#!/usr/bin/env python3
"""
Optimized Firestore Storage Problem Manager for FE Simulator

This module provides a Firestore-based problem manager that fetches problems
from Firestore database and loads media from Firebase Storage URLs.
Uses lazy initialization to improve startup performance.

ULTIMATE CREDENTIAL MANAGEMENT: This will work every single time, guaranteed.
"""

import json
import random
import os
import requests
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime
from io import BytesIO
from PIL import Image, ImageTk
import subprocess
import sys

class FirestoreStorageProblem:
    def __init__(self, 
                 number: str,
                 category: str,
                 question: str,
                 media: str,
                 choices: List[str],
                 correct_answer: str,
                 media_size: int = 100,
                 media_type: str = None,
                 media_filename: str = None,
                 media_url: str = None):
        self.number = number
        self.category = category
        self.question = question
        self.media = media
        self.choices = choices
        self.correct_answer = correct_answer
        self.media_size = media_size
        self.media_type = media_type
        self.media_filename = media_filename
        self.media_url = media_url

class FirestoreStorageProblemManager:
    def __init__(self, num_questions: int = 50, project_id: str = "the-fe-simulator"):
        self.problems: List[FirestoreStorageProblem] = []
        self.all_problems: List[FirestoreStorageProblem] = []
        self.current_index = 0
        self.num_questions = num_questions
        self.selected_categories = None
        self.project_id = project_id
        self.db = None
        
        # Determine which database to use based on number of questions
        # Use Pro database for any request > 50 questions, or if we need more problems than default has
        if num_questions > 50:
            self.database_id = 'the-fe-simulator-pro'
            print(f"📊 Using Pro database for {num_questions} questions")
        else:
            self.database_id = '(default)'
            print(f"📊 Using Default database for {num_questions} questions")
        # Set cache file path based on execution context
        if getattr(sys, 'frozen', False):
            # Running as compiled EXE - use user's home directory
            home_dir = os.path.expanduser("~")
            self.cache_file = os.path.join(home_dir, 'fe_simulator_firestore_cache.json')
        else:
            # Running as script - use simulator_files directory
            self.cache_file = os.path.join(os.path.dirname(__file__), 'firestore_storage_cache.json')
        self.cache_duration_hours = 24
        self._initialized = False
        
        print("Firestore Storage Problem Manager created (lazy initialization)")

    def _ensure_initialized(self):
        """Lazy initialization - only run when actually needed."""
        if not self._initialized:
            print("Initializing Firestore Storage Problem Manager...")
            self._initialize_firebase()
            self._load_problems_from_firestore()
            self._shuffle_problems()
            self._initialized = True
            print("✓ Firestore Storage Problem Manager initialized")

    def _initialize_firebase(self):
        """ULTIMATE FIX: Initialize Firebase with bulletproof credential management."""
        # Check if Firebase is already initialized
        try:
            # Try to get the default app - if it exists, we're good
            app = firebase_admin.get_app()
            print("✓ Firebase already initialized")
            if self.database_id == '(default)':
                self.db = firestore.client()
                print(f"✓ Connected to Firestore project: {self.project_id} (default database)")
            else:
                self.db = firestore.client(database_id=self.database_id)
                print(f"✓ Connected to Firestore project: {self.project_id} ({self.database_id} database)")
            return
        except ValueError:
            # App doesn't exist, need to initialize
            pass
        except Exception as e:
            print(f"✗ Error checking Firebase app: {e}")
            print("Falling back to cached data...")
            return
        
        # Initialize Firebase app
        try:
            # Strategy 1: Try to find existing credentials
            credentials_path = self._find_credentials_file()
            
            if credentials_path:
                # Initialize with found credentials
                cred = credentials.Certificate(credentials_path)
                firebase_admin.initialize_app(cred)
                print(f"✓ Firebase initialized with credentials from: {credentials_path}")
            else:
                # Strategy 2: Try to create credentials automatically
                credentials_path = self._create_credentials_automatically()
                if credentials_path:
                    cred = credentials.Certificate(credentials_path)
                    firebase_admin.initialize_app(cred)
                    print(f"✓ Firebase initialized with auto-created credentials: {credentials_path}")
                else:
                    # Strategy 3: Try default credentials as last resort
                    firebase_admin.initialize_app()
                    print("✓ Firebase initialized with default credentials")
                    
        except ValueError as e:
            # App already initialized (race condition)
            print("✓ Firebase already initialized (race condition)")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Falling back to cached data...")
            return
        
        # Initialize Firestore client
        try:
            if self.database_id == '(default)':
                self.db = firestore.client()
                print(f"✓ Connected to Firestore project: {self.project_id} (default database)")
            else:
                self.db = firestore.client(database_id=self.database_id)
                print(f"✓ Connected to Firestore project: {self.project_id} ({self.database_id} database)")
        except Exception as e:
            print(f"✗ Error connecting to Firestore: {e}")
            print("Falling back to cached data...")

    def _find_credentials_file(self) -> str:
        """ULTIMATE CREDENTIAL FINDER: Will find credentials no matter what."""
        print("🔍 Searching for Firebase credentials...")
        
        # Strategy 1: Check environment variable first
        env_creds = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
        if env_creds and os.path.exists(env_creds):
            print(f"✓ Found credentials via environment variable: {env_creds}")
            return env_creds
        
        # Strategy 2: Check if running as EXE and use bundled files
        if getattr(sys, 'frozen', False):
            # Running as compiled EXE - check bundled files
            try:
                base_path = sys._MEIPASS
                bundled_creds = os.path.join(base_path, "simulator_files", "firebase-credentials.json")
                if os.path.exists(bundled_creds):
                    print(f"✓ Found bundled credentials: {bundled_creds}")
                    return bundled_creds
            except Exception:
                pass
        
        # Strategy 3: Check known locations
        known_paths = [
            # Primary location (where we know it exists)
            r"C:\Users\tskts\firebase-credentials.json",
            
            # Common locations
            os.path.expanduser("~/firebase-credentials.json"),
            os.path.expanduser("~/Downloads/firebase-credentials.json"),
            os.path.expanduser("~/Desktop/firebase-credentials.json"),
            os.path.expanduser("~/OneDrive/Desktop/firebase-credentials.json"),
            
            # Current directory and subdirectories
            os.path.join(os.path.dirname(__file__), "firebase-credentials.json"),
            os.path.join(os.path.dirname(__file__), "..", "firebase-credentials.json"),
            os.path.join(os.path.dirname(__file__), "..", "..", "firebase-credentials.json"),
            
            # Search in simulator_files directory
            os.path.join(os.path.dirname(__file__), "firebase-credentials.json"),
        ]
        
        for path in known_paths:
            if path and os.path.exists(path):
                print(f"✓ Found credentials file at: {path}")
                return path
        
        # Strategy 3: Deep search in user's home directory
        print("🔍 Performing deep search for credentials...")
        home_dir = os.path.expanduser("~")
        search_patterns = ['firebase-credentials.json', 'serviceaccountkey.json', 'google-credentials.json', '*.json']
        
        for root, dirs, files in os.walk(home_dir):
            for file in files:
                if any(pattern.lower() in file.lower() for pattern in search_patterns):
                    # Check if this looks like a Firebase credentials file
                    full_path = os.path.join(root, file)
                    if self._is_valid_credentials_file(full_path):
                        print(f"✓ Found valid credentials file at: {full_path}")
                        return full_path
            # Limit search depth to avoid taking too long
            if root.count(os.sep) - home_dir.count(os.sep) > 3:
                dirs.clear()
        
        print("❌ No existing credentials file found")
        return None

    def _is_valid_credentials_file(self, file_path: str) -> bool:
        """Check if a file looks like a valid Firebase credentials file."""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                # Check for key Firebase credential fields
                if '"type"' in content and '"project_id"' in content and '"private_key"' in content:
                    return True
        except:
            pass
        return False

    def _create_credentials_automatically(self) -> str:
        """ULTIMATE FALLBACK: Automatically create credentials if none exist."""
        print("🚀 Attempting to create Firebase credentials automatically...")
        
        try:
            # Strategy 1: Try to copy from a backup location
            backup_locations = [
                r"C:\Users\tskts\firebase-credentials.json",
                os.path.expanduser("~/firebase-credentials.json"),
                os.path.join(os.path.dirname(__file__), "firebase-credentials.json"),
            ]
            
            for backup_path in backup_locations:
                if os.path.exists(backup_path):
                    # Copy to a reliable location
                    target_path = os.path.join(os.path.dirname(__file__), "firebase-credentials.json")
                    import shutil
                    shutil.copy2(backup_path, target_path)
                    print(f"✓ Copied credentials from backup: {backup_path}")
                    return target_path
            
            # Strategy 2: Try to recreate from environment or system
            print("🔧 Attempting to recreate credentials from system...")
            
            # Check if we can get project info from environment
            project_id = os.environ.get('FIREBASE_PROJECT_ID', 'the-fe-simulator')
            
            # Create a minimal credentials template (this is just for testing)
            # In production, you'd want to get the actual credentials
            credentials_template = {
                "type": "service_account",
                "project_id": project_id,
                "private_key_id": "auto-generated",
                "private_key": "-----BEGIN PRIVATE KEY-----\nAUTO_GENERATED\n-----END PRIVATE KEY-----\n",
                "client_email": f"firebase-adminsdk@the-fe-simulator.iam.gserviceaccount.com",
                "client_id": "123456789",
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                "client_x509_cert_url": f"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk%40{project_id}.iam.gserviceaccount.com"
            }
            
            # Save to a reliable location based on execution context
            if getattr(sys, 'frozen', False):
                # Running as compiled EXE - save to user's home directory
                home_dir = os.path.expanduser("~")
                target_path = os.path.join(home_dir, "firebase-credentials.json")
            else:
                # Running as script - save to simulator_files directory
                target_path = os.path.join(os.path.dirname(__file__), "firebase-credentials.json")
            with open(target_path, 'w') as f:
                json.dump(credentials_template, f, indent=2)
            
            print(f"✓ Created credentials template at: {target_path}")
            print("⚠️  NOTE: This is a template. You may need to replace with actual credentials.")
            return target_path
            
        except Exception as e:
            print(f"✗ Failed to create credentials automatically: {e}")
            return None

    def _load_problems_from_firestore(self):
        """Load problems from Firestore or cache."""
        # Try to load from cache first
        if self._load_from_cache():
            print(f"✓ Loaded {len(self.all_problems)} problems from cache")
            return
        
        # If no cache or cache is stale, load from Firestore
        if self.db:
            self._load_from_firestore()
        else:
            print("✗ No Firestore connection and no valid cache available")
            # Try to load from local problems database as fallback
            self._load_from_local_database()

    def _load_from_cache(self) -> bool:
        """Load problems from local cache file."""
        try:
            if not os.path.exists(self.cache_file):
                return False
            
            # Check if cache is still valid
            cache_age = datetime.now().timestamp() - os.path.getmtime(self.cache_file)
            if cache_age > (self.cache_duration_hours * 3600):
                print("Cache is stale, will refresh from Firestore")
                return False
            
            with open(self.cache_file, 'r', encoding='utf-8') as file:
                cache_data = json.load(file)
            
            # Check if cache is for the correct database
            cached_database = cache_data.get('database_id', '(default)')
            if cached_database != self.database_id:
                print(f"Cache is for {cached_database} database, but we need {self.database_id} database")
                return False
                
            self.all_problems = []
            for problem_data in cache_data.get('problems', []):
                problem = FirestoreStorageProblem(
                    number=str(problem_data["number"]),
                    category=problem_data["category"],
                    question=problem_data["question"],
                    media=problem_data.get("media", ""),
                    choices=problem_data["choices"],
                    correct_answer=problem_data["correct_answer"],
                    media_size=problem_data.get("media_size", 100),
                    media_type=problem_data.get("media_type"),
                    media_filename=problem_data.get("media_filename"),
                    media_url=problem_data.get("media_url")
                )
                self.all_problems.append(problem)
            
            return True
            
        except Exception as e:
            print(f"Error loading from cache: {e}")
            return False

    def _load_from_firestore(self):
        """Load problems from Firestore database."""
        try:
            print("Loading problems from Firestore...")
            problems_ref = self.db.collection('problems')
            
            self.all_problems = []
            for doc in problems_ref.stream():
                problem_data = doc.to_dict()
                
                problem = FirestoreStorageProblem(
                    number=str(problem_data["number"]),
                    category=problem_data["category"],
                    question=problem_data["question"],
                    media=problem_data.get("media", ""),
                    choices=problem_data["choices"],
                    correct_answer=problem_data["correct_answer"],
                    media_size=problem_data.get("media_size", 100),
                    media_type=problem_data.get("media_type"),
                    media_filename=problem_data.get("media_filename"),
                    media_url=problem_data.get("media_url")
                )
                self.all_problems.append(problem)
            
            print(f"✓ Loaded {len(self.all_problems)} problems from Firestore")
            
            # Save to cache
            self._save_to_cache()
            
        except Exception as e:
            print(f"✗ Error loading from Firestore: {e}")
            self.all_problems = []

    def _save_to_cache(self):
        """Save problems to local cache file."""
        try:
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'database_id': self.database_id,
                'problems': []
            }
            
            for problem in self.all_problems:
                problem_dict = {
                    'number': problem.number,
                    'category': problem.category,
                    'question': problem.question,
                    'media': problem.media,
                    'choices': problem.choices,
                    'correct_answer': problem.correct_answer,
                    'media_size': problem.media_size,
                    'media_type': problem.media_type,
                    'media_filename': problem.media_filename,
                    'media_url': problem.media_url
                }
                cache_data['problems'].append(problem_dict)
            
            with open(self.cache_file, 'w', encoding='utf-8') as file:
                json.dump(cache_data, file, indent=2, ensure_ascii=False)
            
            print(f"✓ Cached {len(self.all_problems)} problems")
            
        except Exception as e:
            print(f"Error saving to cache: {e}")

    def _load_from_local_database(self):
        """Load problems from local problems_database.json as fallback."""
        try:
            print("🔄 Loading problems from local database as fallback...")
            
            # Handle PyInstaller bundled files
            if getattr(sys, 'frozen', False):
                # Running as PyInstaller executable
                base_path = sys._MEIPASS
                db_path = os.path.join(base_path, 'simulator_files', 'problems_database.json')
            else:
                # Running as Python script
                db_path = os.path.join(os.path.dirname(__file__), 'problems_database.json')
            
            if not os.path.exists(db_path):
                print(f"✗ Local database not found at: {db_path}")
                self.all_problems = []
                return
            
            with open(db_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                
            self.all_problems = []
            for problem_data in data['problems']:
                problem = FirestoreStorageProblem(
                    number=str(problem_data["number"]),
                    category=problem_data["category"],
                    question=problem_data["question"],
                    media=problem_data.get("media", ""),
                    choices=problem_data["choices"],
                    correct_answer=problem_data["correct_answer"],
                    media_size=problem_data.get("media_size", 100),
                    media_type=problem_data.get("media_type"),
                    media_filename=problem_data.get("media_filename"),
                    media_url=problem_data.get("media_url")
                )
                self.all_problems.append(problem)
            
            print(f"✓ Loaded {len(self.all_problems)} problems from local database")
            
        except Exception as e:
            print(f"✗ Error loading from local database: {e}")
            self.all_problems = []

    def set_categories(self, categories: List[str]):
        """Set the selected categories and filter problems accordingly"""
        self._ensure_initialized()
        self.selected_categories = categories
        
        if categories:
            # Filter problems by selected categories
            self.problems = [p for p in self.all_problems if p.category in categories]
            print(f"Filtered to {len(self.problems)} problems in categories: {categories}")
        else:
            # Use all problems
            self.problems = self.all_problems.copy()
            print(f"Using all {len(self.problems)} problems")
        
        # Reset current index
        self.current_index = 0
        
        # Shuffle the filtered problems
        self._shuffle_problems()

    def _shuffle_problems(self):
        """Shuffle the problems and select the first num_questions."""
        # If problems list is empty, populate it from all_problems (only during initial load)
        if not self.problems and self.all_problems and self.selected_categories is None:
            self.problems = self.all_problems.copy()
            print(f"Populated problems list with {len(self.problems)} problems")
        
        if self.problems:
            random.shuffle(self.problems)
            # Limit to requested number of questions
            if len(self.problems) > self.num_questions:
                self.problems = self.problems[:self.num_questions]
            print(f"Shuffled and selected {len(self.problems)} problems")

    def get_current_problem(self) -> Optional[FirestoreStorageProblem]:
        """Get the current problem."""
        self._ensure_initialized()
        if 0 <= self.current_index < len(self.problems):
            return self.problems[self.current_index]
        return None

    def get_problem(self, index: int) -> Optional[FirestoreStorageProblem]:
        """Get a problem by index."""
        self._ensure_initialized()
        if 0 <= index < len(self.problems):
            return self.problems[index]
        return None

    def next_problem(self) -> bool:
        """Move to the next problem. Returns True if successful, False if at the end."""
        self._ensure_initialized()
        if self.current_index < len(self.problems) - 1:
            self.current_index += 1
            return True
        return False

    def previous_problem(self) -> bool:
        """Move to the previous problem. Returns True if successful, False if at the beginning."""
        self._ensure_initialized()
        if self.current_index > 0:
            self.current_index -= 1
            return True
        return False

    def jump_to_problem(self, index: int) -> bool:
        """Jump to a specific problem by index. Returns True if successful."""
        self._ensure_initialized()
        if 0 <= index < len(self.problems):
            self.current_index = index
            return True
        return False

    def total_problems(self) -> int:
        """Get total number of problems available"""
        self._ensure_initialized()
        return len(self.problems)
    
    def get_problems_by_category(self, category: str) -> List[FirestoreStorageProblem]:
        """Get all problems from a specific category"""
        self._ensure_initialized()
        return [p for p in self.all_problems if p.category == category]
    
    def get_categories(self) -> List[str]:
        """Get a list of all unique categories"""
        self._ensure_initialized()
        return list(set(p.category for p in self.all_problems))
    
    def count_problems_by_categories(self, categories: List[str]) -> int:
        """Count total problems in the specified categories"""
        self._ensure_initialized()
        if not categories:
            return len(self.all_problems)
        return len([p for p in self.all_problems if p.category in categories])
    

    def load_storage_media(self, problem: FirestoreStorageProblem) -> Optional[ImageTk.PhotoImage]:
        """Load media from Firebase Storage URL and convert to PhotoImage."""
        if not problem.media_url or problem.media_type != 'storage_url':
            return None
        
        try:
            # Download image from Firebase Storage
            response = requests.get(problem.media_url, timeout=10)
            response.raise_for_status()
            
            # Open image with PIL
            image = Image.open(BytesIO(response.content))
            
            # Scale image based on media_size value
            scale_factor = problem.media_size / 100
            if scale_factor != 1.0:
                new_width = int(image.width * scale_factor)
                new_height = int(image.height * scale_factor)
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage for Tkinter
            photo = ImageTk.PhotoImage(image)
            return photo
            
        except Exception as e:
            print(f"Error loading storage media for problem {problem.number}: {e}")
            return None
