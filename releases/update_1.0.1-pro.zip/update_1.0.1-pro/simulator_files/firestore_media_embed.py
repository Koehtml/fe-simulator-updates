#!/usr/bin/env python3
"""
Firestore Media Embed Script for FE Simulator

This script embeds media files directly in Firestore documents as base64 strings,
avoiding the need for Firebase Storage setup.
"""

import os
import sys
import json
import base64
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

class FirestoreMediaEmbedder:
    def __init__(self, project_id: str = "the-fe-simulator"):
        """
        Initialize the Firestore media embedder.
        
        Args:
            project_id: Firebase project ID
        """
        self.project_id = project_id
        self.db = None
        self.embedded_files = {}
        self.updated_documents = []
        self.errors = []
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to initialize with default credentials
            firebase_admin.initialize_app()
            print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Please ensure you have set up Firebase Admin SDK credentials.")
            sys.exit(1)
        
        # Initialize Firestore client
        self.db = firestore.client()
        print(f"✓ Connected to Firestore project: {self.project_id}")
    
    def get_media_files(self, media_dir: str) -> Dict[str, str]:
        """
        Get all media files and convert them to base64 strings.
        
        Args:
            media_dir: Path to media directory
            
        Returns:
            Dictionary mapping filename to base64 string
        """
        media_files = {}
        if not os.path.exists(media_dir):
            print(f"✗ Media directory not found: {media_dir}")
            return media_files
        
        # Get all image files
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
        for filename in os.listdir(media_dir):
            file_path = os.path.join(media_dir, filename)
            if os.path.isfile(file_path):
                _, ext = os.path.splitext(filename.lower())
                if ext in image_extensions:
                    try:
                        with open(file_path, 'rb') as f:
                            file_data = f.read()
                            base64_data = base64.b64encode(file_data).decode('utf-8')
                            media_files[filename] = base64_data
                            print(f"✓ Encoded {filename} ({len(file_data)} bytes)")
                    except Exception as e:
                        print(f"✗ Error encoding {filename}: {e}")
                        self.errors.append(f"Error encoding {filename}: {e}")
        
        print(f"✓ Successfully encoded {len(media_files)} media files")
        return media_files
    
    def get_problems_with_media(self) -> List[Dict]:
        """
        Get all problems from Firestore that have media files.
        
        Returns:
            List of problem documents with media
        """
        try:
            problems_ref = self.db.collection('problems')
            problems = []
            
            for doc in problems_ref.stream():
                problem_data = doc.to_dict()
                if problem_data.get('media') and problem_data['media'].strip():
                    problem_data['doc_id'] = doc.id
                    problems.append(problem_data)
            
            print(f"✓ Found {len(problems)} problems with media files")
            return problems
            
        except Exception as e:
            print(f"✗ Error fetching problems from Firestore: {e}")
            self.errors.append(f"Error fetching problems: {e}")
            return []
    
    def update_problem_media_data(self, doc_id: str, media_filename: str, base64_data: str) -> bool:
        """
        Update a problem document with embedded media data.
        
        Args:
            doc_id: Document ID
            media_filename: Original media filename
            base64_data: Base64 encoded media data
            
        Returns:
            True if successful, False otherwise
        """
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc_ref.update({
                'media': base64_data,
                'media_filename': media_filename,
                'media_type': 'base64',
                'media_updated_at': datetime.utcnow()
            })
            return True
            
        except Exception as e:
            print(f"✗ Error updating document {doc_id}: {e}")
            self.errors.append(f"Error updating document {doc_id}: {e}")
            return False
    
    def embed_all_media(self, media_dir: str):
        """
        Embed all media files in Firestore documents.
        
        Args:
            media_dir: Path to media directory
        """
        print("\n" + "="*50)
        print("EMBEDDING MEDIA FILES IN FIRESTORE DOCUMENTS")
        print("="*50)
        
        # Get and encode media files
        self.embedded_files = self.get_media_files(media_dir)
        if not self.embedded_files:
            print("No media files found to embed.")
            return
        
        # Get problems with media
        problems = self.get_problems_with_media()
        if not problems:
            print("No problems with media found.")
            return
        
        # Update documents
        updated_count = 0
        skipped_count = 0
        
        for problem in problems:
            doc_id = problem['doc_id']
            media_filename = problem['media']
            
            # Check if we have the encoded file
            if media_filename in self.embedded_files:
                base64_data = self.embedded_files[media_filename]
                
                print(f"Updating problem {doc_id} ({media_filename})...", end=" ")
                
                if self.update_problem_media_data(doc_id, media_filename, base64_data):
                    self.updated_documents.append(doc_id)
                    updated_count += 1
                    print("✓ Updated")
                else:
                    print("✗ Failed")
            else:
                print(f"Skipping problem {doc_id} - media file '{media_filename}' not found")
                skipped_count += 1
        
        print(f"\n✓ Updated {updated_count} documents")
        print(f"⚠ Skipped {skipped_count} documents (media not found)")
    
    def print_summary(self):
        """Print embed summary."""
        print("\n" + "="*50)
        print("MEDIA EMBED SUMMARY")
        print("="*50)
        print(f"Files encoded: {len(self.embedded_files)}")
        print(f"Documents updated in Firestore: {len(self.updated_documents)}")
        print(f"Errors encountered: {len(self.errors)}")
        
        if self.embedded_files:
            print(f"\nEmbedded files:")
            for filename in self.embedded_files.keys():
                print(f"  ✓ {filename}")
        
        if self.updated_documents:
            print(f"\nUpdated document IDs: {', '.join(sorted(self.updated_documents))}")
        
        if self.errors:
            print(f"\nERRORS:")
            for error in self.errors:
                print(f"  - {error}")
    
    def run_media_embed(self, media_dir: str):
        """
        Run the complete media embed process.
        
        Args:
            media_dir: Path to media directory
        """
        print("FE Simulator - Media Embed Tool")
        print("="*40)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Embed media files
        self.embed_all_media(media_dir)
        
        # Print summary
        self.print_summary()


def main():
    """Main function to run the media embed script."""
    # Get the path to the media directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    media_dir = os.path.join(os.path.dirname(script_dir), "media")
    
    # Check if media directory exists
    if not os.path.exists(media_dir):
        print(f"✗ Error: Media directory not found at {media_dir}")
        print("Please ensure the media directory exists and contains image files.")
        sys.exit(1)
    
    # Create embedder and run embed
    embedder = FirestoreMediaEmbedder()
    embedder.run_media_embed(media_dir)


if __name__ == "__main__":
    main()


