import tkinter as tk
from tkinter import ttk, messagebox, filedialog, Menu
from PIL import Image, ImageTk
import json
import time
from simulator_files.problem_manager import ProblemManager, Problem
from simulator_files.firestore_storage_problem_manager_optimized import FirestoreStorageProblemManager, FirestoreStorageProblem
from simulator_files.calculator import ScientificCalculator
from simulator_files.exam_stats import ExamStats
from simulator_files.latex_renderer import LaTeXRenderer
from simulator_files.simple_updater import create_simple_updater, show_simple_update_dialog
from simulator_files.update_config import get_app_info
import os
import sys
import re
from io import BytesIO
from datetime import datetime, timedelta
import webbrowser
import threading
import random

# Debug information for troubleshooting
if getattr(sys, 'frozen', False):
    print(f"Running as compiled EXE from: {sys._MEIPASS}")
else:
    print(f"Running as script from: {os.path.dirname(__file__)}")

# https://stackoverflow.com/questions/31836104/pyinstaller-and-onefile-how-to-include-an-image-in-the-exe-file
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def get_debug_log_path():
    if getattr(sys, 'frozen', False):
        # Running as compiled EXE - write to user's home directory
        home_dir = os.path.expanduser("~")
        return os.path.join(home_dir, 'fe_simulator_debug.log')
    else:
        # Running as script - write to simulator_files directory
        return os.path.join(os.path.dirname(__file__), 'simulator_files', 'debug.log')

def get_paused_exam_path():
    """Get the correct path for paused_exam.json based on execution context"""
    if getattr(sys, 'frozen', False):
        # Running as compiled EXE - write to user's home directory
        home_dir = os.path.expanduser("~")
        return os.path.join(home_dir, 'fe_simulator_paused_exam.json')
    else:
        # Running as script - write to simulator_files directory
        return os.path.join(os.path.dirname(__file__), 'simulator_files', 'paused_exam.json')

# Write to a log file to track execution
with open(get_debug_log_path(), "w") as f:
    f.write("Starting program...\n")



# Import problem managers
try:
    from simulator_files.firestore_storage_problem_manager_optimized import FirestoreStorageProblemManager
    print("✓ Firestore Storage Problem Manager imported successfully")
except ImportError as e:
    print(f"✗ Failed to import Firestore Storage Problem Manager: {e}")
    FirestoreStorageProblemManager = None

try:
    from simulator_files.problem_manager import ProblemManager
    print("✓ Local Problem Manager imported successfully")
except ImportError as e:
    print(f"✗ Failed to import Local Problem Manager: {e}")
    ProblemManager = None

class FEExamSimulator(tk.Tk):
    def __init__(self, test_type="timed", num_questions=5, selected_categories=None):
        with open(get_debug_log_path(), "a") as f:
            f.write("Initializing FEExamSimulator...\n")
        super().__init__()
        self.title("FE Exam Practice Software")
        self.state('zoomed')
        
        # Store test settings
        self.test_type = test_type
        self.num_questions = num_questions
        
        # Track answered and flagged questions
        self.answered_questions = set()
        self.flagged_questions = set()
        self.user_answers = {}  # Store user's answers
        
        # Track exam time
        self.start_time = time.time()
        
        # Set color scheme
        self.configure(bg='#f0f0f0')
        style = ttk.Style()
        style.configure('TopBar.TFrame', background='#0269B6')  # Science Blue
        style.configure('TopBar.TLabel', background='#0269B6', foreground='white', font=('Arial', 9))
        style.configure('SecondaryBar.TFrame', background='#8AB9EE')  # Jordy Blue
        style.configure('Tool.TButton', padding=2, font=('Arial', 12))
        style.configure('Calculator.TButton', padding=2, font=('Arial', 11))
        style.configure('Flag.TButton', padding=2, font=('Arial', 11))
        
        # Add styles for question navigator buttons
        style.configure('Current.TButton', background='#4CAF50', foreground='black')  # Green for current question with black text
        style.configure('Flagged.TButton', background='#FFC107', foreground='black')  # Yellow for flagged questions with black text
        
        # Configure the large radio button style
        style.configure('Large.TRadiobutton', font=('Arial', 11))
        
        # Configure the large navigation button style
        style.configure('Large.TButton', font=('Arial', 12))
        

        
        # Initialize the problem manager (Firestore-first with local fallback)
        try:
            # Try Firestore first
            if FirestoreStorageProblemManager is not None:
                # Check if we need to use Pro database based on selected categories
                if selected_categories and self.num_questions <= 50:
                    # Check if default database has enough problems for selected categories
                    temp_manager = FirestoreStorageProblemManager(num_questions=50)
                    temp_manager.set_categories(selected_categories)
                    available_in_default = temp_manager.total_problems()
                    
                    if available_in_default < self.num_questions:
                        # Not enough problems in default database, use Pro database
                        self.problem_manager = FirestoreStorageProblemManager(num_questions=self.num_questions)
                        # Force Pro database
                        self.problem_manager.database_id = 'the-fe-simulator-pro'
                        with open(get_debug_log_path(), "a") as f:
                            f.write(f"Using Pro database due to insufficient problems in default ({available_in_default} < {self.num_questions})\n")
                    else:
                        self.problem_manager = FirestoreStorageProblemManager(num_questions=self.num_questions)
                else:
                    self.problem_manager = FirestoreStorageProblemManager(num_questions=self.num_questions)
                
                # Debug logging
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Firestore Storage problem manager created (lazy initialization)\n")
            else:
                raise Exception("FirestoreStorageProblemManager not available")
        except Exception as e:
            # Fallback to local problem manager
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Firestore failed, falling back to local: {str(e)}\n")
            try:
                self.problem_manager = ProblemManager(num_questions=self.num_questions)
                # Debug logging
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Local problem manager created with {self.problem_manager.total_problems()} problems\n")
            except Exception as local_e:
                # Debug logging
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Error initializing local problem manager: {str(local_e)}\n")
                raise
        
        # Set selected categories BEFORE loading the first problem
        if selected_categories:
            self.problem_manager.set_categories(selected_categories)
        
        # Initialize LaTeX renderer
        self.latex_renderer = LaTeXRenderer()
        
        # Configure the main window grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)  # Top bar
        self.grid_rowconfigure(1, weight=0)  # Secondary bar
        self.grid_rowconfigure(2, weight=1)  # Main content

        # Create the top bar
        self.create_top_bar()
        
        # Create the secondary bar
        self.create_secondary_bar()
        
        # Create the main content area
        self.create_main_content()
        
        # Configure timer label after UI is created
        if self.test_type == "timed":
            if hasattr(self, 'remaining_time') and self.remaining_time > 0:
                self.timer_label.config(text="Timed Exam")
            else:
                self.timer_label.config(text="Timed Exam")
        else:
            self.timer_label.config(text="Untimed Exam")

        # Initialize timer if test is timed
        if self.test_type == "timed":
            # Calculate timer based on actual number of problems that will be shown
            try:
                actual_problems = self.problem_manager.total_problems()
                if actual_problems > 0:
                    self.remaining_time = 3 * 60 * actual_problems  # 3 minutes per actual question
                    print(f"Timer set for {actual_problems} problems (requested: {self.num_questions})")
                    self.grace_period = 5  # 5 second grace period
                else:
                    # No problems available - disable timed mode
                    print("Warning: No problems available, switching to non-timed mode")
                    self.test_type = "non-timed"
            except Exception as e:
                print(f"Error getting problem count: {e}")
                # Fallback to non-timed mode
                self.test_type = "non-timed"
        else:
            # Non-timed test
            pass

        # Initialize exam state
        self.exam_started = False
        self.pdf_loaded = False
        
        # Flag to prevent timer updates when window is being destroyed
        self.is_destroying = False
        
        # Initialize update manager
        app_info = get_app_info()
        self.update_manager = create_simple_updater(
            app_name=app_info['name'],
            current_version=app_info['version']
        )
        
        # Create menu bar
        self.create_menu_bar()
        
        # Check for updates on startup (if enabled)
        self.check_updates_on_startup()
        
        # Flag to track if this is a resumed exam
        self.is_resumed_exam = False
        
        # Show initial message instead of loading first problem
        self.show_pdf_requirement_message()
        
        # Bind keyboard shortcuts
        self.bind_keyboard_shortcuts()
        
        # Bind window close event to prevent accidental exit
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    @classmethod
    def from_saved_state(cls, exam_state):
        """Create a simulator instance from a saved exam state"""
        # Create instance with saved settings
        instance = cls.__new__(cls)
        instance.test_type = exam_state['test_type']
        instance.num_questions = exam_state['num_questions']
        
        # Initialize basic attributes
        instance.answered_questions = set(exam_state['answered_questions'])
        instance.flagged_questions = set(exam_state['flagged_questions'])
        # Ensure user_answers keys are integers
        instance.user_answers = {int(k): v for k, v in exam_state['user_answers'].items()}
        instance.start_time = exam_state['start_time']
        
        # Initialize the main window
        super(cls, instance).__init__()
        instance.title("FE Exam Practice Software")
        instance.state('zoomed')
        
        # Set color scheme
        instance.configure(bg='#f0f0f0')
        style = ttk.Style()
        style.configure('TopBar.TFrame', background='#0269B6')  # Science Blue
        style.configure('TopBar.TLabel', background='#0269B6', foreground='white', font=('Arial', 9))
        style.configure('SecondaryBar.TFrame', background='#8AB9EE')  # Jordy Blue
        style.configure('Tool.TButton', padding=2, font=('Arial', 12))
        style.configure('Calculator.TButton', padding=2, font=('Arial', 11))
        style.configure('Flag.TButton', padding=2, font=('Arial', 11))
        style.configure('Current.TButton', background='#4CAF50', foreground='black')
        style.configure('Flagged.TButton', background='#FFC107', foreground='black')
        style.configure('Large.TRadiobutton', font=('Arial', 11))
        style.configure('Large.TButton', font=('Arial', 12))
        
        # Initialize LaTeX renderer
        instance.latex_renderer = LaTeXRenderer()
        
        # Configure the main window grid
        instance.grid_columnconfigure(0, weight=1)
        instance.grid_rowconfigure(0, weight=0)  # Top bar
        instance.grid_rowconfigure(1, weight=0)  # Secondary bar
        instance.grid_rowconfigure(2, weight=1)  # Main content

        # Create the UI components
        instance.create_top_bar()
        instance.create_secondary_bar()
        instance.create_main_content()

        # Initialize problem manager with saved problems (after UI is created)
        # Use Firestore-first with local fallback for resumed exams too
        try:
            if FirestoreStorageProblemManager is not None:
                instance.problem_manager = FirestoreStorageProblemManager(num_questions=instance.num_questions)
            else:
                raise Exception("FirestoreStorageProblemManager not available")
        except Exception as e:
            # Fallback to local problem manager
            instance.problem_manager = ProblemManager(num_questions=instance.num_questions)
        
        instance.problem_manager.selected_categories = exam_state['selected_categories']
        
        # Reconstruct problems from saved state
        instance.problem_manager.problems = []
        for problem_data in exam_state['problems']:
            problem = Problem(
                number=problem_data[0],
                category=problem_data[1],
                question=problem_data[2],
                media=problem_data[3],
                choices=problem_data[4],
                correct_answer=problem_data[5],
                media_size=problem_data[6]
            )
            instance.problem_manager.problems.append(problem)
        
        # Set current index
        instance.problem_manager.current_index = exam_state['current_index']
        
        # Mark as initialized to prevent lazy initialization issues
        instance.problem_manager._initialized = True

        # Configure timer label based on exam type
        if instance.test_type == "timed":
            instance.timer_label.config(text="Timed Exam")
        else:
            instance.timer_label.config(text="Untimed Exam")

        # For resumed exams, we need to handle PDF loading for both timed and untimed exams
        if instance.test_type == "timed":
            # Set flags to require PDF loading
            instance.exam_started = False
            instance.pdf_loaded = False
            instance.remaining_time = exam_state['remaining_time']
            instance.grace_period = 5  # 5 second grace period for resumed exams
            
            # Show PDF requirement message instead of loading problem
            instance.show_pdf_requirement_message()
        else:
            # For untimed exams, also require PDF loading
            instance.exam_started = False
            instance.pdf_loaded = False
            
            # Show PDF requirement message instead of loading problem
            instance.show_pdf_requirement_message()
        
        # Flag to prevent timer updates when window is being destroyed
        instance.is_destroying = False
        
        # Flag to track if this is a resumed exam
        instance.is_resumed_exam = True
        
        # Bind keyboard shortcuts
        instance.bind_keyboard_shortcuts()
        
        # Bind window close event to prevent accidental exit
        instance.protocol("WM_DELETE_WINDOW", instance.on_closing)
        
        return instance

    def create_top_bar(self):
        top_frame = ttk.Frame(self, style='TopBar.TFrame')
        top_frame.grid(row=0, column=0, sticky="ew")
        
        # Software title and username
        title_label = ttk.Label(top_frame, 
                              text="The FE Civil Simulator ~ Copyright 2025",
                              style='TopBar.TLabel')
        title_label.pack(side=tk.LEFT, padx=15, pady=2)  # Reduced padding for thinner bar
        
        # Right side container for timer and progress
        right_container = ttk.Frame(top_frame, style='TopBar.TFrame')
        right_container.pack(side=tk.RIGHT, padx=15, pady=2)  # Reduced padding for thinner bar
        
        # Timer
        self.timer_label = ttk.Label(right_container, 
                                   text="Time Remaining: ",
                                   style='TopBar.TLabel')
        self.timer_label.pack(anchor='e')
        
        # Progress container
        progress_container = ttk.Frame(right_container, style='TopBar.TFrame')
        progress_container.pack(anchor='e', pady=(2,0))  # Reduced padding
        
        # Progress bar and question number
        self.progress = ttk.Progressbar(progress_container, 
                                      length=200,
                                      mode='determinate')
        self.progress.pack(side=tk.LEFT)
        
        self.question_number = ttk.Label(progress_container,
                                       text=" ",
                                       style='TopBar.TLabel')
        self.question_number.pack(side=tk.LEFT, padx=(8,0))  # Reduced padding
        
        # Question navigator button
        ttk.Button(progress_container,
                  text=":::",
                  width=2,  # Reduced width
                  command=self.show_question_navigator).pack(side=tk.LEFT, padx=(8,0))  # Reduced padding

    def create_secondary_bar(self):
        self.secondary_frame = ttk.Frame(self, style='SecondaryBar.TFrame')
        self.secondary_frame.grid(row=1, column=0, sticky="ew")
        
        # Calculator button (left)
        calculator_btn = ttk.Button(self.secondary_frame, 
                                  text="Calculator",
                                  style='Calculator.TButton',
                                  command=self.open_calculator)
        calculator_btn.pack(side=tk.LEFT, padx=20, pady=2)
        calculator_btn.configure(width=9)  # Set width to make button square
        
        # Flag button (right)
        self.flag_btn = ttk.Button(self.secondary_frame,
                             text="Flag for Review 🚩",
                             style='Flag.TButton',
                             command=self.mark_for_review)
        self.flag_btn.pack(side=tk.RIGHT, padx=20, pady=2)
        self.flag_btn.configure(width=17)  # Set width to make button square

    def create_main_content(self):
        # Main content container
        main_frame = ttk.Frame(self)
        main_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
        
        # Configure column weights for 50/50 handbook/problem area
        main_frame.grid_columnconfigure(0, weight=50, uniform="column")  # Reference handbook
        main_frame.grid_columnconfigure(1, weight=50, uniform="column")  # Problem area
        main_frame.grid_rowconfigure(0, weight=1)  # Make content expand vertically
        
        # Reference Handbook (left side)
        handbook_frame = ttk.LabelFrame(main_frame, text="PDF Viewer")
        handbook_frame.grid(row=0, column=0, sticky="nsew", padx=(5,2), pady=5)
        handbook_frame.grid_rowconfigure(0, weight=1)
        handbook_frame.grid_columnconfigure(0, weight=1)
        
        # Initialize PDF viewer without a default PDF
        try:
            from simulator_files.custom_pdf_viewer import CustomPDFViewer
            self.pdf_viewer = CustomPDFViewer(handbook_frame)
            self.pdf_viewer.grid(row=0, column=0, sticky="nsew")
            
            # Set callback for when PDF is loaded
            self.pdf_viewer.set_pdf_loaded_callback(self.on_pdf_loaded)
            
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write("PDF viewer initialized successfully\n")
        except Exception as e:
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Error initializing PDF viewer: {str(e)}\n")
            
            # Create a simple placeholder if PDF viewer fails
            placeholder = ttk.Label(handbook_frame, text="PDF Viewer failed to load\nPlease restart the application", 
                                  justify="center", font=('Arial', 12))
            placeholder.grid(row=0, column=0, sticky="nsew")
            self.pdf_viewer = None
        
        # Problem Area (right side)
        problem_frame = ttk.LabelFrame(main_frame, text="Practice Problem")
        problem_frame.grid(row=0, column=1, sticky="nsew", padx=(2,5), pady=5)
        problem_frame.grid_rowconfigure(0, weight=1)  # Problem text
        problem_frame.grid_rowconfigure(1, weight=0)  # Answer choices
        problem_frame.grid_columnconfigure(0, weight=1)
        
        # Problem text area with scrollbar
        self.problem_text = tk.Text(problem_frame, wrap=tk.WORD, width=50, height=10, font=('Arial', 11))
        self.problem_text.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        problem_frame.grid_rowconfigure(0, weight=1)
        problem_frame.grid_columnconfigure(0, weight=1)
        
        # Add vertical scrollbar to problem_text
        problem_scrollbar = ttk.Scrollbar(problem_frame, orient="vertical", command=self.problem_text.yview)
        problem_scrollbar.grid(row=0, column=1, sticky="ns")
        self.problem_text.configure(yscrollcommand=problem_scrollbar.set)
        
        # Answer choices
        self.answers_frame = ttk.Frame(problem_frame)
        self.answers_frame.grid(row=1, column=0, sticky="ew", padx=15, pady=10)
        
        self.answer_var = tk.StringVar()
        self.answer_buttons = []
        
        # Add trace to track answer selection
        self._trace_id = self.answer_var.trace_add("write", self.on_answer_selected)
        
        # Create a frame for navigation buttons at the bottom of the window
        nav_frame = ttk.Frame(self)
        nav_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=5)
        nav_frame.grid_columnconfigure(0, weight=1)  # Left side
        nav_frame.grid_columnconfigure(1, weight=0)  # Right side (no weight for buttons)
        
        # Next/Submit button on the right
        self.next_btn = ttk.Button(nav_frame, text="Next Question", command=self.next_question, style='Large.TButton')
        self.next_btn.grid(row=0, column=1, sticky="e", padx=5)
        
        # Previous button next to the Next button
        self.prev_btn = ttk.Button(nav_frame, text="Previous Question", command=self.prev_question, style='Large.TButton')
        self.prev_btn.grid(row=0, column=0, sticky="e", padx=(0, 10))
        
        # Pause button on the left
        self.pause_btn = ttk.Button(nav_frame, text="⏸️ Pause Exam", command=self.pause_exam, style='Large.TButton')
        self.pause_btn.grid(row=0, column=0, sticky="w", padx=5)
        
        # Remove the old navigation buttons frame
        self.nav_buttons_frame = None

    def show_question_navigator(self):
        # Create a popup window for question navigation
        nav_window = tk.Toplevel(self)
        nav_window.title("Question Navigator")
        nav_window.geometry("400x300")
        nav_window.transient(self)  # Make window stay on top of main window
        nav_window.grab_set()  # Make window modal
        
        # Create a frame for the buttons
        buttons_frame = ttk.Frame(nav_window)
        buttons_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create grid of question buttons based on actual number of questions
        total_questions = self.problem_manager.total_problems()
        if total_questions <= 0:
            # No questions available
            no_questions_label = ttk.Label(buttons_frame, text="No questions available", font=('Arial', 12))
            no_questions_label.pack(pady=20)
            return
            
        for i in range(total_questions):
            row = i // 10
            col = i % 10
            btn = ttk.Button(buttons_frame,
                           text=str(i+1),
                           width=3,
                           command=lambda x=i: self.jump_to_question(x, nav_window))
            btn.grid(row=row, column=col, padx=2, pady=2)
            
            # Highlight current question
            if i == self.problem_manager.current_index:
                btn.configure(style='Current.TButton')
            
            # Highlight flagged questions
            if i in self.flagged_questions:
                btn.configure(style='Flagged.TButton')
                
        # Add close button at the bottom
        close_btn = ttk.Button(nav_window, text="Close", command=nav_window.destroy)
        close_btn.pack(pady=10)

    def jump_to_question(self, index, nav_window=None):
        # Check if we have problems available
        if self.problem_manager.total_problems() <= 0:
            return
            
        if self.problem_manager.jump_to_problem(index):
            self.load_current_problem()
            if nav_window:
                nav_window.destroy()

    def prev_question(self):
        """Navigate to the previous question."""
        # Check if exam has started
        if not self.exam_started and not self.pdf_loaded:
            return
            
        # Check if we have problems available
        if self.problem_manager.total_problems() <= 0:
            return
            
        if self.problem_manager.current_index > 0:
            self.problem_manager.current_index -= 1
            self.load_current_problem()
            self.update_navigation_buttons()

    def next_question(self):
        """Navigate to the next question or submit the exam if on the last question."""
        # Check if exam has started
        if not self.exam_started and not self.pdf_loaded:
            return
            
        # Check if we have problems available
        if self.problem_manager.total_problems() <= 0:
            return
            
        if self.problem_manager.current_index < self.problem_manager.total_problems() - 1:
            self.problem_manager.current_index += 1
            self.load_current_problem()
            self.update_navigation_buttons()
        else:
            self.check_exam_completion()

    def load_current_problem(self):
        # Debug logging
        with open(get_debug_log_path(), "a") as f:
            f.write(f"load_current_problem called - exam_started: {self.exam_started}, pdf_loaded: {self.pdf_loaded}\n")
        
        # Check if exam has started (PDF loaded)
        if not self.exam_started and not self.pdf_loaded:
            with open(get_debug_log_path(), "a") as f:
                f.write("Showing PDF requirement message\n")
            self.show_pdf_requirement_message()
            return
            
        # Show loading indicator if this is the first problem (Firestore initialization)
        if (self.problem_manager.current_index == 0 and 
            hasattr(self.problem_manager, '_initialized') and 
            not self.problem_manager._initialized):
            self.problem_text.delete(1.0, tk.END)
            self.problem_text.insert(tk.END, "Loading problems from Firestore...\n\nPlease wait while we fetch your practice questions.")
            self.problem_text.tag_configure("center", justify="center")
            self.problem_text.tag_add("center", "1.0", "end")
            self.update()  # Force UI update
            
        # Clear the problem text
        self.problem_text.delete(1.0, tk.END)
        
        # Check if problem manager is working
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            self.problem_text.delete(1.0, tk.END)
            self.problem_text.insert(tk.END, "Error: Problem manager is not available.")
            return
            
        # Get the current problem
        try:
            problem = self.problem_manager.get_current_problem()
            if not problem:
                # No problem available - show error message
                self.problem_text.delete(1.0, tk.END)
                self.problem_text.insert(tk.END, "Error: No problem available. Please check your problem manager configuration.")
                return
        except Exception as e:
            # Problem manager error - show error message
            self.problem_text.delete(1.0, tk.END)
            self.problem_text.insert(tk.END, f"Error: Problem manager error: {str(e)}")
            return

        # Update question number
        current = self.problem_manager.current_index + 1
        total = self.problem_manager.total_problems()
        if total > 0:
            self.question_number.config(text=f"Question {current} of {total}")
        else:
            self.question_number.config(text="No questions available")
            return

        # Display the question with LaTeX rendering
        question_text = self.latex_renderer.convert_latex_to_unicode(problem.question)
        self.problem_text.insert(tk.END, f"{question_text}\n")
        
        # Display media if present (check both old media field and new storage fields)
        if problem.media or (hasattr(problem, 'media_url') and problem.media_type == 'storage_url'):
            print(f"DEBUG: Attempting to load media for problem {problem.number}")
            print(f"DEBUG: problem.media = '{problem.media}'")
            print(f"DEBUG: problem.media_url = {getattr(problem, 'media_url', 'N/A')}")
            print(f"DEBUG: problem.media_type = {getattr(problem, 'media_type', 'N/A')}")
            try:
                # Add a newline before the media
                self.problem_text.insert(tk.END, "\n\n")
                
                # Try to load Storage media first (Firestore)
                if hasattr(problem, 'media_url') and problem.media_type == 'storage_url':
                    try:
                        photo = self.problem_manager.load_storage_media(problem)
                        if photo:
                            self.problem_text.image_create(tk.END, image=photo)
                            self.problem_text.media_image = photo
                            print(f"Successfully loaded Storage media for problem {problem.number}")
                        else:
                            print(f"Failed to load Storage media for problem {problem.number}")
                            self.problem_text.insert(tk.END, f"\n[Failed to load Storage media: {problem.media_filename}]")
                    except Exception as e:
                        print(f"Error loading Storage media: {e}")
                        self.problem_text.insert(tk.END, f"\n[Error loading Storage media: {str(e)}]")
                else:
                    # Fallback to local file loading
                    # Load and display the media file - Updated for PyInstaller compatibility
                    if getattr(sys, 'frozen', False):
                        # Running as EXE
                        media_path = os.path.join(sys._MEIPASS, "media", problem.media)
                    else:
                        # Running as script
                        media_path = os.path.join("media", problem.media)
                    
                    # Debug output
                    print(f"Looking for media file: {problem.media}")
                    print(f"Full media path: {media_path}")
                    print(f"File exists: {os.path.exists(media_path)}")
                    
                    # Handle case-insensitive file extension
                    if not os.path.exists(media_path):
                        base, ext = os.path.splitext(media_path)
                        # Try different case combinations
                        for case_ext in [ext.lower(), ext.upper()]:
                            alt_path = base + case_ext
                            if os.path.exists(alt_path):
                                media_path = alt_path
                                print(f"Found file with different case: {alt_path}")
                                break
                    
                    # Handle spaces in filename
                    if not os.path.exists(media_path):
                        alt_path = media_path.replace("_", " ")
                        if os.path.exists(alt_path):
                            media_path = alt_path
                            print(f"Found file with spaces: {alt_path}")
                    
                    if os.path.exists(media_path):
                        print(f"Successfully loading media from: {media_path}")
                        img = Image.open(media_path)
                        # Scale image based on media_size value (default to 100 if not present)
                        scale_factor = problem.media_size / 100 if hasattr(problem, 'media_size') else 1.0
                        new_width = int(img.width * scale_factor)
                        new_height = int(img.height * scale_factor)
                        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                        # Convert to PhotoImage
                        photo = ImageTk.PhotoImage(img)
                        # Insert the image
                        self.problem_text.image_create(tk.END, image=photo)
                        # Keep a reference to prevent garbage collection
                        self.problem_text.media_image = photo
                    else:
                        print(f"Media file not found: {media_path}")
                        self.problem_text.insert(tk.END, f"\n[Media file not found: {problem.media}]")
            except Exception as e:
                print(f"Error loading media: {str(e)}")
                self.problem_text.insert(tk.END, f"\n[Error loading media: {str(e)}]")

        # Temporarily remove the trace to prevent unwanted callbacks
        self.answer_var.trace_remove("write", self._trace_id)
        
        # Reset the answer variable to clear any previous selection
        self.answer_var.set("_unset_")

        # Clear and update answer choices
        for widget in self.answers_frame.winfo_children():
            widget.destroy()

        self.answer_buttons = []
        for choice in problem.choices:
            # Convert LaTeX to Unicode for the answer text
            answer_text = self.latex_renderer.convert_latex_to_unicode(choice)
            btn = tk.Radiobutton(self.answers_frame,
                                 text=answer_text,
                                variable=self.answer_var,
                                 value=choice,
                                 anchor='w',
                                 justify='left',
                                 font=('Arial', 11),
                                 wraplength=500)
            btn.pack(anchor=tk.W, padx=5, pady=2, fill=tk.X)
            self.answer_buttons.append(btn)

            # If this question was previously answered, restore the selection
            if self.problem_manager.current_index in self.user_answers:
                if choice == self.user_answers[self.problem_manager.current_index]:
                    self.answer_var.set(choice)
        
        # Restore the trace after setting up the answer choices
        self._trace_id = self.answer_var.trace_add("write", self.on_answer_selected)
        
        # Update progress
        self.update_progress()
        
        # Update navigation buttons
        self.update_navigation_buttons()
        
        # Update flag button text
        try:
            if (hasattr(self.problem_manager, 'current_index') and 
                self.problem_manager.current_index in self.flagged_questions):
                self.flag_btn.configure(text="Flagged 🚩")
            else:
                self.flag_btn.configure(text="Flag for Review 🚩")
        except Exception as e:
            print(f"Error updating flag button: {e}")
            self.flag_btn.configure(text="Flag for Review 🚩")

    def update_progress(self):
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            return
        try:
            current = getattr(self.problem_manager, 'current_index', 0) + 1
            total = self.problem_manager.total_problems()
            if total > 0:
                progress = (current / total) * 100
                self.progress['value'] = progress
            else:
                self.progress['value'] = 0
        except Exception as e:
            print(f"Error updating progress: {e}")
            self.progress['value'] = 0

    def open_calculator(self):
        calculator = ScientificCalculator(self)
        self.wait_window(calculator)  # Make calculator modal

    def mark_for_review(self):
        # Check if problem manager is working
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            return
            
        try:
            current_index = getattr(self.problem_manager, 'current_index', 0)
            if current_index in self.flagged_questions:
                self.flagged_questions.remove(current_index)
                # Update flag button text
                self.flag_btn.configure(text="Flag for Review 🚩")
            else:
                self.flagged_questions.add(current_index)
                # Update flag button text
                self.flag_btn.configure(text="Flagged 🚩")
            
            # Update question navigator if it's open
            for widget in self.winfo_children():
                if isinstance(widget, tk.Toplevel) and widget.winfo_name() == "Question Navigator":
                    self.show_question_navigator()
                    break
        except Exception as e:
            print(f"Error marking question for review: {e}")

    def update_grace_period(self):
        """Update the grace period countdown."""
        if self.is_destroying:
            return
            
        if self.grace_period > 0:
            # Different message for resumed exams
            if hasattr(self, 'is_resumed_exam') and self.is_resumed_exam:
                self.timer_label.config(text=f"Resuming in {self.grace_period} seconds...")
            else:
                self.timer_label.config(text=f"Starting in {self.grace_period} seconds...")
            self.grace_period -= 1
            self.after(1000, self.update_grace_period)
        else:
            # Load the current problem and start the timer
            self.load_current_problem()
            self.update_navigation_buttons()
            self.start_timer()

    def start_timer(self):
        """Start the timer countdown after the grace period."""
        self.update_timer()

    def update_timer(self):
        if self.is_destroying:
            return
            
        if self.test_type != "timed":
            return
            
        # Additional safety check for destroyed windows
        try:
            if not self.winfo_exists():
                return
        except:
            return
            
        hours = self.remaining_time // 3600
        minutes = (self.remaining_time % 3600) // 60
        seconds = self.remaining_time % 60
        
        self.timer_label.config(text=f"Time Remaining: {hours:02d}:{minutes:02d}:{seconds:02d}")
        
        if self.remaining_time > 0:
            self.remaining_time -= 1
            self.after(1000, self.update_timer)
        else:
            messagebox.showinfo("Time's Up", "Your exam session has ended!")
            # Save exam results before returning to dashboard
            self.submit_exam()

    def return_to_dashboard(self):
        self.is_destroying = True
        self.destroy()
        dashboard = Dashboard()
        dashboard.mainloop()

    def open_reference_manual(self):
        # Create a new window for the PDF viewer
        viewer_window = tk.Toplevel(self)
        viewer_window.title("PDF Viewer")
        viewer_window.geometry("800x600")
        
        # Create a PDF viewer without a default PDF
        from simulator_files.pdf_viewer import PDFViewer
        viewer = PDFViewer(viewer_window)
        viewer.pack(fill=tk.BOTH, expand=True)
        
        # Make the window modal
        self.wait_window(viewer_window)

    def update_navigation_buttons(self):
        """Update the state of navigation buttons based on current question."""
        # Only enable navigation if exam has started
        if not self.exam_started and not self.pdf_loaded:
            self.prev_btn.configure(state="disabled")
            self.next_btn.configure(state="disabled")
            return
            
        # Check if problem manager is working
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            self.prev_btn.configure(state="disabled")
            self.next_btn.configure(state="disabled")
            return
            
        try:
            # Update Previous button
            current_index = getattr(self.problem_manager, 'current_index', 0)
            if current_index > 0:
                self.prev_btn.configure(state="normal")
            else:
                self.prev_btn.configure(state="disabled")
                
            # Update Next/Submit button
            total_problems = self.problem_manager.total_problems()
            if current_index < total_problems - 1:
                self.next_btn.configure(text="Next Question")
                self.next_btn.configure(state="normal")
            else:
                self.next_btn.configure(text="Submit Exam")
                self.next_btn.configure(state="normal")
        except Exception as e:
            print(f"Error updating navigation buttons: {e}")
            self.prev_btn.configure(state="disabled")
            self.next_btn.configure(state="disabled")

    def check_exam_completion(self):
        """Check if all questions are answered and show appropriate message."""
        # Check if problem manager is working
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            messagebox.showerror("Error", "Problem manager is not available.")
            return
            
        try:
            total_problems = self.problem_manager.total_problems()
            if total_problems <= 0:
                messagebox.showerror("Error", "No problems available.")
                return
                
            # Check for unanswered questions
            unanswered = []
            for i in range(total_problems):
                if i not in self.user_answers:
                    unanswered.append(i + 1)  # Add 1 to make it 1-based for user display
            
            # Check for flagged questions
            flagged = [i + 1 for i in self.flagged_questions]  # Add 1 to make it 1-based
            
            # Create message
            message = []
            if unanswered:
                message.append(f"You have {'one unanswered question' if len(unanswered) == 1 else f'{len(unanswered)} unanswered questions'}")
            if flagged:
                message.append(f"You have {'one flagged question' if len(flagged) == 1 else f'{len(flagged)} flagged questions'}")
            
            if not message:
                message.append("All questions have been answered and none are flagged.")
            
            message.append("\nAre you sure you want to submit?")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error checking exam completion: {str(e)}")
            return
        
        # Show message
        message_window = tk.Toplevel(self)
        message_window.title("Exam Completion Check")
        
        # Create message label
        msg_label = ttk.Label(message_window, text="\n".join(message), wraplength=400)
        msg_label.pack(padx=20, pady=20)
        
        # Add buttons
        button_frame = ttk.Frame(message_window)
        button_frame.pack(pady=10)
        
        if unanswered or flagged:
            ttk.Button(button_frame, text="Yes, submit exam", command=lambda: [message_window.destroy(), self.submit_exam()]).pack(side=tk.LEFT, padx=5)
            ttk.Button(button_frame, text="No, review answers", command=message_window.destroy).pack(side=tk.LEFT, padx=5)
            
        else:
            ttk.Button(button_frame, text="Submit Exam", command=lambda: [message_window.destroy(), self.submit_exam()]).pack(padx=5)
        
        # Center the window
        message_window.update_idletasks()
        width = message_window.winfo_width()
        height = message_window.winfo_height()
        x = (message_window.winfo_screenwidth() // 2) - (width // 2)
        y = (message_window.winfo_screenheight() // 2) - (height // 2)
        message_window.geometry(f'{width}x{height}+{x}+{y}')
        
        # Make window modal
        message_window.transient(self)
        message_window.grab_set()

    def submit_exam(self):
        # Calculate score
        correct_answers = 0
        
        # Check if problem manager is working
        if not hasattr(self, 'problem_manager') or self.problem_manager is None:
            messagebox.showerror("Error", "Problem manager is not available.")
            return
            
        total_questions = self.problem_manager.total_problems()
        
        # Prevent division by zero
        if total_questions == 0:
            messagebox.showerror("Error", "No problems available. Please check your problem manager configuration.")
            return
        
        for index, answer in self.user_answers.items():
            if (hasattr(self.problem_manager, 'problems') and 
                self.problem_manager.problems and 
                index < len(self.problem_manager.problems)):
                problem = self.problem_manager.problems[index]
                # Handle both Problem and FirestoreStorageProblem objects
                if hasattr(problem, 'correct_answer'):
                    correct_answer_index = ord(problem.correct_answer) - ord('A')
                    if 0 <= correct_answer_index < len(problem.choices):
                        if answer == problem.choices[correct_answer_index]:
                            correct_answers += 1
                else:
                    # Fallback for different problem object types
                    print(f"Warning: Problem {index} has unexpected structure")
            else:
                print(f"Warning: Problem {index} not available in problem manager")
        
        percentage = (correct_answers / total_questions) * 100
        
        # Calculate time taken
        time_taken = time.time() - self.start_time
        
        # Save exam statistics
        exam_stats = ExamStats()
        exam_stats.add_result(
            num_questions=total_questions,
            score=percentage,
            time_taken=time_taken,
            test_type=self.test_type
        )
        
        # Show results
        message = f"Exam Results:\n\n"
        message += f"Correct Answers: {correct_answers}/{total_questions}\n"
        message += f"Score: {percentage:.1f}%\n"
        message += f"Time Taken: {time_taken/60:.1f} minutes\n"
        if self.flagged_questions:
            message += f"\nYou flagged {len(self.flagged_questions)} question(s) for review."
        
        # Clear paused exam file if it exists
        state_file = get_paused_exam_path()
        if os.path.exists(state_file):
            os.remove(state_file)
        
        messagebox.showinfo("Exam Results", message)
        self.return_to_dashboard()

    def pause_exam(self):
        """Pause the exam and return to dashboard"""
        # Create pause confirmation dialog
        pause_window = tk.Toplevel(self)
        pause_window.title("Pause Exam")
        pause_window.geometry("400x200")
        pause_window.transient(self)
        pause_window.grab_set()
        
        # Center the window
        pause_window.update_idletasks()
        width = pause_window.winfo_width()
        height = pause_window.winfo_height()
        x = (pause_window.winfo_screenwidth() // 2) - (width // 2)
        y = (pause_window.winfo_screenheight() // 2) - (height // 2)
        pause_window.geometry(f'{width}x{height}+{x}+{y}')
        
        # Add message
        message_label = ttk.Label(pause_window, 
                                text="If you would like to pause the practice exam, click \"OK\". You can resume it at any time.",
                                wraplength=350,
                                justify='center',
                                font=('Arial', 11))
        message_label.pack(pady=30)
        
        # Add buttons
        button_frame = ttk.Frame(pause_window)
        button_frame.pack(pady=20)
        
        ok_button = ttk.Button(button_frame, text="OK", command=lambda: self.save_and_pause_exam(pause_window))
        ok_button.pack(side=tk.LEFT, padx=10)
        
        continue_button = ttk.Button(button_frame, text="Continue Exam", command=pause_window.destroy)
        continue_button.pack(side=tk.LEFT, padx=10)

    def save_and_pause_exam(self, pause_window):
        """Save exam state and return to dashboard"""
        # Calculate remaining time if timed
        remaining_time = None
        if self.test_type == "timed":
            remaining_time = self.remaining_time
        
        # Save exam state
        problems_data = []
        if (hasattr(self.problem_manager, 'problems') and 
            self.problem_manager.problems):
            problems_data = [(p.number, p.category, p.question, p.media, p.choices, p.correct_answer, p.media_size) for p in self.problem_manager.problems]
        
        exam_state = {
            'test_type': self.test_type,
            'num_questions': self.num_questions,
            'current_index': getattr(self.problem_manager, 'current_index', 0),
            'user_answers': self.user_answers,
            'answered_questions': list(self.answered_questions),
            'flagged_questions': list(self.flagged_questions),
            'remaining_time': remaining_time,
            'start_time': self.start_time,
            'selected_categories': getattr(self.problem_manager, 'selected_categories', []),
            'problems': problems_data
        }
        
        # Save to file
        import json
        state_file = get_paused_exam_path()
        with open(state_file, 'w') as f:
            json.dump(exam_state, f)
        
        # Close pause window if provided and return to dashboard
        if pause_window:
            pause_window.destroy()
        self.return_to_dashboard()

    def show_pdf_requirement_message(self):
        """Show message requiring PDF to be loaded before exam starts"""
        # Debug logging
        with open(get_debug_log_path(), "a") as f:
            f.write("show_pdf_requirement_message called\n")
        
        # Clear the problem text area
        self.problem_text.delete(1.0, tk.END)
        
        # Display the requirement message - different for resumed exams
        if hasattr(self, 'remaining_time') and self.remaining_time > 0:
            # This is a resumed timed exam
            message = "Please load a PDF of the Reference Manual to begin."
        else:
            # This is a new exam
            message = "Please load a PDF of the Reference Manual to begin."
            
        self.problem_text.insert(tk.END, message)
        self.problem_text.tag_configure("center", justify="center")
        self.problem_text.tag_add("center", "1.0", "end")
        
        # Disable navigation buttons until PDF is loaded
        self.next_btn.config(state="disabled")
        self.prev_btn.config(state="disabled")
        
        # Debug logging
        with open(get_debug_log_path(), "a") as f:
            f.write(f"PDF requirement message displayed: {message}\n")
        
    def on_pdf_loaded(self):
        """Called when a PDF is loaded in the viewer"""
        if not self.pdf_loaded:
            self.pdf_loaded = True
            self.start_exam_after_pdf_load()
    
    def start_exam_after_pdf_load(self):
        """Start the exam after PDF is loaded"""
        self.exam_started = True
        
        if self.test_type == "timed":
            # Start the grace period countdown
            self.update_grace_period()
        else:
            # For untimed exams, start immediately (no grace period)
            self.load_current_problem()
            self.update_navigation_buttons()

    def on_closing(self):
        """Handle window close event with confirmation dialog"""
        # Prevent the default window closing behavior
        # We'll handle the closing manually based on user choice
        
        # Create confirmation dialog
        confirm_window = tk.Toplevel(self)
        confirm_window.title("Exit Confirmation")
        confirm_window.geometry("400x200")
        confirm_window.resizable(False, False)
        
        # Make window modal
        confirm_window.transient(self)
        confirm_window.grab_set()
        
        # Center the window
        confirm_window.update_idletasks()
        x = (confirm_window.winfo_screenwidth() // 2) - (400 // 2)
        y = (confirm_window.winfo_screenheight() // 2) - (200 // 2)
        confirm_window.geometry(f'400x200+{x}+{y}')
        
        # Message
        message_label = ttk.Label(confirm_window, 
                                text="Do you want to pause your exam and return to the dashboard?",
                                font=('Arial', 12),
                                wraplength=350,
                                justify='center')
        message_label.pack(pady=20)
        
        # Button frame
        button_frame = ttk.Frame(confirm_window)
        button_frame.pack(pady=20)
        
        # No button (close dialog and keep exam running)
        no_btn = ttk.Button(button_frame, 
                           text="No, Continue Exam", 
                           command=confirm_window.destroy,
                           width=20)
        no_btn.pack(side=tk.LEFT, padx=5)
        
        # Pause exam button
        pause_btn = ttk.Button(button_frame, 
                              text="Yes, Pause Exam", 
                              command=lambda: self.handle_pause_exam(confirm_window),
                              width=20)
        pause_btn.pack(side=tk.LEFT, padx=5)
        
        # Focus on No button by default
        no_btn.focus_set()
        
        # Bind Enter key to No button and Escape key to close dialog
        confirm_window.bind("<Return>", lambda e: confirm_window.destroy())
        confirm_window.bind("<Escape>", lambda e: confirm_window.destroy())
        
        # Prevent the main window from closing by default
        # The user must make a choice through the dialog

    def handle_pause_exam(self, confirm_window):
        """Handle the pause exam action from the close confirmation dialog"""
        # Close the confirmation dialog first
        confirm_window.destroy()
        
        # Then pause the exam and return to dashboard
        self.pause_and_return_to_dashboard()

    def pause_and_return_to_dashboard(self):
        """Pause the exam and return to dashboard"""
        # Save the exam state
        self.save_and_pause_exam(None)  # Pass None since we don't have a pause window
        
        # Set destroying flag and return to dashboard
        self.is_destroying = True
        self.return_to_dashboard()

    def on_answer_selected(self, *args):
        current_index = self.problem_manager.current_index
        selected_answer = self.answer_var.get()
        if selected_answer and selected_answer != "_unset_":
            self.answered_questions.add(current_index)
            self.user_answers[current_index] = selected_answer
        elif current_index in self.user_answers:
            del self.user_answers[current_index]

    def bind_keyboard_shortcuts(self):
        """Bind keyboard shortcuts for better user experience - DISABLED to preserve PDF viewer functionality"""
        # All keyboard shortcuts have been disabled to prevent interference with PDF viewer navigation
        # Users must use the GUI buttons for:
        # - Navigation (Previous/Next Question buttons)
        # - Flagging questions (Flag for Review button)
        # - Opening calculator (Calculator button)
        # - Opening question navigator (::: button)
        # - Answer selection (radio buttons)
        # - Exam submission (Next Question/Submit Exam button)
        
        # Only essential shortcuts remain for safety:
        # Return to dashboard shortcut (Ctrl+Q) - kept for emergency exit
        self.bind("<Control-q>", lambda event: self.return_to_dashboard())
        self.bind("<Control-Q>", lambda event: self.return_to_dashboard())
    
    def create_menu_bar(self):
        """Create the application menu bar with update functionality"""
        menubar = Menu(self)
        self.config(menu=menubar)
        
        # File menu removed as requested
        
        # Help menu
        help_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        
        # Update menu (if updates are available)
        if hasattr(self, 'update_manager') and self.update_manager:
            update_menu = Menu(menubar, tearoff=0)
            menubar.add_cascade(label="Updates", menu=update_menu)
            update_menu.add_command(label="Check for Updates", command=self.check_for_updates)
            update_menu.add_command(label="Update Settings", command=self.show_update_settings)
    
    def check_for_updates(self):
        """Show the update dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            show_simple_update_dialog(self, self.update_manager)
        else:
            messagebox.showinfo("Updates", "Update functionality is not available.")
    
    def show_update_settings(self):
        """Show update settings dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            self._show_update_settings_dialog()
        else:
            messagebox.showinfo("Update Settings", "Update functionality is not available.")
    
    def _show_update_settings_dialog(self):
        """Show update settings dialog"""
        settings_dialog = tk.Toplevel(self)
        settings_dialog.title("Update Settings")
        settings_dialog.geometry("500x400")
        settings_dialog.transient(self)
        settings_dialog.grab_set()
        
        # Center the dialog
        settings_dialog.update_idletasks()
        x = (settings_dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (settings_dialog.winfo_screenheight() // 2) - (400 // 2)
        settings_dialog.geometry(f'500x400+{x}+{y}')
        
        # Title
        title_label = ttk.Label(settings_dialog, text="Update Settings", font=('Arial', 14, 'bold'))
        title_label.pack(pady=20)
        
        # Version info
        version_info = self.update_manager.get_version_info()
        version_frame = ttk.LabelFrame(settings_dialog, text="Version Information")
        version_frame.pack(pady=10, padx=20, fill='x')
        
        ttk.Label(version_frame, text=f"Current Version: {version_info['current_version']}").pack(anchor='w', padx=10, pady=5)
        if version_info['latest_version']:
            ttk.Label(version_frame, text=f"Latest Version: {version_info['latest_version']}").pack(anchor='w', padx=10, pady=5)
        
        # Update status
        status_frame = ttk.LabelFrame(settings_dialog, text="Update Status")
        status_frame.pack(pady=10, padx=20, fill='x')
        
        if version_info['update_available']:
            status_label = ttk.Label(status_frame, text="Update Available!", foreground='green', font=('Arial', 10, 'bold'))
        else:
            status_label = ttk.Label(status_frame, text="No updates available", foreground='blue')
        status_label.pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(settings_dialog)
        button_frame.pack(pady=20)
        
        if version_info['update_available']:
            download_btn = ttk.Button(button_frame, text="Download Update", 
                                    command=lambda: self._download_update(settings_dialog))
            download_btn.pack(side='left', padx=5)
        
        check_btn = ttk.Button(button_frame, text="Check for Updates", 
                              command=lambda: self._check_updates_from_settings(settings_dialog))
        check_btn.pack(side='left', padx=5)
        
        close_btn = ttk.Button(button_frame, text="Close", command=settings_dialog.destroy)
        close_btn.pack(side='left', padx=5)
    
    def _download_update(self, dialog):
        """Download update from settings dialog"""
        def progress_callback(progress):
            # Update progress in dialog
            pass
        
        def completion_callback(success, message):
            if success:
                messagebox.showinfo("Download Complete", message)
                dialog.destroy()
            else:
                messagebox.showerror("Download Failed", message)
        
        self.update_manager.download_update(progress_callback, completion_callback)
    
    def _check_updates_from_settings(self, dialog):
        """Check for updates from settings dialog"""
        def update_callback(update_available, message):
            if update_available:
                messagebox.showinfo("Updates", message)
                dialog.destroy()
                self._show_update_settings_dialog()
            else:
                messagebox.showinfo("Updates", message)
        
        self.update_manager.check_for_updates(update_callback)
    
    def show_about(self):
        """Show about dialog with version information"""
        app_info = get_app_info()
        about_text = f"""
{app_info['name']} v{app_info['version']}

{app_info['description']}

This software helps you prepare for the FE Civil exam
by providing practice problems in an environment similar
to the testing center.

For support or questions, please contact the development team.

This software is not affilated with NCEES.
        """
        
        messagebox.showinfo("About", about_text.strip())
    
    def check_updates_on_startup(self):
        """Check for updates on application startup"""
        if hasattr(self, 'update_manager') and self.update_manager:
            # Check for updates in background
            def update_callback(update_available, message):
                if update_available:
                    # Show notification about available update
                    self.after(1000, lambda: self._show_update_notification(message))
            
            self.update_manager.check_for_updates(update_callback)
    
    def _show_update_notification(self, message):
        """Show update notification"""
        # Create a simple notification window
        notification = tk.Toplevel(self)
        notification.title("Update Available")
        notification.geometry("300x150")
        notification.transient(self)
        notification.grab_set()
        
        # Center the notification
        notification.update_idletasks()
        x = (notification.winfo_screenwidth() // 2) - (300 // 2)
        y = (notification.winfo_screenheight() // 2) - (150 // 2)
        notification.geometry(f'300x150+{x}+{y}')
        
        # Content
        ttk.Label(notification, text="Update Available!", font=('Arial', 12, 'bold')).pack(pady=20)
        ttk.Label(notification, text=message, font=('Arial', 10)).pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(notification)
        button_frame.pack(pady=20)
        
        ttk.Button(button_frame, text="Update Now", 
                  command=lambda: [notification.destroy(), self.check_for_updates()]).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Later", command=notification.destroy).pack(side='left', padx=5)
    
    def select_answer_by_key(self, answer_key):
        """Select an answer using keyboard shortcuts"""
        # Find the index of the answer (A=0, B=1, C=2, D=3)
        answer_index = ord(answer_key) - ord('A')
        
        # Check if the answer index is valid
        if 0 <= answer_index < len(self.answer_buttons):
            # Set the answer variable
            self.answer_var.set(self.answer_buttons[answer_index]['text'])
            
            # Update the UI to reflect the selection
            self.update_answer_selection()
    
    def update_answer_selection(self):
        """Update the UI to reflect the current answer selection"""
        # Get the current problem
        problem = self.problem_manager.get_current_problem()
        if not problem:
            # No problem available - can't update answer selection
            return
            
        current_index = self.problem_manager.current_index
        
        # Store the answer
        selected_answer = self.answer_var.get()
        if selected_answer:
            self.user_answers[current_index] = selected_answer
            self.answered_questions.add(current_index)
        else:
            # Remove from answered questions if no answer selected
            if current_index in self.user_answers:
                del self.user_answers[current_index]
            self.answered_questions.discard(current_index)
        
        # Update progress
        self.update_progress()

    def create_menu_bar(self):
        """Create the application menu bar with update functionality"""
        menubar = Menu(self)
        self.config(menu=menubar)
        
        # File menu removed as requested
        
        # Help menu
        help_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        
        # Update menu (if updates are available)
        if hasattr(self, 'update_manager') and self.update_manager:
            update_menu = Menu(menubar, tearoff=0)
            menubar.add_cascade(label="Updates", menu=update_menu)
            update_menu.add_command(label="Check for Updates", command=self.check_for_updates)
            update_menu.add_command(label="Update Settings", command=self.show_update_settings)
    
    def check_for_updates(self):
        """Show the update dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            show_simple_update_dialog(self, self.update_manager)
        else:
            messagebox.showinfo("Updates", "Update functionality is not available.")
    
    def show_update_settings(self):
        """Show update settings dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            self._show_update_settings_dialog()
        else:
            messagebox.showinfo("Update Settings", "Update functionality is not available.")
    
    def _show_update_settings_dialog(self):
        """Show update settings dialog"""
        settings_dialog = tk.Toplevel(self)
        settings_dialog.title("Update Settings")
        settings_dialog.geometry("500x400")
        settings_dialog.transient(self)
        settings_dialog.grab_set()
        
        # Center the dialog
        settings_dialog.update_idletasks()
        x = (settings_dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (settings_dialog.winfo_screenheight() // 2) - (400 // 2)
        settings_dialog.geometry(f'500x400+{x}+{y}')
        
        # Title
        title_label = ttk.Label(settings_dialog, text="Update Settings", font=('Arial', 14, 'bold'))
        title_label.pack(pady=20)
        
        # Version info
        version_info = self.update_manager.get_version_info()
        version_frame = ttk.LabelFrame(settings_dialog, text="Version Information")
        version_frame.pack(pady=10, padx=20, fill='x')
        
        ttk.Label(version_frame, text=f"Current Version: {version_info['current_version']}").pack(anchor='w', padx=10, pady=5)
        if version_info['latest_version']:
            ttk.Label(version_frame, text=f"Latest Version: {version_info['latest_version']}").pack(anchor='w', padx=10, pady=5)
        
        # Update status
        status_frame = ttk.LabelFrame(settings_dialog, text="Update Status")
        status_frame.pack(pady=10, padx=20, fill='x')
        
        if version_info['update_available']:
            status_label = ttk.Label(status_frame, text="Update Available!", foreground='green', font=('Arial', 10, 'bold'))
        else:
            status_label = ttk.Label(status_frame, text="No updates available", foreground='blue')
        status_label.pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(settings_dialog)
        button_frame.pack(pady=20)
        
        if version_info['update_available']:
            download_btn = ttk.Button(button_frame, text="Download Update", 
                                    command=lambda: self._download_update(settings_dialog))
            download_btn.pack(side='left', padx=5)
        
        check_btn = ttk.Button(button_frame, text="Check for Updates", 
                              command=lambda: self._check_updates_from_settings(settings_dialog))
        check_btn.pack(side='left', padx=5)
        
        close_btn = ttk.Button(button_frame, text="Close", command=settings_dialog.destroy)
        close_btn.pack(side='left', padx=5)
    
    def _download_update(self, dialog):
        """Download update from settings dialog"""
        def progress_callback(progress):
            # Update progress in dialog
            pass
        
        def completion_callback(success, message):
            if success:
                messagebox.showinfo("Download Complete", message)
                dialog.destroy()
            else:
                messagebox.showerror("Download Failed", message)
        
        self.update_manager.download_update(progress_callback, completion_callback)
    
    def _check_updates_from_settings(self, dialog):
        """Check for updates from settings dialog"""
        def update_callback(update_available, message):
            if update_available:
                messagebox.showinfo("Updates", message)
                dialog.destroy()
                self._show_update_settings_dialog()
            else:
                messagebox.showinfo("Updates", message)
        
        self.update_manager.check_for_updates(update_callback)
    
    def show_about(self):
        """Show about dialog with version information"""
        app_info = get_app_info()
        about_text = f"""
{app_info['name']} v{app_info['version']}

{app_info['description']}

This software helps you prepare for the FE Civil exam
by providing practice problems in an environment similar
to the testing center.

For support or questions, please contact the development team.

This software is not affilated with NCEES.
        """
        
        messagebox.showinfo("About", about_text.strip())
    
    def check_updates_on_startup(self):
        """Check for updates on application startup"""
        if hasattr(self, 'update_manager') and self.update_manager:
            # Check for updates in background
            def update_callback(update_available, message):
                if update_available:
                    # Show notification about available update
                    self.after(1000, lambda: self._show_update_notification(message))
            
            self.update_manager.check_for_updates(update_callback)
    
    def _show_update_notification(self, message):
        """Show update notification"""
        # Create a simple notification window
        notification = tk.Toplevel(self)
        notification.title("Update Available")
        notification.geometry("300x150")
        notification.transient(self)
        notification.grab_set()
        
        # Center the notification
        notification.update_idletasks()
        x = (notification.winfo_screenwidth() // 2) - (300 // 2)
        y = (notification.winfo_screenheight() // 2) - (150 // 2)
        notification.geometry(f'300x150+{x}+{y}')
        
        # Content
        ttk.Label(notification, text="Update Available!", font=('Arial', 12, 'bold')).pack(pady=20)
        ttk.Label(notification, text=message, font=('Arial', 10)).pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(notification)
        button_frame.pack(pady=20)
        
        ttk.Button(button_frame, text="Update Now", 
                  command=lambda: [notification.destroy(), self.check_for_updates()]).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Later", command=notification.destroy).pack(side='left', padx=5)

class Dashboard(tk.Tk):
    def __init__(self):
        with open(get_debug_log_path(), "a") as f:
            f.write("Initializing Dashboard...\n")
        super().__init__()
        self.title("FE Exam Practice Dashboard")
        self.state('zoomed')
        
        # Load exam statistics
        self.exam_stats = ExamStats()
        
        # Configure the main window grid
        self.grid_columnconfigure(0, weight=1)  # Left pane
        self.grid_columnconfigure(1, weight=1)  # Right pane
        self.grid_rowconfigure(0, weight=1)  # Main content
        self.grid_rowconfigure(1, weight=0)  # Paused test section
        self.grid_rowconfigure(2, weight=0)  # Review section
        self.grid_rowconfigure(3, weight=0)  # Button row
        
        # Create left pane (Statistics)
        self.create_stats_pane()
        
        # Create right pane (Test Settings)
        self.create_settings_pane()
        
        # Create paused test section
        self.create_paused_test_section()
        
        # Create review section
        self.create_review_section()
        
        # Create start button
        self.create_start_button()
        
        # Initialize update manager
        app_info = get_app_info()
        self.update_manager = create_simple_updater(
            app_name=app_info['name'],
            current_version=app_info['version']
        )
        
        # Create menu bar
        self.create_menu_bar()
        
        # Check for updates on startup (if enabled)
        self.check_updates_on_startup()
        
        # Initialize the question dropdown with current category selection
        self.update_question_dropdown()

    def create_menu_bar(self):
        """Create the application menu bar with update functionality"""
        menubar = Menu(self)
        self.config(menu=menubar)
        
        # File menu removed as requested
        
        # Help menu
        help_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        
        # Update menu (if updates are available)
        if hasattr(self, 'update_manager') and self.update_manager:
            update_menu = Menu(menubar, tearoff=0)
            menubar.add_cascade(label="Updates", menu=update_menu)
            update_menu.add_command(label="Check for Updates", command=self.check_for_updates)
            update_menu.add_command(label="Update Settings", command=self.show_update_settings)
    
    def check_for_updates(self):
        """Show the update dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            show_simple_update_dialog(self, self.update_manager)
        else:
            messagebox.showinfo("Updates", "Update functionality is not available.")
    
    def show_update_settings(self):
        """Show update settings dialog"""
        if hasattr(self, 'update_manager') and self.update_manager:
            self._show_update_settings_dialog()
        else:
            messagebox.showinfo("Update Settings", "Update functionality is not available.")
    
    def _show_update_settings_dialog(self):
        """Show update settings dialog"""
        settings_dialog = tk.Toplevel(self)
        settings_dialog.title("Update Settings")
        settings_dialog.geometry("500x400")
        settings_dialog.transient(self)
        settings_dialog.grab_set()
        
        # Center the dialog
        settings_dialog.update_idletasks()
        x = (settings_dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (settings_dialog.winfo_screenheight() // 2) - (400 // 2)
        settings_dialog.geometry(f'500x400+{x}+{y}')
        
        # Title
        title_label = ttk.Label(settings_dialog, text="Update Settings", font=('Arial', 14, 'bold'))
        title_label.pack(pady=20)
        
        # Version info
        version_info = self.update_manager.get_version_info()
        version_frame = ttk.LabelFrame(settings_dialog, text="Version Information")
        version_frame.pack(pady=10, padx=20, fill='x')
        
        ttk.Label(version_frame, text=f"Current Version: {version_info['current_version']}").pack(anchor='w', padx=10, pady=5)
        if version_info['latest_version']:
            ttk.Label(version_frame, text=f"Latest Version: {version_info['latest_version']}").pack(anchor='w', padx=10, pady=5)
        
        # Update status
        status_frame = ttk.LabelFrame(settings_dialog, text="Update Status")
        status_frame.pack(pady=10, padx=20, fill='x')
        
        if version_info['update_available']:
            status_label = ttk.Label(status_frame, text="Update Available!", foreground='green', font=('Arial', 10, 'bold'))
        else:
            status_label = ttk.Label(status_frame, text="No updates available", foreground='blue')
        status_label.pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(settings_dialog)
        button_frame.pack(pady=20)
        
        if version_info['update_available']:
            download_btn = ttk.Button(button_frame, text="Download Update", 
                                    command=lambda: self._download_update(settings_dialog))
            download_btn.pack(side='left', padx=5)
        
        check_btn = ttk.Button(button_frame, text="Check for Updates", 
                              command=lambda: self._check_updates_from_settings(settings_dialog))
        check_btn.pack(side='left', padx=5)
        
        close_btn = ttk.Button(button_frame, text="Close", command=settings_dialog.destroy)
        close_btn.pack(side='left', padx=5)
    
    def _download_update(self, dialog):
        """Download update from settings dialog"""
        def progress_callback(progress):
            # Update progress in dialog
            pass
        
        def completion_callback(success, message):
            if success:
                messagebox.showinfo("Download Complete", message)
                dialog.destroy()
            else:
                messagebox.showerror("Download Failed", message)
        
        self.update_manager.download_update(progress_callback, completion_callback)
    
    def _check_updates_from_settings(self, dialog):
        """Check for updates from settings dialog"""
        def update_callback(update_available, message):
            if update_available:
                messagebox.showinfo("Updates", message)
                dialog.destroy()
                self._show_update_settings_dialog()
            else:
                messagebox.showinfo("Updates", message)
        
        self.update_manager.check_for_updates(update_callback)
    
    def show_about(self):
        """Show about dialog with version information"""
        app_info = get_app_info()
        about_text = f"""
{app_info['name']} v{app_info['version']}

{app_info['description']}

This software helps you prepare for the FE Civil exam
by providing practice problems in an environment similar
to the testing center.

For support or questions, please contact the development team.

This software is not affilated with NCEES.
        """
        
        messagebox.showinfo("About", about_text.strip())
    
    def check_updates_on_startup(self):
        """Check for updates on application startup"""
        if hasattr(self, 'update_manager') and self.update_manager:
            # Check for updates in background
            def update_callback(update_available, message):
                if update_available:
                    # Show notification about available update
                    self.after(1000, lambda: self._show_update_notification(message))
            
            self.update_manager.check_for_updates(update_callback)
    
    def _show_update_notification(self, message):
        """Show update notification"""
        # Create a simple notification window
        notification = tk.Toplevel(self)
        notification.title("Update Available")
        notification.geometry("300x150")
        notification.transient(self)
        notification.grab_set()
        
        # Center the notification
        notification.update_idletasks()
        x = (notification.winfo_screenwidth() // 2) - (300 // 2)
        y = (notification.winfo_screenheight() // 2) - (150 // 2)
        notification.geometry(f'300x150+{x}+{y}')
        
        # Content
        ttk.Label(notification, text="Update Available!", font=('Arial', 12, 'bold')).pack(pady=20)
        ttk.Label(notification, text=message, font=('Arial', 10)).pack(pady=10)
        
        # Buttons
        button_frame = ttk.Frame(notification)
        button_frame.pack(pady=20)
        
        ttk.Button(button_frame, text="Update Now", 
                  command=lambda: [notification.destroy(), self.check_for_updates()]).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Later", command=notification.destroy).pack(side='left', padx=5)

    def create_paused_test_section(self):
        """Create a section for paused test information"""
        # Check if there's a paused exam
        import json
        state_file = get_paused_exam_path()
        
        if not os.path.exists(state_file):
            return  # No paused exam, don't create the section
        
        try:
            with open(state_file, 'r') as f:
                exam_state = json.load(f)
        except:
            return  # Invalid file, don't create the section
        
        # Create the paused test frame
        paused_frame = ttk.LabelFrame(self, text="Paused Test")
        paused_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 10))
        
        # Calculate exam progress
        total_questions = exam_state['num_questions']
        answered_questions = len(exam_state['user_answers'])
        remaining_questions = total_questions - answered_questions
        
        # Create info labels
        info_frame = ttk.Frame(paused_frame)
        info_frame.pack(fill="x", padx=10, pady=10)
        
        # Test type and questions info
        test_type_text = "Timed" if exam_state['test_type'] == "timed" else "Non-timed"
        ttk.Label(info_frame, text=f"Test Type: {test_type_text}").pack(anchor="w")
        ttk.Label(info_frame, text=f"Total Questions: {total_questions}").pack(anchor="w")
        ttk.Label(info_frame, text=f"Questions Remaining: {remaining_questions}").pack(anchor="w")
        
        # Time remaining info (if timed)
        if exam_state['test_type'] == "timed" and exam_state['remaining_time'] is not None:
            remaining_time = exam_state['remaining_time']
            hours = remaining_time // 3600
            minutes = (remaining_time % 3600) // 60
            seconds = remaining_time % 60
            time_text = f"Time Remaining: {hours:02d}:{minutes:02d}:{seconds:02d}"
            ttk.Label(info_frame, text=time_text).pack(anchor="w")
        
        # Create button frame for resume and end exam buttons
        button_frame = ttk.Frame(paused_frame)
        button_frame.pack(pady=(10, 10))
        
        # Resume button
        resume_button = tk.Button(
            button_frame,
            text="▶️ Resume Exam",
            font=('Arial', 12, 'bold'),
            bg='#007bff',  # Blue
            fg='white',
            activebackground='#0056b3',
            activeforeground='white',
            relief=tk.RAISED,
            padx=15,
            pady=8,
            command=self.resume_exam
        )
        resume_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # End Exam button
        end_exam_button = tk.Button(
            button_frame,
            text="❌ End Exam",
            font=('Arial', 12, 'bold'),
            bg='#dc3545',  # Red
            fg='white',
            activebackground='#c82333',
            activeforeground='white',
            relief=tk.RAISED,
            padx=15,
            pady=8,
            command=self.end_paused_exam
        )
        end_exam_button.pack(side=tk.LEFT, padx=(10, 0))
        
        # Add hover effects for resume button
        def on_enter(e):
            resume_button['background'] = '#0056b3'
            
        def on_leave(e):
            resume_button['background'] = '#007bff'
            
        resume_button.bind("<Enter>", on_enter)
        resume_button.bind("<Leave>", on_leave)
        
        # Add hover effects for end exam button
        def on_enter_end(e):
            end_exam_button['background'] = '#c82333'
            
        def on_leave_end(e):
            end_exam_button['background'] = '#dc3545'
            
        end_exam_button.bind("<Enter>", on_enter_end)
        end_exam_button.bind("<Leave>", on_leave_end)

    def resume_exam(self):
        """Resume a paused exam"""
        import json
        state_file = get_paused_exam_path()
        
        try:
            with open(state_file, 'r') as f:
                exam_state = json.load(f)
        except:
            messagebox.showerror("Error", "Could not load paused exam data.")
            return
        
        # Close dashboard and create simulator with saved state
        self.destroy()
        exam = FEExamSimulator.from_saved_state(exam_state)
        exam.mainloop()

    def end_paused_exam(self):
        """End a paused exam and clear the paused exam data"""
        # Show confirmation dialog
        result = messagebox.askyesno(
            "End Paused Exam",
            "Are you sure you want to end this paused exam?\n\nAll your progress will be lost and cannot be recovered.",
            icon='warning'
        )
        
        if result:
            # Delete the paused exam file
            import json
            state_file = get_paused_exam_path()
            
            try:
                if os.path.exists(state_file):
                    os.remove(state_file)
                    messagebox.showinfo(
                        "Exam Ended",
                        "The paused exam has been ended successfully.\n\nAll progress has been cleared."
                    )
                    # Refresh the dashboard to remove the paused exam section
                    self.refresh_dashboard()
                else:
                    messagebox.showinfo(
                        "No Paused Exam",
                        "There is no paused exam to end."
                    )
            except Exception as e:
                messagebox.showerror(
                    "Error",
                    f"Failed to end the paused exam: {str(e)}"
                )

    def create_stats_pane(self):
        stats_frame = ttk.LabelFrame(self, text="Your Statistics")
        stats_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
        # Get statistics
        stats = self.exam_stats.get_statistics()
        
        # Statistics labels
        ttk.Label(stats_frame, text=f"Practice Exams Taken: {stats['exams_taken']}").pack(anchor="w", padx=10, pady=5)
        ttk.Label(stats_frame, text=f"Average Score: {stats['average_score']:.1f}%").pack(anchor="w", padx=10, pady=5)
        ttk.Label(stats_frame, text=f"Average Time per Question: {stats['average_time_per_question']/60:.1f} minutes").pack(anchor="w", padx=10, pady=5)
        
        # Add separator
        ttk.Separator(stats_frame, orient='horizontal').pack(fill='x', padx=10, pady=10)
        
        # Add exam history section
        history_label = ttk.Label(stats_frame, text="Previous Exams:", font=('Arial', 10, 'bold'))
        history_label.pack(anchor="w", padx=10, pady=(10, 5))
        
        # Create frame for the listbox and scrollbar
        list_frame = ttk.Frame(stats_frame)
        list_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Create listbox for exam history
        self.exam_history_listbox = tk.Listbox(
            list_frame,
            height=8,
            font=('Arial', 9),
            selectmode='none'  # Disable selection
        )
        self.exam_history_listbox.pack(side='left', fill='both', expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.exam_history_listbox.yview)
        scrollbar.pack(side='right', fill='y')
        self.exam_history_listbox.configure(yscrollcommand=scrollbar.set)
        
        # Populate the exam history
        self.populate_exam_history()
        
        # Add clear statistics button
        clear_button = tk.Button(
            stats_frame,
            text="Clear All Statistics",
            font=('Arial', 10),
            bg='#dc3545',  # Red
            fg='white',
            activebackground='#c82333',
            activeforeground='white',
            relief=tk.RAISED,
            padx=10,
            pady=5,
            command=self.clear_statistics
        )
        clear_button.pack(anchor="w", padx=10, pady=10)
        
        # Add hover effects for the clear button
        def on_enter_clear(e):
            clear_button['background'] = '#e74c3c'  # Lighter red on hover
            
        def on_leave_clear(e):
            clear_button['background'] = '#dc3545'  # Return to original red
            
        clear_button.bind("<Enter>", on_enter_clear)
        clear_button.bind("<Leave>", on_leave_clear)

    def populate_exam_history(self):
        """Populate the exam history listbox with previous exam results."""
        # Clear existing items
        self.exam_history_listbox.delete(0, tk.END)
        
        # Get exam results (most recent first)
        results = self.exam_stats.results[::-1]  # Reverse to show newest first
        
        if not results:
            self.exam_history_listbox.insert(tk.END, "No previous exams found.")
            return
        
        for result in results:
            # Format the date
            date_obj = datetime.strptime(result.date, "%Y-%m-%d %H:%M:%S")
            formatted_date = date_obj.strftime("%m/%d/%Y %I:%M %p")
            
            # Format time taken
            minutes = result.time_taken / 60
            time_str = f"{minutes:.1f} min"
            
            # Create the display string
            exam_info = f"{formatted_date} | {result.num_questions} Q | {result.score:.1f}% | {time_str} | {result.test_type}"
            
            self.exam_history_listbox.insert(tk.END, exam_info)

    def clear_statistics(self):
        """Clear all exam statistics with confirmation."""
        # Show confirmation dialog
        result = messagebox.askyesno(
            "Clear Statistics",
            "Are you sure you want to clear all exam statistics?\n\nThis action cannot be undone.",
            icon='warning'
        )
        
        if result:
            # Clear the statistics
            self.exam_stats.clear_statistics()
            
            # Show confirmation message
            messagebox.showinfo(
                "Statistics Cleared",
                "All exam statistics have been cleared successfully."
            )
            
            # Refresh the dashboard to show updated statistics
            self.refresh_dashboard()

    def refresh_dashboard(self):
        """Refresh the dashboard to show updated statistics."""
        # Store current category selections
        current_categories = {}
        if hasattr(self, 'category_vars'):
            current_categories = {category: var.get() for category, var in self.category_vars.items()}
        
        # Destroy current widgets and recreate them
        for widget in self.winfo_children():
            widget.destroy()
        
        # Recreate the dashboard
        self.grid_columnconfigure(0, weight=1)  # Left pane
        self.grid_columnconfigure(1, weight=1)  # Right pane
        self.grid_rowconfigure(0, weight=1)  # Main content
        self.grid_rowconfigure(1, weight=0)  # Paused test section
        self.grid_rowconfigure(2, weight=0)  # Review section
        self.grid_rowconfigure(3, weight=0)  # Button row
        
        # Create left pane (Statistics)
        self.create_stats_pane()
        
        # Create right pane (Test Settings)
        self.create_settings_pane()
        
        # Create paused test section
        self.create_paused_test_section()
        
        # Create review section
        self.create_review_section()
        
        # Restore category selections
        if hasattr(self, 'category_vars') and current_categories:
            for category, value in current_categories.items():
                if category in self.category_vars:
                    self.category_vars[category].set(value)
        
        # Create start button
        self.create_start_button()
        
        # Refresh exam history
        self.populate_exam_history()

    def create_settings_pane(self):
        settings_frame = ttk.LabelFrame(self, text="Test Settings")
        settings_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        
        # Configure grid for two columns
        settings_frame.grid_columnconfigure(0, weight=1)  # Left side (test type and questions)
        settings_frame.grid_columnconfigure(1, weight=1)  # Right side (categories)
        
        # Left side - Test type and number of questions
        left_frame = ttk.Frame(settings_frame)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        
        # Test type selection
        ttk.Label(left_frame, text="Test Type:").pack(anchor="w", padx=10, pady=5)
        self.test_type = tk.StringVar(value="timed")
        ttk.Radiobutton(left_frame, text="Timed Test", variable=self.test_type, value="timed").pack(anchor="w", padx=20)
        ttk.Radiobutton(left_frame, text="Non-timed Test", variable=self.test_type, value="non-timed").pack(anchor="w", padx=20)
        
        # Number of questions selection
        ttk.Label(left_frame, text="\nNumber of Questions:").pack(anchor="w", padx=10, pady=5)
        self.num_questions = tk.StringVar(value="5")
        self.question_choices = ttk.Combobox(left_frame, textvariable=self.num_questions, state="readonly")
        self.question_choices['values'] = tuple(range(10, 111, 10))  # 10 to 110 in steps of 10
        self.question_choices.pack(anchor="w", padx=20)
        
        # Right side - Category selection
        right_frame = ttk.Frame(settings_frame)
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        
        # Category selection
        ttk.Label(right_frame, text="Categories (Select all that apply):").pack(anchor="w", padx=10, pady=5)
        
        # Create frame for category checkboxes in two columns
        category_frame = ttk.Frame(right_frame)
        category_frame.pack(fill="x", padx=10, pady=5)
        
        # Define all FE exam categories (matching the CSV file names)
        self.categories = [
            "Math", "Ethics", "Econ", "Statics", "Dynamics", "Strength", 
            "Materials", "Fluids", "Surveying", "Envir", "Struc", 
            "Geotech", "Transp", "Constr"
        ]
        
        # Create category variables and checkboxes
        self.category_vars = {}
        for i, category in enumerate(self.categories):
            var = tk.BooleanVar(value=True)  # Default to selected
            self.category_vars[category] = var
            
            # Determine column (0 or 1) and row
            col = i % 2
            row = i // 2
            
            # Create checkbox with command to update question count
            cb = ttk.Checkbutton(
                category_frame, 
                text=category, 
                variable=var,
                command=self.update_question_dropdown
            )
            cb.grid(row=row, column=col, sticky="w", padx=(0, 20), pady=2)
        
        # Add "Select All" and "Clear All" buttons
        button_frame = ttk.Frame(right_frame)
        button_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Button(button_frame, text="Select All", command=self.select_all_categories).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Clear All", command=self.clear_all_categories).pack(side=tk.LEFT, padx=(0, 5))

    def create_review_section(self):
        """Create a section for users to leave reviews"""
        review_frame = ttk.LabelFrame(self, text="Leave a Review")
        review_frame.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 10))
        
        # Add description text
        description_text = "Help us improve The FE Simulator by sharing your feedback!"
        ttk.Label(review_frame, text=description_text, font=('Arial', 10)).pack(pady=(10, 1))
        
        # Create a frame for the review button
        button_frame = ttk.Frame(review_frame)
        button_frame.pack(pady=(5, 10))
        
        # Create the review button with a link-like appearance
        review_button = tk.Button(
            button_frame,
            text="📝 Leave a Review",
            font=('Arial', 11, 'bold'),
            bg='#007bff',  # Blue color for link-like appearance
            fg='white',
            activebackground='#0056b3',
            activeforeground='white',
            relief=tk.FLAT,
            padx=15,
            pady=8,
            cursor='hand2',  # Hand cursor to indicate it's clickable
            command=self.open_review_form
        )
        review_button.pack()
        
        # Add hover effects
        def on_enter(e):
            review_button['background'] = '#0056b3'
            
        def on_leave(e):
            review_button['background'] = '#007bff'
            
        review_button.bind("<Enter>", on_enter)
        review_button.bind("<Leave>", on_leave)

    def open_review_form(self):
        """Open the review form in the default web browser"""
        review_url = "https://veiled-cart-658.notion.site/2235f061bd4b80d3834ce1b84135ef82"
        try:
            webbrowser.open(review_url)
        except Exception as e:
            messagebox.showerror("Error", f"Could not open the review form. Please visit:\n{review_url}")

    def select_all_categories(self):
        """Select all category checkboxes"""
        for var in self.category_vars.values():
            var.set(True)
        self.update_question_dropdown()
    
    def clear_all_categories(self):
        """Clear all category checkboxes"""
        for var in self.category_vars.values():
            var.set(False)
        self.update_question_dropdown()
    
    def update_question_dropdown(self):
        """Update the question dropdown based on selected categories"""
        try:
            # Get selected categories
            selected_categories = [cat for cat, var in self.category_vars.items() if var.get()]
            
            # Create a temporary problem manager to count problems
            from simulator_files.firestore_storage_problem_manager_optimized import FirestoreStorageProblemManager
            # Use the same database selection logic as the simulator
            temp_manager = FirestoreStorageProblemManager(num_questions=110)  # Use max to get all problems
            
            # Count problems in selected categories
            if selected_categories:
                max_problems = temp_manager.count_problems_by_categories(selected_categories)
            else:
                max_problems = 0
            
            # Generate dropdown values based on selection type
            if max_problems > 0:
                # Determine step size based on selection
                if len(selected_categories) == 1:
                    # Single category: use multiples of 5
                    step = 5
                    start = 5
                elif max_problems > 30:
                    # Multiple categories with >30 problems: use multiples of 10
                    step = 10
                    start = 10
                else:
                    # Multiple categories with ≤30 problems: use multiples of 5
                    step = 5
                    start = 5
                
                # Generate dropdown values
                dropdown_values = list(range(start, max_problems + 1, step))
                
                # If max_problems is not a multiple of step, add the exact count
                if max_problems % step != 0 and max_problems not in dropdown_values:
                    dropdown_values.append(max_problems)
                    dropdown_values.sort()
            else:
                dropdown_values = [5]  # Default minimum
            
            # Update the combobox values
            self.question_choices['values'] = tuple(dropdown_values)
            
            # If current selection is higher than max, reset to the highest available
            current_value = int(self.num_questions.get())
            if current_value > max_problems and max_problems > 0:
                self.num_questions.set(str(max_problems))
            elif current_value not in dropdown_values and dropdown_values:
                # Set to the closest available value
                closest = min(dropdown_values, key=lambda x: abs(x - current_value))
                self.num_questions.set(str(closest))
            
            # Update the label to show the count
            self.update_question_count_label(max_problems)
            
        except Exception as e:
            # If there's an error, fall back to default values
            print(f"Error updating question dropdown: {e}")
            self.question_choices['values'] = tuple(range(5, 111, 5))
    
    def update_question_count_label(self, max_problems):
        """Update the question count label to show available problems"""
        # Find the label and update it
        for widget in self.winfo_children():
            if isinstance(widget, ttk.Frame):
                for child in widget.winfo_children():
                    if isinstance(child, ttk.Frame):
                        for grandchild in child.winfo_children():
                            if isinstance(grandchild, ttk.Label) and "Number of Questions" in str(grandchild.cget("text")):
                                grandchild.config(text=f"\nNumber of Questions (Max: {max_problems}):")
                                return
    
    def select_default_categories(self):
        """Select default categories (all)"""
        self.select_all_categories()

    def start_exam(self):
        # Get test settings
        test_type = self.test_type.get()
        num_questions = int(self.num_questions.get())
        
        # Get selected categories
        selected_categories = [category for category, var in self.category_vars.items() if var.get()]
        
        # Validate that at least one category is selected
        if not selected_categories:
            messagebox.showerror("Error", "Please select at least one category for the exam.")
            return
        
        # Check if we have problems available (this will trigger lazy initialization)
        try:
            # Create a temporary problem manager to check availability
            temp_manager = FirestoreStorageProblemManager(num_questions=num_questions)
            temp_manager.set_categories(selected_categories)
            available_problems = temp_manager.total_problems()
            
            if available_problems == 0:
                messagebox.showerror("Error", 
                    "No problems available for the selected categories.\n\n"
                    "This may be due to:\n"
                    "• Firestore connection issues\n"
                    "• No problems in the selected categories\n"
                    "• Cache corruption\n\n"
                    "Please check your internet connection and try again.")
                return
                
        except Exception as e:
            # Try fallback to local problem manager
            try:
                temp_manager = ProblemManager(num_questions=num_questions)
                temp_manager.set_categories(selected_categories)
                available_problems = temp_manager.total_problems()
                
                if available_problems == 0:
                    messagebox.showerror("Error", 
                        "No problems available for the selected categories.\n\n"
                        "Please check your problem database configuration.")
                    return
                    
            except Exception as e2:
                messagebox.showerror("Error", 
                    f"Failed to initialize both Firestore and local problem managers:\n\n"
                    f"Firestore error: {str(e)}\n"
                    f"Local error: {str(e2)}\n\n"
                    "Please check your configuration and try again.")
                return
        
        # Show loading message
        loading_window = tk.Toplevel(self)
        loading_window.title("Starting Exam")
        loading_window.geometry("400x150")
        loading_window.transient(self)
        loading_window.grab_set()
        
        # Center the window
        loading_window.update_idletasks()
        x = (loading_window.winfo_screenwidth() // 2) - (400 // 2)
        y = (loading_window.winfo_screenheight() // 2) - (150 // 2)
        loading_window.geometry(f'400x150+{x}+{y}')
        
        # Loading message
        message_label = ttk.Label(loading_window, 
                                text="Starting your practice exam...\n\nThis may take a few seconds on first run\nas we load problems from the database.",
                                font=('Arial', 11),
                                justify='center')
        message_label.pack(pady=30)
        
        # Progress bar
        progress = ttk.Progressbar(loading_window, mode='indeterminate')
        progress.pack(pady=10, padx=20, fill='x')
        progress.start()
        
        # Update loading window
        loading_window.update()
        
        # Create and start the exam with the selected settings
        self.destroy()
        exam = FEExamSimulator(test_type=test_type, num_questions=num_questions, selected_categories=selected_categories)
        exam.mainloop()

    def create_start_button(self):
        start_button = tk.Button(
            self,
            text="Take Practice Exam",
            font=('Arial', 16, 'bold'),
            bg='#007bff',  # Blue
            fg='white',    # White text
            activebackground='#0056b3',  # Darker Blue on hover
            activeforeground='white',    # Keep text white on hover
            relief=tk.RAISED,
            padx=20,
            pady=10,
            command=self.start_exam
        )
        
        # Add hover effects
        def on_enter(e):
            start_button['background'] = '#0056b3'
            
        def on_leave(e):
            start_button['background'] = '#007bff'
            
        start_button.bind("<Enter>", on_enter)
        start_button.bind("<Leave>", on_leave)
        
        start_button.grid(row=3, column=0, columnspan=2, pady=20)

if __name__ == "__main__":
    with open(get_debug_log_path(), "a") as f:
        f.write("In main block...\n")
    dashboard = Dashboard()
    with open(get_debug_log_path(), "a") as f:
        f.write("Created Dashboard, starting mainloop...\n")
    dashboard.mainloop()
    with open(get_debug_log_path(), "a") as f:
        f.write("Program finished.\n") 