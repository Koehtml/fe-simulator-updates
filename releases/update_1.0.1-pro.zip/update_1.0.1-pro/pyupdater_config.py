"""
PyUpdater Configuration for FE Simulator
This file configures how PyUpdater handles updates for the application
"""

import os
import sys

# Application information
APP_NAME = "FE_Simulator Beta"
APP_VERSION = "1.0"
APP_DESCRIPTION = "FE Exam Practice Software"

# Update repository configuration
# You'll need to set up a repository (GitHub, S3, etc.) to host your updates
UPDATE_REPOSITORY = {
    'type': 'github',  # Options: github, s3, local
    'url': 'https://github.com/yourusername/fe-simulator-updates',  # Replace with your actual repository
    'branch': 'main',
    'access_token': None,  # Set this if using private repository
}

# Alternative: S3 configuration
# UPDATE_REPOSITORY = {
#     'type': 's3',
#     'bucket': 'your-update-bucket',
#     'region': 'us-east-1',
#     'access_key': None,  # Set your AWS access key
#     'secret_key': None,  # Set your AWS secret key
# }

# Update settings
UPDATE_SETTINGS = {
    'auto_check': True,  # Automatically check for updates on startup
    'check_interval': 24,  # Check for updates every 24 hours
    'download_updates': False,  # Don't automatically download updates
    'install_updates': False,  # Don't automatically install updates
    'backup_before_update': True,  # Create backup before updating
    'max_download_retries': 3,  # Maximum retry attempts for downloads
}

# File patterns to include/exclude in updates
UPDATE_PATTERNS = {
    'include': [
        '*.exe',  # Windows executable
        '*.dll',  # Windows libraries
        '*.py',   # Python files
        '*.pyc',  # Compiled Python files
        '*.json', # Configuration files
        '*.jpg',  # Image files
        '*.png',  # Image files
        '*.ico',  # Icon files
    ],
    'exclude': [
        '*.log',      # Log files
        '*.tmp',      # Temporary files
        '*.bak',      # Backup files
        '__pycache__', # Python cache
        '*.pyc',      # Compiled Python files (if you want to exclude them)
    ]
}

# Version compatibility
MINIMUM_VERSION = "1.0"  # Minimum version required for updates
MAXIMUM_VERSION = None     # Maximum version (None = no limit)

# Update channels
UPDATE_CHANNELS = {
    'stable': {
        'name': 'Stable',
        'description': 'Stable releases for production use',
        'default': True,
    },
    'beta': {
        'name': 'Beta',
        'description': 'Beta releases for testing',
        'default': False,
    },
    'alpha': {
        'name': 'Alpha',
        'description': 'Alpha releases for development',
        'default': False,
    }
}

# Logging configuration
LOGGING_CONFIG = {
    'level': 'INFO',
    'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    'file': 'pyupdater.log',
    'max_size': 1024 * 1024,  # 1MB
    'backup_count': 5,
}

# Security settings
SECURITY_SETTINGS = {
    'verify_signatures': True,  # Verify update signatures
    'allowed_signers': [],      # List of allowed signer certificates
    'check_file_hashes': True,  # Verify file integrity
}

def get_config():
    """Get the complete configuration dictionary"""
    return {
        'app': {
            'name': APP_NAME,
            'version': APP_VERSION,
            'description': APP_DESCRIPTION,
        },
        'repository': UPDATE_REPOSITORY,
        'settings': UPDATE_SETTINGS,
        'patterns': UPDATE_PATTERNS,
        'compatibility': {
            'minimum_version': MINIMUM_VERSION,
            'maximum_version': MAXIMUM_VERSION,
        },
        'channels': UPDATE_CHANNELS,
        'logging': LOGGING_CONFIG,
        'security': SECURITY_SETTINGS,
    }

def get_app_info():
    """Get basic application information"""
    return {
        'name': APP_NAME,
        'version': APP_VERSION,
        'description': APP_DESCRIPTION,
    }

def get_update_settings():
    """Get update settings"""
    return UPDATE_SETTINGS.copy()

def get_repository_config():
    """Get repository configuration"""
    return UPDATE_REPOSITORY.copy()
