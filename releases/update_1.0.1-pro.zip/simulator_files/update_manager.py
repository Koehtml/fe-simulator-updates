"""
Update Manager for FE Simulator using PyUpdater
Handles automatic updates, version checking, and update notifications
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import messagebox, ttk
import json
from datetime import datetime
import logging

try:
    from pyupdater.client import Client
    from pyupdater.utils import get_home_dir
    PYUPGRADER_AVAILABLE = True
except ImportError:
    PYUPGRADER_AVAILABLE = False
    print("PyUpdater not available - updates will be disabled")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class UpdateManager:
    """Manages automatic updates for the FE Simulator"""
    
    def __init__(self, app_name="FE_Simulator Beta", app_version="1.0"):
        self.app_name = app_name
        self.app_version = app_version
        self.client = None
        self.update_available = False
        self.latest_version = None
        self.update_info = None
        
        # Initialize PyUpdater client if available
        if PYUPGRADER_AVAILABLE:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the PyUpdater client"""
        try:
            # Get the home directory for PyUpdater
            home_dir = get_home_dir()
            app_dir = os.path.join(home_dir, self.app_name)
            
            # Create app directory if it doesn't exist
            os.makedirs(app_dir, exist_ok=True)
            
            # Initialize the client
            self.client = Client(
                app_name=self.app_name,
                app_version=self.app_version,
                app_dir=app_dir
            )
            
            logger.info(f"PyUpdater client initialized for {self.app_name} v{self.app_version}")
            
        except Exception as e:
            logger.error(f"Failed to initialize PyUpdater client: {e}")
            self.client = None
    
    def check_for_updates(self, callback=None):
        """Check for available updates asynchronously"""
        if not self.client:
            if callback:
                callback(False, "PyUpdater not available")
            return
        
        def update_check():
            try:
                # Check for updates
                self.update_available = self.client.check_for_updates()
                
                if self.update_available:
                    # Get update information
                    self.update_info = self.client.get_update_info()
                    self.latest_version = self.update_info.get('latest_version', 'Unknown')
                    
                    logger.info(f"Update available: {self.latest_version}")
                    
                    if callback:
                        callback(True, f"Update available: {self.latest_version}")
                else:
                    logger.info("No updates available")
                    if callback:
                        callback(False, "No updates available")
                        
            except Exception as e:
                logger.error(f"Error checking for updates: {e}")
                if callback:
                    callback(False, f"Error checking for updates: {str(e)}")
        
        # Run update check in background thread
        thread = threading.Thread(target=update_check, daemon=True)
        thread.start()
    
    def download_update(self, progress_callback=None, completion_callback=None):
        """Download the available update"""
        if not self.client or not self.update_available:
            if completion_callback:
                completion_callback(False, "No update available to download")
            return
        
        def download_process():
            try:
                # Download the update
                success = self.client.download_update(
                    progress_callback=progress_callback
                )
                
                if success:
                    logger.info("Update downloaded successfully")
                    if completion_callback:
                        completion_callback(True, "Update downloaded successfully")
                else:
                    logger.error("Failed to download update")
                    if completion_callback:
                        completion_callback(False, "Failed to download update")
                        
            except Exception as e:
                logger.error(f"Error downloading update: {e}")
                if completion_callback:
                    completion_callback(False, f"Error downloading update: {str(e)}")
        
        # Run download in background thread
        thread = threading.Thread(target=download_process, daemon=True)
        thread.start()
    
    def install_update(self, completion_callback=None):
        """Install the downloaded update"""
        if not self.client:
            if completion_callback:
                completion_callback(False, "PyUpdater not available")
            return
        
        def install_process():
            try:
                # Install the update
                success = self.client.install_update()
                
                if success:
                    logger.info("Update installed successfully")
                    if completion_callback:
                        completion_callback(True, "Update installed successfully. Please restart the application.")
                else:
                    logger.error("Failed to install update")
                    if completion_callback:
                        completion_callback(False, "Failed to install update")
                        
            except Exception as e:
                logger.error(f"Error installing update: {e}")
                if completion_callback:
                    completion_callback(False, f"Error installing update: {str(e)}")
        
        # Run install in background thread
        thread = threading.Thread(target=install_process, daemon=True)
        thread.start()
    
    def get_version_info(self):
        """Get current version information"""
        return {
            'current_version': self.app_version,
            'latest_version': self.latest_version,
            'update_available': self.update_available,
            'update_info': self.update_info
        }


class UpdateDialog:
    """Dialog for displaying update information and managing updates"""
    
    def __init__(self, parent, update_manager):
        self.parent = parent
        self.update_manager = update_manager
        self.dialog = None
        
    def show_update_check_dialog(self):
        """Show dialog for checking updates"""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title("Check for Updates")
        self.dialog.geometry("400x300")
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # Center the dialog
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (300 // 2)
        self.dialog.geometry(f'400x300+{x}+{y}')
        
        # Title
        title_label = ttk.Label(self.dialog, text="Check for Updates", font=('Arial', 14, 'bold'))
        title_label.pack(pady=20)
        
        # Status label
        self.status_label = ttk.Label(self.dialog, text="Checking for updates...", font=('Arial', 10))
        self.status_label.pack(pady=10)
        
        # Progress bar
        self.progress = ttk.Progressbar(self.dialog, mode='indeterminate')
        self.progress.pack(pady=10, padx=20, fill='x')
        self.progress.start()
        
        # Buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(pady=20)
        
        self.check_button = ttk.Button(button_frame, text="Check Again", command=self._check_updates)
        self.check_button.pack(side='left', padx=5)
        
        self.close_button = ttk.Button(button_frame, text="Close", command=self.dialog.destroy)
        self.close_button.pack(side='left', padx=5)
        
        # Start checking for updates
        self._check_updates()
    
    def _check_updates(self):
        """Check for updates"""
        self.status_label.config(text="Checking for updates...")
        self.progress.start()
        self.check_button.config(state='disabled')
        
        def update_callback(update_available, message):
            self.dialog.after(0, self._update_status, update_available, message)
        
        self.update_manager.check_for_updates(update_callback)
    
    def _update_status(self, update_available, message):
        """Update the status display"""
        self.progress.stop()
        self.check_button.config(state='normal')
        
        if update_available:
            self.status_label.config(text=message)
            self._show_update_options()
        else:
            self.status_label.config(text=message)
    
    def _show_update_options(self):
        """Show update options when an update is available"""
        # Remove existing buttons
        for widget in self.dialog.winfo_children():
            if isinstance(widget, ttk.Frame) and widget != self.dialog.winfo_children()[-1]:
                widget.destroy()
        
        # Add update buttons
        update_frame = ttk.Frame(self.dialog)
        update_frame.pack(pady=20)
        
        download_button = ttk.Button(update_frame, text="Download Update", 
                                   command=self._download_update)
        download_button.pack(side='left', padx=5)
        
        self.close_button = ttk.Button(update_frame, text="Close", 
                                     command=self.dialog.destroy)
        self.close_button.pack(side='left', padx=5)
    
    def _download_update(self):
        """Download the update"""
        self.status_label.config(text="Downloading update...")
        self.progress.start()
        
        def progress_callback(progress):
            self.dialog.after(0, self._update_progress, progress)
        
        def completion_callback(success, message):
            self.dialog.after(0, self._download_complete, success, message)
        
        self.update_manager.download_update(progress_callback, completion_callback)
    
    def _update_progress(self, progress):
        """Update progress display"""
        if hasattr(self, 'progress'):
            self.progress.config(mode='determinate', value=progress)
    
    def _download_complete(self, success, message):
        """Handle download completion"""
        self.progress.stop()
        self.status_label.config(text=message)
        
        if success:
            self._show_install_option()
    
    def _show_install_option(self):
        """Show install option after download"""
        # Remove existing buttons
        for widget in self.dialog.winfo_children():
            if isinstance(widget, ttk.Frame) and widget != self.dialog.winfo_children()[-1]:
                widget.destroy()
        
        # Add install button
        install_frame = ttk.Frame(self.dialog)
        install_frame.pack(pady=20)
        
        install_button = ttk.Button(install_frame, text="Install Update", 
                                  command=self._install_update)
        install_button.pack(side='left', padx=5)
        
        self.close_button = ttk.Button(install_frame, text="Close", 
                                     command=self.dialog.destroy)
        self.close_button.pack(side='left', padx=5)
    
    def _install_update(self):
        """Install the update"""
        self.status_label.config(text="Installing update...")
        self.progress.start()
        
        def completion_callback(success, message):
            self.dialog.after(0, self._install_complete, success, message)
        
        self.update_manager.install_update(completion_callback)
    
    def _install_complete(self, success, message):
        """Handle install completion"""
        self.progress.stop()
        self.status_label.config(text=message)
        
        if success:
            # Show restart message
            messagebox.showinfo("Update Complete", 
                              "Update installed successfully. Please restart the application to apply changes.")
            self.dialog.destroy()


def create_update_manager(app_name="FE_Simulator Beta", app_version="1.0"):
    """Factory function to create an update manager"""
    return UpdateManager(app_name, app_version)


def show_update_dialog(parent, update_manager):
    """Show the update dialog"""
    dialog = UpdateDialog(parent, update_manager)
    dialog.show_update_check_dialog()
