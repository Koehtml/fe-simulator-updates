#!/usr/bin/env python3
"""
Firestore Integration Script for FE Simulator

This script modifies FE_Simulator.py to use the new Firestore Problem Manager
instead of the local JSON-based problem manager.
"""

import os
import shutil
from datetime import datetime

def backup_original_file():
    """Create a backup of the original FE_Simulator.py file."""
    original_file = "FE_Simulator.py"
    backup_file = f"FE_Simulator_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
    
    if os.path.exists(original_file):
        shutil.copy2(original_file, backup_file)
        print(f"✓ Created backup: {backup_file}")
        return backup_file
    else:
        print(f"✗ Original file not found: {original_file}")
        return None

def integrate_firestore_problem_manager():
    """Integrate Firestore Problem Manager into FE_Simulator.py."""
    
    # Create backup
    backup_file = backup_original_file()
    if not backup_file:
        return False
    
    # Read the original file
    with open("FE_Simulator.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # Make the necessary changes
    modified_content = content
    
    # 1. Update imports
    old_import = "from simulator_files.problem_manager import ProblemManager, Problem"
    new_import = """from simulator_files.problem_manager import ProblemManager, Problem
from simulator_files.firestore_problem_manager import FirestoreProblemManager, FirestoreProblem"""
    
    modified_content = modified_content.replace(old_import, new_import)
    
    # 2. Update problem manager initialization
    old_init = """        # Initialize the problem manager
        try:
            self.problem_manager = ProblemManager(num_questions=self.num_questions)
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Problem manager initialized with {self.problem_manager.total_problems()} problems\\n")
        except Exception as e:
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Error initializing problem manager: {str(e)}\\n")
            raise"""
    
    new_init = """        # Initialize the problem manager (Firestore-based)
        try:
            self.problem_manager = FirestoreProblemManager(num_questions=self.num_questions)
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Firestore problem manager initialized with {self.problem_manager.total_problems()} problems\\n")
        except Exception as e:
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Error initializing Firestore problem manager: {str(e)}\\n")
            # Fallback to local problem manager
            try:
                self.problem_manager = ProblemManager(num_questions=self.num_questions)
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Fallback to local problem manager with {self.problem_manager.total_problems()} problems\\n")
            except Exception as e2:
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Error initializing local problem manager: {str(e2)}\\n")
                raise"""
    
    modified_content = modified_content.replace(old_init, new_init)
    
    # 3. Update media loading logic
    old_media_loading = """        # Display media if present
        if problem.media:
            # Add a newline before the media
            self.problem_text.insert(tk.END, "\\n")
            
            # Load and display the media file - Updated for PyInstaller compatibility
            if getattr(sys, 'frozen', False):
                media_path = os.path.join(sys._MEIPASS, "media", problem.media)
            else:
                media_path = os.path.join("media", problem.media)
            
            print(f"Looking for media file: {problem.media}")
            print(f"Full media path: {media_path}")
            print(f"File exists: {os.path.exists(media_path)}")
            
            # Try different path variations
            if not os.path.exists(media_path):
                base, ext = os.path.splitext(media_path)
                alt_path = base.replace("_", " ") + ext
                print(f"Trying alternative path: {alt_path}")
                media_path = alt_path
            
            if not os.path.exists(media_path):
                alt_path = media_path.replace("_", " ")
                print(f"Trying another alternative path: {alt_path}")
                media_path = alt_path
            
            if os.path.exists(media_path):
                print(f"Successfully loading media from: {media_path}")
                img = Image.open(media_path)
                # Scale image based on media_size value (default to 100 if not present)
                scale_factor = problem.media_size / 100 if hasattr(problem, 'media_size') else 1.0
                if scale_factor != 1.0:
                    new_width = int(img.width * scale_factor)
                    new_height = int(img.height * scale_factor)
                    img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self.problem_text.image_create(tk.END, image=photo)
                self.problem_text.media_image = photo
            else:
                print(f"Media file not found: {media_path}")
                self.problem_text.insert(tk.END, f"\\n[Media file not found: {problem.media}]")
        else:
            print(f"Error loading media: {str(e)}")
            self.problem_text.insert(tk.END, f"\\n[Error loading media: {str(e)}]")"""
    
    new_media_loading = """        # Display media if present
        if problem.media:
            # Add a newline before the media
            self.problem_text.insert(tk.END, "\\n")
            
            # Try to load embedded media first (Firestore)
            if hasattr(problem, 'media_type') and problem.media_type == 'base64':
                try:
                    photo = self.problem_manager.load_embedded_media(problem)
                    if photo:
                        self.problem_text.image_create(tk.END, image=photo)
                        self.problem_text.media_image = photo
                        print(f"Successfully loaded embedded media for problem {problem.number}")
                    else:
                        print(f"Failed to load embedded media for problem {problem.number}")
                        self.problem_text.insert(tk.END, f"\\n[Failed to load embedded media: {problem.media_filename}]")
                except Exception as e:
                    print(f"Error loading embedded media: {e}")
                    self.problem_text.insert(tk.END, f"\\n[Error loading embedded media: {str(e)}]")
            else:
                # Fallback to local file loading
                try:
                    # Load and display the media file - Updated for PyInstaller compatibility
                    if getattr(sys, 'frozen', False):
                        media_path = os.path.join(sys._MEIPASS, "media", problem.media)
                    else:
                        media_path = os.path.join("media", problem.media)
                    
                    print(f"Looking for media file: {problem.media}")
                    print(f"Full media path: {media_path}")
                    print(f"File exists: {os.path.exists(media_path)}")
                    
                    # Try different path variations
                    if not os.path.exists(media_path):
                        base, ext = os.path.splitext(media_path)
                        alt_path = base.replace("_", " ") + ext
                        print(f"Trying alternative path: {alt_path}")
                        media_path = alt_path
                    
                    if not os.path.exists(media_path):
                        alt_path = media_path.replace("_", " ")
                        print(f"Trying another alternative path: {alt_path}")
                        media_path = alt_path
                    
                    if os.path.exists(media_path):
                        print(f"Successfully loading media from: {media_path}")
                        img = Image.open(media_path)
                        # Scale image based on media_size value (default to 100 if not present)
                        scale_factor = problem.media_size / 100 if hasattr(problem, 'media_size') else 1.0
                        if scale_factor != 1.0:
                            new_width = int(img.width * scale_factor)
                            new_height = int(img.height * scale_factor)
                            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(img)
                        self.problem_text.image_create(tk.END, image=photo)
                        self.problem_text.media_image = photo
                    else:
                        print(f"Media file not found: {media_path}")
                        self.problem_text.insert(tk.END, f"\\n[Media file not found: {problem.media}]")
                except Exception as e:
                    print(f"Error loading media: {str(e)}")
                    self.problem_text.insert(tk.END, f"\\n[Error loading media: {str(e)}]")"""
    
    modified_content = modified_content.replace(old_media_loading, new_media_loading)
    
    # Write the modified content back to the file
    with open("FE_Simulator.py", "w", encoding="utf-8") as f:
        f.write(modified_content)
    
    print("✓ Successfully integrated Firestore Problem Manager into FE_Simulator.py")
    return True

def create_integration_summary():
    """Create a summary of the integration changes."""
    summary = """
# Firestore Integration Summary

## Changes Made to FE_Simulator.py:

1. **Updated Imports**: Added import for FirestoreProblemManager and FirestoreProblem
2. **Modified Problem Manager Initialization**: 
   - Now uses FirestoreProblemManager as primary
   - Falls back to local ProblemManager if Firestore fails
3. **Enhanced Media Loading**:
   - First tries to load embedded media from Firestore (base64)
   - Falls back to local file loading if embedded media fails
   - Maintains backward compatibility

## Benefits:

✅ **Cloud-based**: Problems loaded from Firestore database
✅ **Embedded Media**: Images loaded directly from database (no local files needed)
✅ **Offline Support**: Caches problems locally for offline use
✅ **Backward Compatible**: Falls back to local files if needed
✅ **Real-time Updates**: Can update problems without app updates

## Files Created:

- `firestore_problem_manager.py`: New Firestore-based problem manager
- `firestore_cache.json`: Local cache of problems (auto-generated)
- `FE_Simulator_backup_*.py`: Backup of original file

## Usage:

The simulator will now automatically:
1. Connect to Firestore and load problems
2. Cache problems locally for performance
3. Load embedded media from the database
4. Fall back to local files if needed

## Testing:

Run the simulator normally - it will now use Firestore as the primary data source!
"""
    
    with open("FIRESTORE_INTEGRATION_SUMMARY.md", "w") as f:
        f.write(summary)
    
    print("✓ Created integration summary: FIRESTORE_INTEGRATION_SUMMARY.md")

def main():
    """Main function to run the integration."""
    print("Firestore Integration for FE Simulator")
    print("="*40)
    
    success = integrate_firestore_problem_manager()
    
    if success:
        create_integration_summary()
        print("\n✅ Integration completed successfully!")
        print("\nYour simulator is now ready to use Firestore!")
        print("Run FE_Simulator.py to test the integration.")
    else:
        print("\n❌ Integration failed. Please check the errors above.")

if __name__ == "__main__":
    main()
