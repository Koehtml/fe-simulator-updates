"""
Update Configuration for FE Simulator
Simple configuration for the lightweight updater system
"""

# Update server configuration
UPDATE_SERVER = {
    'version_url': 'https://Koehtml.github.io/fe-simulator-updates/version-pro.json',  # Pro version uses separate version file
    'download_url': 'https://github.com/Koehtml/fe-simulator-updates/releases/download/',  # Replace 'yourusername' with your GitHub username
    'timeout': 10,  # Request timeout in seconds
    'check_interval': 24,  # Check for updates every 24 hours (in hours)
}

# Application information
APP_INFO = {
    'name': 'FE Simulator Pro',
    'version': '1.0.1',
    'description': 'FE Exam Practice Software',
}

# Update settings
UPDATE_SETTINGS = {
    'auto_check_on_startup': True,  # Automatically check for updates on startup
    'show_notifications': True,     # Show update notifications
    'auto_download': False,         # Don't automatically download updates
    'create_backup': True,          # Create backup before updating
    'max_backups': 5,              # Maximum number of backups to keep
}

# Files to include in updates
UPDATE_FILES = [
    'FE_Simulator.py',
    'simulator_files/',
    'version.txt',
    'pyupdater_config.py',
    'media/',
]

# Files to exclude from updates
EXCLUDE_FILES = [
    '*.log',
    '*.tmp',
    '*.bak',
    '__pycache__/',
    'build/',
    'dist/',
    '*.spec',
    'backup_*',
]

def get_update_config():
    """Get the complete update configuration"""
    return {
        'server': UPDATE_SERVER,
        'app': APP_INFO,
        'settings': UPDATE_SETTINGS,
        'files': {
            'include': UPDATE_FILES,
            'exclude': EXCLUDE_FILES,
        }
    }

def get_app_info():
    """Get application information"""
    return APP_INFO.copy()

def get_server_config():
    """Get server configuration"""
    return UPDATE_SERVER.copy()

def get_update_settings():
    """Get update settings"""
    return UPDATE_SETTINGS.copy()
