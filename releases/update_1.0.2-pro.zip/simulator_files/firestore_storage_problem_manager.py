#!/usr/bin/env python3
"""
Firestore Storage Problem Manager for FE Simulator

This module provides a Firestore-based problem manager that fetches problems
from Firestore database and loads media from Firebase Storage URLs.
"""

import json
import random
import os
import requests
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime
from io import BytesIO
from PIL import Image, ImageTk

class FirestoreStorageProblem:
    def __init__(self, 
                 number: str,
                 category: str,
                 question: str,
                 media: str,
                 choices: List[str],
                 correct_answer: str,
                 media_size: int = 100,
                 media_type: str = None,
                 media_filename: str = None,
                 media_url: str = None):
        self.number = number
        self.category = category
        self.question = question
        self.media = media
        self.choices = choices
        self.correct_answer = correct_answer
        self.media_size = media_size
        self.media_type = media_type
        self.media_filename = media_filename
        self.media_url = media_url

class FirestoreStorageProblemManager:
    def __init__(self, num_questions: int = 50, project_id: str = "the-fe-simulator"):
        self.problems: List[FirestoreStorageProblem] = []
        self.all_problems: List[FirestoreStorageProblem] = []  # Store all problems
        self.current_index = 0
        self.num_questions = num_questions
        self.selected_categories = None
        self.project_id = project_id
        self.db = None
        self.cache_file = os.path.join(os.path.dirname(__file__), 'firestore_storage_cache.json')
        self.cache_duration_hours = 24  # Cache for 24 hours
        
        # Initialize Firebase
        self._initialize_firebase()
        
        # Load problems from Firestore
        self._load_problems_from_firestore()
        self._shuffle_problems()

    def _initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to initialize with default credentials
            firebase_admin.initialize_app()
            print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Falling back to cached data...")
            return
        
        # Initialize Firestore client
        try:
            self.db = firestore.client()
            print(f"✓ Connected to Firestore project: {self.project_id}")
        except Exception as e:
            print(f"✗ Error connecting to Firestore: {e}")
            print("Falling back to cached data...")

    def _load_problems_from_firestore(self):
        """Load problems from Firestore or cache."""
        # Try to load from cache first
        if self._load_from_cache():
            print(f"✓ Loaded {len(self.all_problems)} problems from cache")
            return
        
        # If no cache or cache is stale, load from Firestore
        if self.db:
            self._load_from_firestore()
        else:
            print("✗ No Firestore connection and no valid cache available")
            self.all_problems = []

    def _load_from_cache(self) -> bool:
        """Load problems from local cache file."""
        try:
            if not os.path.exists(self.cache_file):
                return False
            
            # Check if cache is still valid
            cache_age = datetime.now().timestamp() - os.path.getmtime(self.cache_file)
            if cache_age > (self.cache_duration_hours * 3600):
                print("Cache is stale, will refresh from Firestore")
                return False
            
            with open(self.cache_file, 'r', encoding='utf-8') as file:
                cache_data = json.load(file)
                
            self.all_problems = []
            for problem_data in cache_data.get('problems', []):
                problem = FirestoreStorageProblem(
                    number=str(problem_data["number"]),
                    category=problem_data["category"],
                    question=problem_data["question"],
                    media=problem_data.get("media", ""),
                    choices=problem_data["choices"],
                    correct_answer=problem_data["correct_answer"],
                    media_size=problem_data.get("media_size", 100),
                    media_type=problem_data.get("media_type"),
                    media_filename=problem_data.get("media_filename"),
                    media_url=problem_data.get("media_url")
                )
                self.all_problems.append(problem)
            
            return True
            
        except Exception as e:
            print(f"Error loading from cache: {e}")
            return False

    def _load_from_firestore(self):
        """Load problems from Firestore database."""
        try:
            print("Loading problems from Firestore...")
            problems_ref = self.db.collection('problems')
            
            self.all_problems = []
            for doc in problems_ref.stream():
                problem_data = doc.to_dict()
                
                problem = FirestoreStorageProblem(
                    number=str(problem_data["number"]),
                    category=problem_data["category"],
                    question=problem_data["question"],
                    media=problem_data.get("media", ""),
                    choices=problem_data["choices"],
                    correct_answer=problem_data["correct_answer"],
                    media_size=problem_data.get("media_size", 100),
                    media_type=problem_data.get("media_type"),
                    media_filename=problem_data.get("media_filename"),
                    media_url=problem_data.get("media_url")
                )
                self.all_problems.append(problem)
            
            print(f"✓ Loaded {len(self.all_problems)} problems from Firestore")
            
            # Save to cache
            self._save_to_cache()
            
        except Exception as e:
            print(f"✗ Error loading from Firestore: {e}")
            self.all_problems = []

    def _save_to_cache(self):
        """Save problems to local cache file."""
        try:
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'problems': []
            }
            
            for problem in self.all_problems:
                problem_dict = {
                    'number': problem.number,
                    'category': problem.category,
                    'question': problem.question,
                    'media': problem.media,
                    'choices': problem.choices,
                    'correct_answer': problem.correct_answer,
                    'media_size': problem.media_size,
                    'media_type': problem.media_type,
                    'media_filename': problem.media_filename,
                    'media_url': problem.media_url
                }
                cache_data['problems'].append(problem_dict)
            
            with open(self.cache_file, 'w', encoding='utf-8') as file:
                json.dump(cache_data, file, indent=2, ensure_ascii=False)
            
            print(f"✓ Cached {len(self.all_problems)} problems")
            
        except Exception as e:
            print(f"Error saving to cache: {e}")

    def set_categories(self, categories: List[str]):
        """Set the selected categories and filter problems accordingly"""
        self.selected_categories = categories
        if categories:
            self.problems = [p for p in self.all_problems if p.category in categories]
        else:
            self.problems = self.all_problems.copy()
        self._shuffle_problems()

    def _shuffle_problems(self):
        """Shuffle and ensure exactly num_questions problems"""
        # If no categories are set, use all problems
        if self.selected_categories is None:
            self.problems = self.all_problems.copy()
        
        # First shuffle the filtered list
        random.shuffle(self.problems)
        
        # If we have fewer problems than requested, use all of them
        if len(self.problems) <= self.num_questions:
            return
            
        # Take exactly num_questions problems
        self.problems = self.problems[:self.num_questions]
        self.current_index = 0

    def get_current_problem(self) -> Optional[FirestoreStorageProblem]:
        if 0 <= self.current_index < len(self.problems):
            return self.problems[self.current_index]
        return None

    def next_problem(self) -> Optional[FirestoreStorageProblem]:
        if self.current_index < len(self.problems) - 1:
            self.current_index += 1
            return self.get_current_problem()
        return None

    def previous_problem(self) -> Optional[FirestoreStorageProblem]:
        if self.current_index > 0:
            self.current_index -= 1
            return self.get_current_problem()
        return None

    def jump_to_problem(self, index: int) -> Optional[FirestoreStorageProblem]:
        if 0 <= index < len(self.problems):
            self.current_index = index
            return self.get_current_problem()
        return None

    def total_problems(self) -> int:
        """Get total number of problems available"""
        self._ensure_initialized()
        return len(self.problems)

    def get_problem_by_number(self, number: str) -> Optional[FirestoreStorageProblem]:
        """Get a specific problem by its number"""
        for problem in self.all_problems:
            if problem.number == number:
                return problem
        return None

    def get_problems_by_category(self, category: str) -> List[FirestoreStorageProblem]:
        """Get all problems in a specific category"""
        return [p for p in self.all_problems if p.category == category]

    def get_all_categories(self) -> List[str]:
        """Get list of all available categories"""
        categories = set()
        for problem in self.all_problems:
            categories.add(problem.category)
        return sorted(list(categories))

    def load_storage_media(self, problem: FirestoreStorageProblem) -> Optional[ImageTk.PhotoImage]:
        """
        Load media from Firebase Storage URL and return as PhotoImage.
        
        Args:
            problem: FirestoreStorageProblem object with media_url
            
        Returns:
            PhotoImage object or None if loading fails
        """
        if not problem.media_url or problem.media_type != 'storage_url':
            return None
        
        try:
            # Download image from Storage URL
            response = requests.get(problem.media_url, timeout=10)
            response.raise_for_status()
            
            # Create PIL Image from response content
            image = Image.open(BytesIO(response.content))
            
            # Scale image based on media_size value
            scale_factor = problem.media_size / 100
            if scale_factor != 1.0:
                new_width = int(image.width * scale_factor)
                new_height = int(image.height * scale_factor)
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(image)
            return photo
            
        except Exception as e:
            print(f"Error loading storage media for problem {problem.number}: {e}")
            return None

    def refresh_from_firestore(self):
        """Force refresh problems from Firestore, bypassing cache."""
        if self.db:
            self._load_from_firestore()
            self._shuffle_problems()
        else:
            print("No Firestore connection available for refresh")

    def get_cache_info(self) -> Dict:
        """Get information about the cache status."""
        if not os.path.exists(self.cache_file):
            return {
                'exists': False,
                'age_hours': None,
                'problem_count': 0
            }
        
        cache_age = datetime.now().timestamp() - os.path.getmtime(self.cache_file)
        age_hours = cache_age / 3600
        
        try:
            with open(self.cache_file, 'r', encoding='utf-8') as file:
                cache_data = json.load(file)
                problem_count = len(cache_data.get('problems', []))
        except:
            problem_count = 0
        
        return {
            'exists': True,
            'age_hours': age_hours,
            'problem_count': problem_count,
            'is_stale': age_hours > self.cache_duration_hours
        }
