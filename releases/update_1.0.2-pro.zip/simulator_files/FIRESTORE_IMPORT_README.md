# Firestore Import Script for FE Simulator

This script imports practice questions from `problems_database.json` into a Firestore database using Firebase Admin SDK.

## Features

- ✅ Imports all 50 practice problems to Firestore
- ✅ Uses Firebase Admin SDK for authentication
- ✅ Converts problem numbers to integers
- ✅ Skips existing documents (no overwrites)
- ✅ Comprehensive error handling and reporting
- ✅ Progress tracking and detailed summary
- ✅ Validates data integrity before import
- ✅ Preserves LaTeX formatting in questions

## Prerequisites

1. **Python 3.7+** installed on your system
2. **Firebase project** with Firestore enabled
3. **Firebase Admin SDK credentials** set up

## Setup Instructions

### 1. Install Dependencies

```bash
pip install -r firestore_requirements.txt
```

### 2. Firebase Authentication Setup

You have several options for authentication:

#### Option A: Firebase CLI (Recommended for Development)

1. Install Firebase CLI:
   ```bash
   ```

2. Login to Firebase:
   ```bash
   firebase login
   ```

3. Set your project:
   ```bash
   firebase use the-fe-simulator
   ```

#### Option B: Service Account Key (Recommended for Production)

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project: `the-fe-simulator`
3. Go to Project Settings → Service Accounts
4. Click "Generate new private key"
5. Download the JSON file
6. Set environment variable:
   ```bash
   # Windows
   set GOOGLE_APPLICATION_CREDENTIALS=path\to\your\service-account-key.json
   
   # macOS/Linux
   export GOOGLE_APPLICATION_CREDENTIALS=path/to/your/service-account-key.json
   ```

#### Option C: Google Cloud SDK

1. Install [Google Cloud SDK](https://cloud.google.com/sdk/docs/install)
2. Authenticate:
   ```bash
   gcloud auth application-default login
   ```

### 3. Verify Firestore Setup

Ensure your Firebase project has Firestore enabled:
1. Go to Firebase Console → Firestore Database
2. Create database if not exists
3. Choose a location (recommended: `us-central1`)

## Usage

### Basic Usage

```bash
python firestore_import.py
```

The script will:
1. Load `problems_database.json` from the same directory
2. Connect to your Firestore database
3. Import all problems to the `problems` collection
4. Display progress and summary

### Expected Output

```
FE Simulator - Firestore Import Tool
========================================
✓ Firebase initialized with default credentials
✓ Connected to Firestore project: the-fe-simulator
✓ Loaded 50 problems from simulator_files/problems_database.json

Starting import of 50 problems...
Processing problem 1/50 (ID: 1) → Imported
Processing problem 2/50 (ID: 2) → Imported
...
Processing problem 50/50 (ID: 50) → Imported

==================================================
IMPORT SUMMARY
==================================================
Total problems processed: 50
Successfully imported: 50
Skipped (already exist): 0
Errors: 0

Imported problem IDs: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50
```

## Data Structure

Each problem is stored as a document in the `problems` collection with the following structure:

```json
{
  "number": 1,
  "category": "Math",
  "question": "The following equation defines what kind of shape? \\( (x-3)^2 + \\frac{y^2}{16} = 1 \\)",
  "media": "",
  "choices": [
    "Circle",
    "Ellipse", 
    "Hyperbola",
    "Parabola"
  ],
  "correct_answer": "B",
  "media_size": 40,
  "imported_at": "2024-01-15T10:30:00.000Z"
}
```

### Field Descriptions

- `number`: Problem number (converted to integer)
- `category`: Subject category (Math, Ethics, Econ, etc.)
- `question`: Question text with LaTeX formatting preserved
- `media`: Media file reference (empty string or filename)
- `choices`: Array of 4 answer choices
- `correct_answer`: Letter of correct answer (A, B, C, or D)
- `media_size`: Integer value for media sizing
- `imported_at`: Timestamp when the problem was imported

## Error Handling

The script handles various error scenarios:

- **Missing required fields**: Reports which fields are missing
- **Invalid data formats**: Validates number formats, choice counts, etc.
- **Network issues**: Continues processing other problems
- **Existing documents**: Skips without overwriting
- **Authentication errors**: Provides clear setup instructions

## Troubleshooting

### Common Issues

1. **"Firebase not initialized" error**
   - Ensure you've completed the authentication setup
   - Check that Firebase CLI is installed and you're logged in

2. **"Permission denied" error**
   - Verify your service account has Firestore read/write permissions
   - Check that you're using the correct project ID

3. **"File not found" error**
   - Ensure `problems_database.json` is in the same directory as the script

4. **Import errors**
   - Check the error messages in the summary
   - Verify your JSON file is valid
   - Ensure all required fields are present

### Getting Help

If you encounter issues:

1. Check the error messages in the import summary
2. Verify your Firebase project settings
3. Ensure all dependencies are installed
4. Check that your authentication is properly configured

## Security Notes

- Keep service account keys secure and never commit them to version control
- Use environment variables for sensitive credentials
- Consider using Firebase CLI for development and service accounts for production

## Future Enhancements

The script is designed to be extensible. You can easily add:
- Additional validation rules
- Custom field transformations
- Batch processing for large datasets
- Export functionality
- Data migration tools

## Support

For questions or issues, check:
1. Firebase documentation: https://firebase.google.com/docs
2. Firebase Admin SDK: https://firebase.google.com/docs/admin
3. Your project's error logs in Firebase Console
