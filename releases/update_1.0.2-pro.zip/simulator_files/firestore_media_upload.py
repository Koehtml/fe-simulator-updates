#!/usr/bin/env python3
"""
Firestore Media Upload Script for FE Simulator

This script uploads media files to Firebase Storage and updates Firestore documents
with the corresponding media URLs.
"""

import os
import sys
import json
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore, storage
from datetime import datetime
import mimetypes

class FirestoreMediaUploader:
    def __init__(self, project_id: str = "the-fe-simulator"):
        """
        Initialize the Firestore media uploader.
        
        Args:
            project_id: Firebase project ID
        """
        self.project_id = project_id
        self.db = None
        self.bucket = None
        self.uploaded_files = {}
        self.updated_documents = []
        self.errors = []
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK with Storage."""
        try:
            # Try to initialize with default credentials
            firebase_admin.initialize_app()
            print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Please ensure you have set up Firebase Admin SDK credentials.")
            sys.exit(1)
        
        # Initialize Firestore client
        self.db = firestore.client()
        print(f"✓ Connected to Firestore project: {self.project_id}")
        
        # Initialize Storage bucket
        try:
            # Use the default bucket for the project
            bucket_name = f"{self.project_id}.appspot.com"
            self.bucket = storage.bucket(bucket_name)
            print(f"✓ Connected to Firebase Storage bucket: {self.bucket.name}")
        except Exception as e:
            print(f"✗ Error connecting to Firebase Storage: {e}")
            print("Please ensure Firebase Storage is enabled in your project.")
            print("You may need to enable Storage in the Firebase Console.")
            sys.exit(1)
    
    def get_media_files(self, media_dir: str) -> List[str]:
        """
        Get list of media files from the media directory.
        
        Args:
            media_dir: Path to media directory
            
        Returns:
            List of media file paths
        """
        media_files = []
        if not os.path.exists(media_dir):
            print(f"✗ Media directory not found: {media_dir}")
            return media_files
        
        # Get all image files
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
        for filename in os.listdir(media_dir):
            file_path = os.path.join(media_dir, filename)
            if os.path.isfile(file_path):
                _, ext = os.path.splitext(filename.lower())
                if ext in image_extensions:
                    media_files.append(file_path)
        
        print(f"✓ Found {len(media_files)} media files in {media_dir}")
        return media_files
    
    def upload_media_file(self, file_path: str) -> Optional[str]:
        """
        Upload a single media file to Firebase Storage.
        
        Args:
            file_path: Path to the media file
            
        Returns:
            Public URL of uploaded file, or None if failed
        """
        try:
            filename = os.path.basename(file_path)
            
            # Create blob reference
            blob = self.bucket.blob(f"media/{filename}")
            
            # Set content type
            content_type, _ = mimetypes.guess_type(file_path)
            if content_type:
                blob.content_type = content_type
            
            # Upload file
            print(f"Uploading {filename}...", end=" ")
            blob.upload_from_filename(file_path)
            
            # Make public and get URL
            blob.make_public()
            url = blob.public_url
            
            print(f"✓ Uploaded successfully")
            print(f"  URL: {url}")
            
            return url
            
        except Exception as e:
            print(f"✗ Failed to upload {filename}: {e}")
            self.errors.append(f"Failed to upload {filename}: {e}")
            return None
    
    def upload_all_media(self, media_dir: str):
        """
        Upload all media files to Firebase Storage.
        
        Args:
            media_dir: Path to media directory
        """
        print("\n" + "="*50)
        print("UPLOADING MEDIA FILES TO FIREBASE STORAGE")
        print("="*50)
        
        media_files = self.get_media_files(media_dir)
        if not media_files:
            print("No media files found to upload.")
            return
        
        for file_path in media_files:
            filename = os.path.basename(file_path)
            url = self.upload_media_file(file_path)
            if url:
                self.uploaded_files[filename] = url
        
        print(f"\n✓ Successfully uploaded {len(self.uploaded_files)} files")
        if self.errors:
            print(f"✗ Failed to upload {len(self.errors)} files")
    
    def get_problems_with_media(self) -> List[Dict]:
        """
        Get all problems from Firestore that have media files.
        
        Returns:
            List of problem documents with media
        """
        try:
            problems_ref = self.db.collection('problems')
            problems = []
            
            for doc in problems_ref.stream():
                problem_data = doc.to_dict()
                if problem_data.get('media') and problem_data['media'].strip():
                    problem_data['doc_id'] = doc.id
                    problems.append(problem_data)
            
            print(f"✓ Found {len(problems)} problems with media files")
            return problems
            
        except Exception as e:
            print(f"✗ Error fetching problems from Firestore: {e}")
            self.errors.append(f"Error fetching problems: {e}")
            return []
    
    def update_problem_media_url(self, doc_id: str, media_filename: str, media_url: str) -> bool:
        """
        Update a problem document with the new media URL.
        
        Args:
            doc_id: Document ID
            media_filename: Original media filename
            media_url: New Firebase Storage URL
            
        Returns:
            True if successful, False otherwise
        """
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc_ref.update({
                'media': media_url,
                'media_updated_at': datetime.utcnow()
            })
            return True
            
        except Exception as e:
            print(f"✗ Error updating document {doc_id}: {e}")
            self.errors.append(f"Error updating document {doc_id}: {e}")
            return False
    
    def update_all_problem_media(self):
        """
        Update all problem documents with new media URLs.
        """
        print("\n" + "="*50)
        print("UPDATING FIRESTORE DOCUMENTS WITH MEDIA URLS")
        print("="*50)
        
        problems = self.get_problems_with_media()
        if not problems:
            print("No problems with media found.")
            return
        
        updated_count = 0
        skipped_count = 0
        
        for problem in problems:
            doc_id = problem['doc_id']
            media_filename = problem['media']
            
            # Check if we have the uploaded file
            if media_filename in self.uploaded_files:
                media_url = self.uploaded_files[media_filename]
                
                print(f"Updating problem {doc_id} ({media_filename})...", end=" ")
                
                if self.update_problem_media_url(doc_id, media_filename, media_url):
                    self.updated_documents.append(doc_id)
                    updated_count += 1
                    print("✓ Updated")
                else:
                    print("✗ Failed")
            else:
                print(f"Skipping problem {doc_id} - media file '{media_filename}' not uploaded")
                skipped_count += 1
        
        print(f"\n✓ Updated {updated_count} documents")
        print(f"⚠ Skipped {skipped_count} documents (media not uploaded)")
    
    def print_summary(self):
        """Print upload and update summary."""
        print("\n" + "="*50)
        print("MEDIA UPLOAD SUMMARY")
        print("="*50)
        print(f"Files uploaded to Storage: {len(self.uploaded_files)}")
        print(f"Documents updated in Firestore: {len(self.updated_documents)}")
        print(f"Errors encountered: {len(self.errors)}")
        
        if self.uploaded_files:
            print(f"\nUploaded files:")
            for filename, url in self.uploaded_files.items():
                print(f"  {filename} → {url}")
        
        if self.updated_documents:
            print(f"\nUpdated document IDs: {', '.join(sorted(self.updated_documents))}")
        
        if self.errors:
            print(f"\nERRORS:")
            for error in self.errors:
                print(f"  - {error}")
    
    def run_media_upload(self, media_dir: str):
        """
        Run the complete media upload process.
        
        Args:
            media_dir: Path to media directory
        """
        print("FE Simulator - Media Upload Tool")
        print("="*40)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Upload media files
        self.upload_all_media(media_dir)
        
        # Update Firestore documents
        self.update_all_problem_media()
        
        # Print summary
        self.print_summary()


def main():
    """Main function to run the media upload script."""
    # Get the path to the media directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    media_dir = os.path.join(os.path.dirname(script_dir), "media")
    
    # Check if media directory exists
    if not os.path.exists(media_dir):
        print(f"✗ Error: Media directory not found at {media_dir}")
        print("Please ensure the media directory exists and contains image files.")
        sys.exit(1)
    
    # Create uploader and run upload
    uploader = FirestoreMediaUploader()
    uploader.run_media_upload(media_dir)


if __name__ == "__main__":
    main()
