#!/usr/bin/env python3
"""
Firebase Storage Media Upload Script

This script uploads media files from the local media/ folder to Firebase Storage
and updates Firestore documents to reference the Storage URLs instead of base64 data.
"""

import os
import firebase_admin
from firebase_admin import credentials, firestore, storage
from datetime import datetime
import mimetypes

class FirebaseStorageUploader:
    def __init__(self, project_id: str = "the-fe-simulator"):
        self.project_id = project_id
        self.db = None
        self.bucket = None
        self.media_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "media")
        self.uploaded_files = []
        self.errors = []
        
        # Initialize Firebase
        self._initialize_firebase()
    
    def _initialize_firebase(self):
        """Initialize Firebase Admin SDK and Storage."""
        try:
            # Try to initialize with default credentials
            firebase_admin.initialize_app()
            print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            raise
        
        # Initialize Firestore client
        try:
            self.db = firestore.client()
            print(f"✓ Connected to Firestore project: {self.project_id}")
        except Exception as e:
            print(f"✗ Error connecting to Firestore: {e}")
            raise
        
        # Initialize Storage bucket
        try:
            self.bucket = storage.bucket("the-fe-simulator.firebasestorage.app")
            print(f"✓ Connected to Storage bucket: the-fe-simulator.firebasestorage.app")
        except Exception as e:
            print(f"✗ Error connecting to Storage: {e}")
            raise
    
    def upload_media_files(self):
        """Upload all media files to Firebase Storage."""
        if not os.path.exists(self.media_folder):
            print(f"✗ Media folder not found: {self.media_folder}")
            return False
        
        print(f"\nUploading media files from: {self.media_folder}")
        print("="*50)
        
        # Get list of media files
        media_files = []
        for filename in os.listdir(self.media_folder):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                media_files.append(filename)
        
        if not media_files:
            print("✗ No media files found in media folder")
            return False
        
        print(f"Found {len(media_files)} media files to upload")
        
        # Upload each file
        for filename in media_files:
            file_path = os.path.join(self.media_folder, filename)
            try:
                # Upload to Storage
                blob_name = f"media/{filename}"
                blob = self.bucket.blob(blob_name)
                
                # Set content type
                content_type, _ = mimetypes.guess_type(file_path)
                if content_type:
                    blob.content_type = content_type
                
                # Upload file
                blob.upload_from_filename(file_path)
                
                # Make public (optional - you can set custom rules instead)
                blob.make_public()
                
                # Get public URL
                public_url = blob.public_url
                
                self.uploaded_files.append({
                    'filename': filename,
                    'blob_name': blob_name,
                    'url': public_url,
                    'size': os.path.getsize(file_path)
                })
                
                print(f"✓ Uploaded: {filename} -> {blob_name}")
                print(f"  URL: {public_url}")
                
            except Exception as e:
                error_msg = f"Error uploading {filename}: {e}"
                print(f"✗ {error_msg}")
                self.errors.append(error_msg)
        
        print(f"\n✓ Successfully uploaded {len(self.uploaded_files)} files")
        if self.errors:
            print(f"✗ {len(self.errors)} errors occurred")
        
        return len(self.errors) == 0
    
    def update_firestore_documents(self):
        """Update Firestore documents to reference Storage URLs instead of base64 data."""
        if not self.uploaded_files:
            print("✗ No files uploaded, cannot update Firestore")
            return False
        
        print(f"\nUpdating Firestore documents...")
        print("="*50)
        
        # Create filename to URL mapping
        filename_to_url = {file_info['filename']: file_info['url'] for file_info in self.uploaded_files}
        
        # Get all problems from Firestore
        try:
            problems_ref = self.db.collection('problems')
            problems = list(problems_ref.stream())
            
            print(f"Found {len(problems)} problems in Firestore")
            
            updated_count = 0
            for doc in problems:
                doc_data = doc.to_dict()
                media_filename = doc_data.get('media_filename')
                
                if media_filename and media_filename in filename_to_url:
                    # Update the document
                    try:
                        doc_ref = self.db.collection('problems').document(doc.id)
                        doc_ref.update({
                            'media_url': filename_to_url[media_filename],
                            'media_type': 'storage_url',
                            'media_updated_at': datetime.utcnow(),
                            # Remove old base64 data
                            'media': firestore.DELETE_FIELD
                        })
                        
                        print(f"✓ Updated problem {doc_data.get('number', 'unknown')}: {media_filename}")
                        updated_count += 1
                        
                    except Exception as e:
                        error_msg = f"Error updating document {doc.id}: {e}"
                        print(f"✗ {error_msg}")
                        self.errors.append(error_msg)
                
                elif doc_data.get('media_type') == 'base64':
                    # This problem has base64 data but no filename match
                    print(f"⚠ Problem {doc_data.get('number', 'unknown')}: Has base64 data but no filename match")
            
            print(f"\n✓ Successfully updated {updated_count} Firestore documents")
            
        except Exception as e:
            error_msg = f"Error accessing Firestore: {e}"
            print(f"✗ {error_msg}")
            self.errors.append(error_msg)
            return False
        
        return len(self.errors) == 0
    
    def cleanup_base64_data(self):
        """Remove base64 data from Firestore documents to reduce size."""
        print(f"\nCleaning up base64 data...")
        print("="*50)
        
        try:
            problems_ref = self.db.collection('problems')
            problems = list(problems_ref.stream())
            
            cleaned_count = 0
            for doc in problems:
                doc_data = doc.to_dict()
                
                # If document has base64 data and now has a storage URL, remove base64
                if (doc_data.get('media_type') == 'storage_url' and 
                    doc_data.get('media_url') and 
                    'media' in doc_data):
                    
                    try:
                        doc_ref = self.db.collection('problems').document(doc.id)
                        doc_ref.update({
                            'media': firestore.DELETE_FIELD
                        })
                        cleaned_count += 1
                        
                    except Exception as e:
                        error_msg = f"Error cleaning document {doc.id}: {e}"
                        print(f"✗ {error_msg}")
                        self.errors.append(error_msg)
            
            print(f"✓ Cleaned up {cleaned_count} documents")
            
        except Exception as e:
            error_msg = f"Error during cleanup: {e}"
            print(f"✗ {error_msg}")
            self.errors.append(error_msg)
    
    def run_full_migration(self):
        """Run the complete migration process."""
        print("Firebase Storage Media Migration")
        print("="*40)
        
        try:
            # Step 1: Upload media files
            if not self.upload_media_files():
                print("✗ Media upload failed")
                return False
            
            # Step 2: Update Firestore documents
            if not self.update_firestore_documents():
                print("✗ Firestore update failed")
                return False
            
            # Step 3: Clean up base64 data
            self.cleanup_base64_data()
            
            # Summary
            print(f"\n" + "="*50)
            print("✅ MIGRATION COMPLETED SUCCESSFULLY!")
            print(f"✓ Uploaded {len(self.uploaded_files)} media files")
            print(f"✓ Updated Firestore documents with Storage URLs")
            print(f"✓ Cleaned up old base64 data")
            
            if self.errors:
                print(f"\n⚠ {len(self.errors)} errors occurred during migration:")
                for error in self.errors:
                    print(f"  - {error}")
            
            return True
            
        except Exception as e:
            print(f"\n❌ MIGRATION FAILED: {e}")
            return False

def main():
    """Main function to run the migration."""
    try:
        uploader = FirebaseStorageUploader()
        success = uploader.run_full_migration()
        
        if success:
            print("\nNext steps:")
            print("1. Your media files are now in Firebase Storage")
            print("2. Firestore documents reference Storage URLs")
            print("3. Update your simulator to load images from URLs")
        else:
            print("\nMigration failed. Please check the errors above.")
            
    except Exception as e:
        print(f"Fatal error: {e}")
        print("Please ensure Firebase Storage is enabled in your project.")

if __name__ == "__main__":
    main()
