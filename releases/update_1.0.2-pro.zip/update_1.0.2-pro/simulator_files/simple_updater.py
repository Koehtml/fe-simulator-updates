"""
Simple Updater for FE Simulator
A lightweight update system that doesn't require PyUpdater
"""

import os
import sys
import json
import shutil
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import urllib.request
import urllib.error
from datetime import datetime
import hashlib
import tempfile
import zipfile
from pathlib import Path
try:
    from .update_config import get_update_config, get_app_info
except ImportError:
    from update_config import get_update_config, get_app_info

class SimpleUpdater:
    """Simple update manager that checks for updates and downloads them"""
    
    def __init__(self, app_name=None, current_version=None):
        # Load configuration
        config = get_update_config()
        app_info = get_app_info()
        
        self.app_name = app_name or app_info['name']
        self.current_version = current_version or app_info['version']
        self.update_url = config['server']['version_url']
        self.download_url = config['server']['download_url']
        self.update_available = False
        self.latest_version = None
        self.update_info = None
        
    def check_for_updates(self, callback=None):
        """Check for available updates"""
        def check_thread():
            try:
                # Create version check request
                request = urllib.request.Request(
                    self.update_url,
                    headers={'User-Agent': f'{self.app_name}/{self.current_version}'}
                )
                
                with urllib.request.urlopen(request, timeout=10) as response:
                    data = json.loads(response.read().decode())
                    
                self.latest_version = data.get('version')
                self.update_info = data
                
                # Compare versions (simple string comparison for now)
                if self._is_newer_version(self.latest_version, self.current_version):
                    self.update_available = True
                    if callback:
                        callback(True, f"Update available: {self.latest_version}")
                else:
                    self.update_available = False
                    if callback:
                        callback(False, "You have the latest version")
                        
            except urllib.error.URLError as e:
                if callback:
                    callback(False, f"Could not check for updates: {str(e)}")
            except Exception as e:
                if callback:
                    callback(False, f"Error checking for updates: {str(e)}")
        
        # Run in background thread
        thread = threading.Thread(target=check_thread, daemon=True)
        thread.start()
    
    def _is_newer_version(self, latest, current):
        """Simple version comparison"""
        try:
            # Convert version strings to tuples for comparison
            latest_parts = [int(x) for x in latest.split('.')]
            current_parts = [int(x) for x in current.split('.')]
            
            # Pad with zeros if needed
            max_len = max(len(latest_parts), len(current_parts))
            latest_parts.extend([0] * (max_len - len(latest_parts)))
            current_parts.extend([0] * (max_len - len(current_parts)))
            
            return latest_parts > current_parts
        except:
            # Fallback to string comparison
            return latest > current
    
    def download_update(self, progress_callback=None, completion_callback=None):
        """Download the update package"""
        if not self.update_available or not self.update_info:
            if completion_callback:
                completion_callback(False, "No update available")
            return
        
        def download_thread():
            try:
                # Get download URL from update info
                download_url = self.update_info.get('download_url', 
                    f"{self.download_url}update_{self.latest_version}.zip")
                
                # Create temporary file for download
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
                temp_path = temp_file.name
                temp_file.close()
                
                # Download with progress tracking
                def progress_hook(block_num, block_size, total_size):
                    if progress_callback and total_size > 0:
                        progress = (block_num * block_size) / total_size * 100
                        progress_callback(progress)
                
                urllib.request.urlretrieve(download_url, temp_path, progress_hook)
                
                # Verify download
                if self._verify_download(temp_path):
                    if completion_callback:
                        completion_callback(True, temp_path)
                else:
                    os.unlink(temp_path)
                    if completion_callback:
                        completion_callback(False, "Download verification failed")
                        
            except Exception as e:
                if completion_callback:
                    completion_callback(False, f"Download failed: {str(e)}")
        
        # Run in background thread
        thread = threading.Thread(target=download_thread, daemon=True)
        thread.start()
    
    def _verify_download(self, file_path):
        """Verify the downloaded file"""
        try:
            # Check if it's a valid zip file
            with zipfile.ZipFile(file_path, 'r') as zip_file:
                # Check for required files
                required_files = ['FE_Simulator.py', 'simulator_files/']
                file_list = zip_file.namelist()
                
                has_main = any('FE_Simulator.py' in f for f in file_list)
                has_simulator_files = any('simulator_files/' in f for f in file_list)
                
                return has_main and has_simulator_files
        except:
            return False
    
    def install_update(self, update_file_path, completion_callback=None):
        """Install the downloaded update"""
        def install_thread():
            try:
                # Get the application directory
                if getattr(sys, 'frozen', False):
                    # Running as compiled EXE
                    app_dir = os.path.dirname(sys.executable)
                else:
                    # Running as script
                    app_dir = os.path.dirname(os.path.abspath(__file__))
                    # Go up one level to get the main directory
                    app_dir = os.path.dirname(app_dir)
                
                # Create backup
                backup_dir = os.path.join(app_dir, 'backup_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
                self._create_backup(app_dir, backup_dir)
                
                # Extract update
                with zipfile.ZipFile(update_file_path, 'r') as zip_file:
                    zip_file.extractall(app_dir)
                
                # Clean up
                os.unlink(update_file_path)
                
                if completion_callback:
                    completion_callback(True, "Update installed successfully. Please restart the application.")
                    
            except Exception as e:
                if completion_callback:
                    completion_callback(False, f"Installation failed: {str(e)}")
        
        # Run in background thread
        thread = threading.Thread(target=install_thread, daemon=True)
        thread.start()
    
    def _create_backup(self, source_dir, backup_dir):
        """Create a backup of the current installation"""
        try:
            os.makedirs(backup_dir, exist_ok=True)
            
            # Files to backup
            files_to_backup = [
                'FE_Simulator.py',
                'simulator_files/',
                'version.txt',
                'pyupdater_config.py'
            ]
            
            for item in files_to_backup:
                source_path = os.path.join(source_dir, item)
                backup_path = os.path.join(backup_dir, item)
                
                if os.path.exists(source_path):
                    if os.path.isdir(source_path):
                        shutil.copytree(source_path, backup_path)
                    else:
                        shutil.copy2(source_path, backup_path)
                        
        except Exception as e:
            print(f"Backup creation failed: {e}")


class UpdateDialog:
    """User interface for the update process"""
    
    def __init__(self, parent, updater):
        self.parent = parent
        self.updater = updater
        self.dialog = None
        self.update_file_path = None
        
    def show_update_check_dialog(self):
        """Show the update check dialog"""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title("Check for Updates")
        self.dialog.geometry("500x400")
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # Center the dialog
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (400 // 2)
        self.dialog.geometry(f'500x400+{x}+{y}')
        
        # Title
        title_label = ttk.Label(self.dialog, text="Software Updates", font=('Arial', 16, 'bold'))
        title_label.pack(pady=20)
        
        # Current version info
        version_frame = ttk.Frame(self.dialog)
        version_frame.pack(pady=10, padx=20, fill='x')
        
        ttk.Label(version_frame, text=f"Current Version: {self.updater.current_version}", 
                 font=('Arial', 10)).pack(anchor='w')
        
        # Status area
        self.status_frame = ttk.Frame(self.dialog)
        self.status_frame.pack(pady=20, padx=20, fill='both', expand=True)
        
        # Initial status
        self.status_label = ttk.Label(self.status_frame, text="Click 'Check for Updates' to begin", 
                                     font=('Arial', 11))
        self.status_label.pack(pady=10)
        
        # Progress bar (initially hidden)
        self.progress = ttk.Progressbar(self.status_frame, mode='indeterminate')
        
        # Buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(pady=20)
        
        self.check_button = ttk.Button(button_frame, text="Check for Updates", 
                                      command=self._check_updates)
        self.check_button.pack(side='left', padx=5)
        
        self.close_button = ttk.Button(button_frame, text="Close", 
                                      command=self.dialog.destroy)
        self.close_button.pack(side='left', padx=5)
        
        # Auto-check for updates
        self._check_updates()
    
    def _check_updates(self):
        """Check for updates"""
        self.status_label.config(text="Checking for updates...")
        self.progress.pack(pady=10, fill='x')
        self.progress.start()
        self.check_button.config(state='disabled')
        
        def update_callback(update_available, message):
            self.dialog.after(0, self._update_status, update_available, message)
        
        self.updater.check_for_updates(update_callback)
    
    def _update_status(self, update_available, message):
        """Update the status display"""
        self.progress.stop()
        self.progress.pack_forget()
        self.check_button.config(state='normal')
        
        self.status_label.config(text=message)
        
        if update_available:
            self._show_update_options()
        else:
            # Show check again button
            self.check_button.config(text="Check Again")
    
    def _show_update_options(self):
        """Show update options when an update is available"""
        # Clear existing buttons
        for widget in self.dialog.winfo_children():
            if isinstance(widget, ttk.Frame) and widget != self.dialog.winfo_children()[-1]:
                for child in widget.winfo_children():
                    if isinstance(child, ttk.Button) and child != self.check_button and child != self.close_button:
                        child.destroy()
        
        # Add update information
        info_text = f"New version {self.updater.latest_version} is available!\n\n"
        if self.updater.update_info:
            changelog = self.updater.update_info.get('changelog', 'Bug fixes and improvements')
            info_text += f"Changes in this update:\n{changelog}"
        
        info_label = ttk.Label(self.status_frame, text=info_text, 
                              font=('Arial', 10), justify='left')
        info_label.pack(pady=10, anchor='w')
        
        # Add download button
        download_button = ttk.Button(self.status_frame, text="Download and Install Update", 
                                    command=self._download_update)
        download_button.pack(pady=10)
    
    def _download_update(self):
        """Download the update"""
        self.status_label.config(text="Downloading update...")
        self.progress.pack(pady=10, fill='x')
        self.progress.config(mode='determinate', value=0)
        self.progress.start()
        
        def progress_callback(progress):
            self.dialog.after(0, self._update_progress, progress)
        
        def completion_callback(success, message):
            self.dialog.after(0, self._download_complete, success, message)
        
        self.updater.download_update(progress_callback, completion_callback)
    
    def _update_progress(self, progress):
        """Update progress display"""
        self.progress.config(mode='determinate', value=progress)
    
    def _download_complete(self, success, message):
        """Handle download completion"""
        self.progress.stop()
        self.progress.pack_forget()
        
        if success:
            self.update_file_path = message
            self._show_install_option()
        else:
            self.status_label.config(text=f"Download failed: {message}")
    
    def _show_install_option(self):
        """Show install option after download"""
        self.status_label.config(text="Update downloaded successfully!")
        
        # Add install button
        install_button = ttk.Button(self.status_frame, text="Install Update Now", 
                                   command=self._install_update)
        install_button.pack(pady=10)
    
    def _install_update(self):
        """Install the update"""
        self.status_label.config(text="Installing update...")
        self.progress.pack(pady=10, fill='x')
        self.progress.config(mode='indeterminate')
        self.progress.start()
        
        def completion_callback(success, message):
            self.dialog.after(0, self._install_complete, success, message)
        
        self.updater.install_update(self.update_file_path, completion_callback)
    
    def _install_complete(self, success, message):
        """Handle install completion"""
        self.progress.stop()
        self.progress.pack_forget()
        
        if success:
            self.status_label.config(text=message)
            messagebox.showinfo("Update Complete", 
                              "Update installed successfully!\n\nPlease restart the application to apply changes.")
            self.dialog.destroy()
        else:
            self.status_label.config(text=f"Installation failed: {message}")


def create_simple_updater(app_name="FE Simulator", current_version="1.0.0"):
    """Factory function to create a simple updater"""
    return SimpleUpdater(app_name, current_version)


def show_simple_update_dialog(parent, updater):
    """Show the simple update dialog"""
    dialog = UpdateDialog(parent, updater)
    dialog.show_update_check_dialog()
