#!/usr/bin/env python3
"""
Update Media Size and Re-upload to Firestore

This script updates the media_size for all problems in both JSON files
and then re-uploads the updated data to both Firestore databases.
"""

import json
import argparse
import os
import sys
from typing import Dict, List, Any
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

def update_media_size_in_json(json_file_path: str, media_size: int) -> bool:
    """Update media_size for all problems in a JSON file."""
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        updated_count = 0
        for problem in data["problems"]:
            if problem.get("media") and problem["media"].strip():
                problem["media_size"] = media_size
                updated_count += 1
        
        with open(json_file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Updated {updated_count} problems with media in {os.path.basename(json_file_path)}")
        return True
        
    except Exception as e:
        print(f"✗ Error updating {json_file_path}: {e}")
        return False

class FirestoreReuploader:
    def __init__(self, project_id: str = "the-fe-simulator"):
        self.project_id = project_id
        self.db_default = None
        self.db_pro = None
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            cred_path = os.path.join(os.path.dirname(__file__), 'firebase-credentials.json')
            if os.path.exists(cred_path):
                cred = credentials.Certificate(cred_path)
                firebase_admin.initialize_app(cred)
                print(f"✓ Firebase initialized with credentials from: {cred_path}")
            else:
                firebase_admin.initialize_app()
                print("✓ Firebase initialized with default credentials")
        except ValueError:
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            sys.exit(1)
        
        # Initialize Firestore clients
        self.db_default = firestore.client()
        self.db_pro = firestore.client(database_id='the-fe-simulator-pro')
        print(f"✓ Connected to both Firestore databases")
    
    def load_problems_from_json(self, json_file_path: str) -> List[Dict[str, Any]]:
        """Load problems from JSON file."""
        try:
            with open(json_file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
            
            problems = data.get('problems', [])
            print(f"✓ Loaded {len(problems)} problems from {os.path.basename(json_file_path)}")
            return problems
            
        except Exception as e:
            print(f"✗ Error loading {json_file_path}: {e}")
            return []
    
    def update_problem_in_firestore(self, db, problem: Dict[str, Any]) -> bool:
        """Update a single problem in Firestore."""
        try:
            doc_id = str(problem['number'])
            doc_ref = db.collection('problems').document(doc_id)
            
            # Update only the media_size field
            doc_ref.update({
                'media_size': problem.get('media_size', 100),
                'updated_at': datetime.utcnow().isoformat() + 'Z'
            })
            return True
        except Exception as e:
            print(f"✗ Error updating problem {problem.get('number', 'unknown')}: {e}")
            return False
    
    def reupload_database(self, json_file_path: str, database_name: str, db):
        """Re-upload problems to a specific database."""
        print(f"\n🔄 Updating {database_name} database...")
        print("-" * 50)
        
        problems = self.load_problems_from_json(json_file_path)
        if not problems:
            return
        
        updated_count = 0
        for problem in problems:
            if self.update_problem_in_firestore(db, problem):
                updated_count += 1
        
        print(f"✓ Updated {updated_count}/{len(problems)} problems in {database_name} database")
    
    def run_reupload(self, json_50_path: str, json_110_path: str):
        """Run the complete re-upload process."""
        print("🔄 Updating Media Sizes in Firestore")
        print("=" * 50)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Update default database (50 problems)
        self.reupload_database(json_50_path, "default", self.db_default)
        
        # Update pro database (110 problems)
        self.reupload_database(json_110_path, "the-fe-simulator-pro", self.db_pro)
        
        print("\n" + "=" * 50)
        print("✅ Media size update completed!")

def main():
    parser = argparse.ArgumentParser(description='Update media_size for all problems and re-upload to Firestore')
    parser.add_argument('--size', type=int, default=40, help='Desired media_size value (default: 40)')
    parser.add_argument('--upload', action='store_true', help='Re-upload to Firestore after updating JSON files')
    args = parser.parse_args()
    
    script_dir = os.path.dirname(__file__)
    json_50_path = os.path.join(script_dir, 'problems_database_50_fixed.json')
    json_110_path = os.path.join(script_dir, 'problems_database.json')
    
    print(f"📏 Setting media_size to {args.size} for all problems with media")
    print("=" * 60)
    
    # Update both JSON files
    success_50 = update_media_size_in_json(json_50_path, args.size)
    success_110 = update_media_size_in_json(json_110_path, args.size)
    
    if not (success_50 and success_110):
        print("✗ Failed to update JSON files. Aborting.")
        return
    
    # Re-upload to Firestore if requested
    if args.upload:
        reuploader = FirestoreReuploader()
        reuploader.run_reupload(json_50_path, json_110_path)
    else:
        print(f"\n💡 To re-upload to Firestore, run: python {os.path.basename(__file__)} --size {args.size} --upload")

if __name__ == "__main__":
    main() 