#!/usr/bin/env python3
"""
Firestore Storage Integration Script for FE Simulator

This script modifies FE_Simulator.py to use the new Firestore Storage Problem Manager
instead of the base64-based problem manager.
"""

import os
import shutil
from datetime import datetime

def backup_original_file():
    """Create a backup of the original FE_Simulator.py file."""
    original_file = "FE_Simulator.py"
    backup_file = f"FE_Simulator_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
    
    if os.path.exists(original_file):
        shutil.copy2(original_file, backup_file)
        print(f"✓ Created backup: {backup_file}")
        return backup_file
    else:
        print(f"✗ Original file not found: {original_file}")
        return None

def integrate_firestore_storage_problem_manager():
    """Integrate Firestore Storage Problem Manager into FE_Simulator.py."""
    
    # Create backup
    backup_file = backup_original_file()
    if not backup_file:
        return False
    
    # Read the original file
    with open("FE_Simulator.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # Make the necessary changes
    modified_content = content
    
    # 1. Update imports - replace the old Firestore imports with Storage-based ones
    old_import = "from simulator_files.firestore_problem_manager import FirestoreProblemManager, FirestoreProblem"
    new_import = "from simulator_files.firestore_storage_problem_manager import FirestoreStorageProblemManager, FirestoreStorageProblem"
    
    if old_import in modified_content:
        modified_content = modified_content.replace(old_import, new_import)
        print("✓ Updated imports to use Storage-based problem manager")
    else:
        print("⚠ Old imports not found, checking for alternative import patterns...")
        # Try to find and replace the base64-based imports
        old_import_alt = "from simulator_files.problem_manager import ProblemManager, Problem"
        new_import_alt = """from simulator_files.problem_manager import ProblemManager, Problem
from simulator_files.firestore_storage_problem_manager import FirestoreStorageProblemManager, FirestoreStorageProblem"""
        
        if old_import_alt in modified_content:
            modified_content = modified_content.replace(old_import_alt, new_import_alt)
            print("✓ Added Storage-based problem manager imports")
        else:
            print("⚠ Could not find import statements to update")
    
    # 2. Update problem manager initialization
    old_init_patterns = [
        # Pattern 1: FirestoreProblemManager initialization
        """        # Initialize the problem manager (Firestore-based)
        try:
            self.problem_manager = FirestoreProblemManager(num_questions=self.num_questions)""",
        
        # Pattern 2: ProblemManager initialization
        """        # Initialize the problem manager
        try:
            self.problem_manager = ProblemManager(num_questions=self.num_questions)"""
    ]
    
    new_init = """        # Initialize the problem manager (Firestore Storage-based)
        try:
            self.problem_manager = FirestoreStorageProblemManager(num_questions=self.num_questions)
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Firestore Storage problem manager initialized with {self.problem_manager.total_problems()} problems\\n")
        except Exception as e:
            # Debug logging
            with open(get_debug_log_path(), "a") as f:
                f.write(f"Error initializing Firestore Storage problem manager: {str(e)}\\n")
            # Fallback to local problem manager
            try:
                self.problem_manager = ProblemManager(num_questions=self.num_questions)
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Fallback to local problem manager with {self.problem_manager.total_problems()} problems\\n")
            except Exception as e2:
                with open(get_debug_log_path(), "a") as f:
                    f.write(f"Error initializing local problem manager: {str(e2)}\\n")
                raise"""
    
    # Try to replace each pattern
    replacement_made = False
    for old_pattern in old_init_patterns:
        if old_pattern in modified_content:
            modified_content = modified_content.replace(old_pattern, new_init)
            print("✓ Updated problem manager initialization")
            replacement_made = True
            break
    
    if not replacement_made:
        print("⚠ Could not find problem manager initialization to update")
    
    # 3. Update media loading logic - replace base64 loading with Storage URL loading
    old_media_loading_patterns = [
        # Pattern 1: Base64 media loading
        """            # Try to load embedded media first (Firestore)
            if hasattr(problem, 'media_type') and problem.media_type == 'base64':
                try:
                    photo = self.problem_manager.load_embedded_media(problem)
                    if photo:
                        self.problem_text.image_create(tk.END, image=photo)
                        self.problem_text.media_image = photo
                        print(f"Successfully loaded embedded media for problem {problem.number}")
                    else:
                        print(f"Failed to load embedded media for problem {problem.number}")
                        self.problem_text.insert(tk.END, f"\\n[Failed to load embedded media: {problem.media_filename}]")
                except Exception as e:
                    print(f"Error loading embedded media: {e}")
                    self.problem_text.insert(tk.END, f"\\n[Error loading embedded media: {str(e)}]")
            else:""",
        
        # Pattern 2: Alternative base64 pattern
        """            # Try to load embedded media first (Firestore)
            if hasattr(problem, 'media_type') and problem.media_type == 'base64':"""
    ]
    
    new_media_loading = """            # Try to load Storage media first (Firestore)
            if hasattr(problem, 'media_url') and problem.media_type == 'storage_url':
                try:
                    photo = self.problem_manager.load_storage_media(problem)
                    if photo:
                        self.problem_text.image_create(tk.END, image=photo)
                        self.problem_text.media_image = photo
                        print(f"Successfully loaded Storage media for problem {problem.number}")
                    else:
                        print(f"Failed to load Storage media for problem {problem.number}")
                        self.problem_text.insert(tk.END, f"\\n[Failed to load Storage media: {problem.media_filename}]")
                except Exception as e:
                    print(f"Error loading Storage media: {e}")
                    self.problem_text.insert(tk.END, f"\\n[Error loading Storage media: {str(e)}]")
            elif hasattr(problem, 'media_type') and problem.media_type == 'base64':
                # Fallback to base64 loading if Storage fails
                try:
                    photo = self.problem_manager.load_embedded_media(problem)
                    if photo:
                        self.problem_text.image_create(tk.END, image=photo)
                        self.problem_text.media_image = photo
                        print(f"Successfully loaded embedded media for problem {problem.number}")
                    else:
                        print(f"Failed to load embedded media for problem {problem.number}")
                        self.problem_text.insert(tk.END, f"\\n[Failed to load embedded media: {problem.media_filename}]")
                except Exception as e:
                    print(f"Error loading embedded media: {e}")
                    self.problem_text.insert(tk.END, f"\\n[Error loading embedded media: {str(e)}]")
            else:"""
    
    # Try to replace each pattern
    media_replacement_made = False
    for old_pattern in old_media_loading_patterns:
        if old_pattern in modified_content:
            modified_content = modified_content.replace(old_pattern, new_media_loading)
            print("✓ Updated media loading logic to use Storage URLs")
            media_replacement_made = True
            break
    
    if not media_replacement_made:
        print("⚠ Could not find media loading logic to update")
    
    # Write the modified content back to the file
    with open("FE_Simulator.py", "w", encoding="utf-8") as f:
        f.write(modified_content)
    
    print("✓ Successfully integrated Firestore Storage Problem Manager into FE_Simulator.py")
    return True

def create_integration_summary():
    """Create a summary of the integration changes."""
    summary = """# Firestore Storage Integration Summary

## Changes Made to FE_Simulator.py:

1. **Updated Imports**: Changed from base64-based to Storage-based problem manager
2. **Modified Problem Manager Initialization**: 
   - Now uses FirestoreStorageProblemManager as primary
   - Falls back to local ProblemManager if Storage fails
3. **Enhanced Media Loading**:
   - First tries to load images from Firebase Storage URLs
   - Falls back to base64 loading if Storage fails
   - Maintains backward compatibility with local files

## Benefits:

✅ **Efficient Media Loading**: Images loaded directly from Storage URLs (no base64 decoding)
✅ **Better Performance**: Faster image loading and smaller Firestore documents
✅ **Cloud-based**: Problems and media loaded from Firestore database
✅ **Offline Support**: Caches problems locally for offline use
✅ **Backward Compatible**: Falls back to base64/local files if needed
✅ **Real-time Updates**: Can update problems and media without app updates

## Files Created:

- `firestore_storage_problem_manager.py`: New Storage-based problem manager
- `firestore_storage_cache.json`: Local cache of problems (auto-generated)
- `FE_Simulator_backup_*.py`: Backup of original file

## Usage:

The simulator will now automatically:
1. Connect to Firestore and load problems
2. Load images from Firebase Storage URLs
3. Cache problems locally for performance
4. Fall back to base64/local files if needed

## Testing:

Run the simulator normally - it will now use Firebase Storage for media loading!
"""
    
    with open("FIRESTORE_STORAGE_INTEGRATION_SUMMARY.md", "w", encoding="utf-8") as f:
        f.write(summary)
    
    print("✓ Created integration summary: FIRESTORE_STORAGE_INTEGRATION_SUMMARY.md")

def main():
    """Main function to run the integration."""
    print("Firestore Storage Integration for FE Simulator")
    print("="*40)
    
    success = integrate_firestore_storage_problem_manager()
    
    if success:
        create_integration_summary()
        print("\n✅ Integration completed successfully!")
        print("\nYour simulator is now ready to use Firebase Storage for media!")
        print("Run FE_Simulator.py to test the integration.")
    else:
        print("\n❌ Integration failed. Please check the errors above.")

if __name__ == "__main__":
    main()
