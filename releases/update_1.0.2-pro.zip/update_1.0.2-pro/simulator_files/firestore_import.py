#!/usr/bin/env python3
"""
Firestore Import Script for FE Simulator Practice Questions

This script imports practice questions from problems_database.json into a Firestore database.
Uses Firebase Admin SDK for authentication and handles all specified requirements.
"""

import json
import os
import sys
from typing import Dict, List, Any
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

class FirestoreImporter:
    def __init__(self, project_id: str = "the-fe-simulator"):
        """
        Initialize the Firestore importer.
        
        Args:
            project_id: Firebase project ID
        """
        self.project_id = project_id
        self.db = None
        self.errors = []
        self.skipped = []
        self.imported = []
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to initialize with credentials file
            cred_path = os.path.join(os.path.dirname(__file__), 'firebase-credentials.json')
            if os.path.exists(cred_path):
                cred = credentials.Certificate(cred_path)
                firebase_admin.initialize_app(cred)
                print(f"✓ Firebase initialized with credentials from: {cred_path}")
            else:
                # Fallback to default credentials
                firebase_admin.initialize_app()
                print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Please ensure you have set up Firebase Admin SDK credentials.")
            print("You can set GOOGLE_APPLICATION_CREDENTIALS environment variable")
            print("or use 'firebase login' if you have Firebase CLI installed.")
            sys.exit(1)
        
        # Initialize Firestore client
        self.db = firestore.client()
        print(f"✓ Connected to Firestore project: {self.project_id}")
    
    def load_json_data(self, file_path: str) -> Dict[str, Any]:
        """
        Load and parse the JSON file containing practice problems.
        
        Args:
            file_path: Path to the JSON file
            
        Returns:
            Dictionary containing the problems data
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                print(f"✓ Loaded {len(data.get('problems', []))} problems from {file_path}")
                return data
        except FileNotFoundError:
            print(f"✗ Error: File not found at {file_path}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"✗ Error: Invalid JSON format in {file_path}: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"✗ Error reading file {file_path}: {e}")
            sys.exit(1)
    
    def validate_problem(self, problem: Dict[str, Any]) -> bool:
        """
        Validate a problem object has all required fields.
        
        Args:
            problem: Problem dictionary to validate
            
        Returns:
            True if valid, False otherwise
        """
        required_fields = ['number', 'category', 'question', 'choices', 'correct_answer']
        
        for field in required_fields:
            if field not in problem:
                self.errors.append(f"Problem {problem.get('number', 'unknown')}: Missing required field '{field}'")
                return False
        
        # Validate choices array has exactly 4 elements
        if len(problem.get('choices', [])) != 4:
            self.errors.append(f"Problem {problem.get('number', 'unknown')}: Must have exactly 4 choices")
            return False
        
        # Validate correct_answer is A, B, C, or D
        if problem.get('correct_answer') not in ['A', 'B', 'C', 'D']:
            self.errors.append(f"Problem {problem.get('number', 'unknown')}: Invalid correct_answer '{problem.get('correct_answer')}'")
            return False
        
        return True
    
    def transform_problem(self, problem: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform problem data for Firestore storage.
        
        Args:
            problem: Original problem dictionary
            
        Returns:
            Transformed problem dictionary
        """
        # Create a copy to avoid modifying the original
        transformed = problem.copy()
        
        # Convert number to integer
        try:
            transformed['number'] = int(problem['number'])
        except (ValueError, TypeError):
            self.errors.append(f"Problem {problem.get('number', 'unknown')}: Invalid number format")
            return None
        
        # Ensure media_size is an integer
        if 'media_size' in transformed:
            try:
                transformed['media_size'] = int(transformed['media_size'])
            except (ValueError, TypeError):
                transformed['media_size'] = 40  # Default value
        
        # Add timestamp for tracking
        transformed['imported_at'] = datetime.utcnow()
        
        return transformed
    
    def check_document_exists(self, doc_id: str) -> bool:
        """
        Check if a document already exists in Firestore.
        
        Args:
            doc_id: Document ID to check
            
        Returns:
            True if document exists, False otherwise
        """
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc = doc_ref.get()
            return doc.exists
        except Exception as e:
            print(f"Warning: Could not check if document {doc_id} exists: {e}")
            return False
    
    def import_problem(self, problem: Dict[str, Any]) -> bool:
        """
        Import a single problem to Firestore.
        
        Args:
            problem: Problem dictionary to import
            
        Returns:
            True if successful, False otherwise
        """
        doc_id = str(problem['number'])
        
        # Check if document already exists
        if self.check_document_exists(doc_id):
            self.skipped.append(doc_id)
            return True  # Not an error, just skipped
        
        # Validate problem
        if not self.validate_problem(problem):
            return False
        
        # Transform problem
        transformed_problem = self.transform_problem(problem)
        if transformed_problem is None:
            return False
        
        # Upload to Firestore
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc_ref.set(transformed_problem)
            self.imported.append(doc_id)
            return True
        except Exception as e:
            self.errors.append(f"Problem {doc_id}: Failed to upload to Firestore: {e}")
            return False
    
    def import_all_problems(self, problems: List[Dict[str, Any]]):
        """
        Import all problems to Firestore.
        
        Args:
            problems: List of problem dictionaries
        """
        total_problems = len(problems)
        print(f"\nStarting import of {total_problems} problems...")
        
        for i, problem in enumerate(problems, 1):
            print(f"Processing problem {i}/{total_problems} (ID: {problem.get('number', 'unknown')})", end=" ")
            
            success = self.import_problem(problem)
            
            if success:
                if str(problem.get('number', 'unknown')) in self.skipped:
                    print("→ Skipped (already exists)")
                else:
                    print("→ Imported")
            else:
                print("→ Failed")
        
        # Print summary
        self.print_summary()
    
    def print_summary(self):
        """Print import summary."""
        print("\n" + "="*50)
        print("IMPORT SUMMARY")
        print("="*50)
        print(f"Total problems processed: {len(self.imported) + len(self.skipped) + len(self.errors)}")
        print(f"Successfully imported: {len(self.imported)}")
        print(f"Skipped (already exist): {len(self.skipped)}")
        print(f"Errors: {len(self.errors)}")
        
        if self.imported:
            print(f"\nImported problem IDs: {', '.join(sorted(self.imported))}")
        
        if self.skipped:
            print(f"\nSkipped problem IDs: {', '.join(sorted(self.skipped))}")
        
        if self.errors:
            print(f"\nERRORS:")
            for error in self.errors:
                print(f"  - {error}")
    
    def run_import(self, json_file_path: str):
        """
        Run the complete import process.
        
        Args:
            json_file_path: Path to the JSON file containing problems
        """
        print("FE Simulator - Firestore Import Tool")
        print("="*40)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Load JSON data
        data = self.load_json_data(json_file_path)
        problems = data.get('problems', [])
        
        if not problems:
            print("✗ No problems found in the JSON file")
            return
        
        # Import all problems
        self.import_all_problems(problems)


def main():
    """Main function to run the import script."""
    # Get the path to the JSON file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    json_file_path = os.path.join(script_dir, "problems_database.json")
    
    # Check if JSON file exists
    if not os.path.exists(json_file_path):
        print(f"✗ Error: problems_database.json not found at {json_file_path}")
        print("Please ensure the JSON file is in the same directory as this script.")
        sys.exit(1)
    
    # Create importer and run import
    importer = FirestoreImporter()
    importer.run_import(json_file_path)


if __name__ == "__main__":
    main()
