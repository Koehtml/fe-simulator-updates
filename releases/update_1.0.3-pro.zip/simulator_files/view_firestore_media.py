#!/usr/bin/env python3
"""
Firestore Media Viewer Script

This script allows you to view and verify the embedded media files in Firestore documents.
"""

import os
import sys
import base64
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

class FirestoreMediaViewer:
    def __init__(self, project_id: str = "the-fe-simulator"):
        """
        Initialize the Firestore media viewer.
        
        Args:
            project_id: Firebase project ID
        """
        self.project_id = project_id
        self.db = None
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to initialize with default credentials
            firebase_admin.initialize_app()
            print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Please ensure you have set up Firebase Admin SDK credentials.")
            sys.exit(1)
        
        # Initialize Firestore client
        self.db = firestore.client()
        print(f"✓ Connected to Firestore project: {self.project_id}")
    
    def get_problems_with_media(self) -> List[Dict]:
        """
        Get all problems from Firestore that have media files.
        
        Returns:
            List of problem documents with media
        """
        try:
            problems_ref = self.db.collection('problems')
            problems = []
            
            for doc in problems_ref.stream():
                problem_data = doc.to_dict()
                if problem_data.get('media') and problem_data['media'].strip():
                    problem_data['doc_id'] = doc.id
                    problems.append(problem_data)
            
            return problems
            
        except Exception as e:
            print(f"✗ Error fetching problems from Firestore: {e}")
            return []
    
    def view_media_info(self):
        """Display information about embedded media files."""
        print("\n" + "="*60)
        print("FIRESTORE MEDIA FILES INFORMATION")
        print("="*60)
        
        problems = self.get_problems_with_media()
        if not problems:
            print("No problems with media found in Firestore.")
            return
        
        print(f"Found {len(problems)} problems with embedded media files:\n")
        
        for problem in problems:
            doc_id = problem['doc_id']
            number = problem.get('number', 'Unknown')
            category = problem.get('category', 'Unknown')
            media_type = problem.get('media_type', 'Unknown')
            media_filename = problem.get('media_filename', 'Unknown')
            media_updated = problem.get('media_updated_at', 'Unknown')
            
            # Calculate media size
            media_data = problem.get('media', '')
            if media_data:
                media_size_bytes = len(media_data.encode('utf-8'))
                media_size_kb = media_size_bytes / 1024
            else:
                media_size_kb = 0
            
            print(f"Problem {number} ({doc_id}):")
            print(f"  Category: {category}")
            print(f"  Media Type: {media_type}")
            print(f"  Original Filename: {media_filename}")
            print(f"  Embedded Size: {media_size_kb:.1f} KB")
            print(f"  Last Updated: {media_updated}")
            print()
    
    def save_media_to_local(self, output_dir: str = "extracted_media"):
        """
        Extract and save embedded media files to local directory.
        
        Args:
            output_dir: Directory to save extracted media files
        """
        print(f"\n" + "="*60)
        print(f"EXTRACTING MEDIA FILES TO: {output_dir}")
        print("="*60)
        
        # Create output directory
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"✓ Created output directory: {output_dir}")
        
        problems = self.get_problems_with_media()
        if not problems:
            print("No problems with media found in Firestore.")
            return
        
        extracted_count = 0
        
        for problem in problems:
            doc_id = problem['doc_id']
            number = problem.get('number', 'Unknown')
            media_filename = problem.get('media_filename', f'problem_{doc_id}.jpg')
            media_data = problem.get('media', '')
            
            if media_data and problem.get('media_type') == 'base64':
                try:
                    # Decode base64 data
                    file_data = base64.b64decode(media_data)
                    
                    # Save to file
                    output_path = os.path.join(output_dir, media_filename)
                    with open(output_path, 'wb') as f:
                        f.write(file_data)
                    
                    print(f"✓ Extracted: {media_filename} (Problem {number})")
                    extracted_count += 1
                    
                except Exception as e:
                    print(f"✗ Error extracting {media_filename}: {e}")
            else:
                print(f"⚠ Skipping problem {number} - no valid media data")
        
        print(f"\n✓ Successfully extracted {extracted_count} media files to {output_dir}")
    
    def show_firebase_console_instructions(self):
        """Show instructions for viewing media in Firebase Console."""
        print("\n" + "="*60)
        print("VIEWING MEDIA IN FIREBASE CONSOLE")
        print("="*60)
        print("To view the embedded media files in Firebase Console:")
        print()
        print("1. Go to: https://console.firebase.google.com/project/the-fe-simulator")
        print("2. Click on 'Firestore Database' in the left sidebar")
        print("3. Click on the 'problems' collection")
        print("4. Click on any problem document that has media")
        print("5. Look for these fields:")
        print("   - 'media': Contains the base64 encoded image data")
        print("   - 'media_filename': Original filename")
        print("   - 'media_type': Should be 'base64'")
        print("   - 'media_updated_at': When the media was embedded")
        print()
        print("Note: The 'media' field contains a very long base64 string.")
        print("This is the actual image data embedded directly in the document.")
        print()
        print("Problems with embedded media:")
        problems = self.get_problems_with_media()
        if problems:
            problem_ids = [p['doc_id'] for p in problems]
            print(f"   Document IDs: {', '.join(sorted(problem_ids))}")
    
    def run_viewer(self):
        """Run the media viewer."""
        print("FE Simulator - Firestore Media Viewer")
        print("="*40)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Show media information
        self.view_media_info()
        
        # Show Firebase Console instructions
        self.show_firebase_console_instructions()
        
        # Ask if user wants to extract media
        print("\n" + "="*60)
        print("EXTRACTION OPTION")
        print("="*60)
        response = input("Would you like to extract the media files to a local directory? (y/n): ")
        
        if response.lower() in ['y', 'yes']:
            output_dir = input("Enter output directory name (default: 'extracted_media'): ").strip()
            if not output_dir:
                output_dir = "extracted_media"
            self.save_media_to_local(output_dir)


def main():
    """Main function to run the media viewer."""
    viewer = FirestoreMediaViewer()
    viewer.run_viewer()


if __name__ == "__main__":
    main()
