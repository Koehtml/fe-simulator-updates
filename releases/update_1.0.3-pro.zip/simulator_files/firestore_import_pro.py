#!/usr/bin/env python3
"""
Firestore Import Script for Pro Database (110 Problems)

This script imports the 110 problems from problems_database.json into the the-fe-simulator-pro Firestore database.
"""

import json
import os
import sys
from typing import Dict, List, Any
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

class FirestoreImporterPro:
    def __init__(self, project_id: str = "the-fe-simulator"):
        """
        Initialize the Firestore importer for pro database.
        
        Args:
            project_id: Firebase project ID
        """
        self.project_id = project_id
        self.db = None
        self.errors = []
        self.skipped = []
        self.imported = []
        
    def initialize_firebase(self):
        """Initialize Firebase Admin SDK."""
        try:
            # Try to initialize with credentials file
            cred_path = os.path.join(os.path.dirname(__file__), 'firebase-credentials.json')
            if os.path.exists(cred_path):
                cred = credentials.Certificate(cred_path)
                firebase_admin.initialize_app(cred)
                print(f"✓ Firebase initialized with credentials from: {cred_path}")
            else:
                # Fallback to default credentials
                firebase_admin.initialize_app()
                print("✓ Firebase initialized with default credentials")
        except ValueError:
            # App already initialized
            print("✓ Firebase already initialized")
        except Exception as e:
            print(f"✗ Error initializing Firebase: {e}")
            print("Please ensure you have set up Firebase Admin SDK credentials.")
            sys.exit(1)
        
        # Initialize Firestore client for the-fe-simulator-pro database
        self.db = firestore.client(database_id='the-fe-simulator-pro')
        print(f"✓ Connected to Firestore project: {self.project_id} (the-fe-simulator-pro database)")
    
    def load_problems_from_json(self, json_file_path: str) -> List[Dict[str, Any]]:
        """Load problems from JSON file."""
        try:
            with open(json_file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
            
            problems = data.get('problems', [])
            print(f"✓ Loaded {len(problems)} problems from {json_file_path}")
            return problems
            
        except FileNotFoundError:
            print(f"✗ Error: {json_file_path} not found!")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"✗ Error: Invalid JSON format in {json_file_path}: {e}")
            sys.exit(1)
    
    def validate_problem(self, problem: Dict[str, Any]) -> bool:
        """Validate a problem has all required fields."""
        required_fields = ['number', 'category', 'question', 'choices', 'correct_answer']
        
        for field in required_fields:
            if field not in problem or not problem[field]:
                self.errors.append(f"Problem {problem.get('number', 'unknown')}: Missing required field '{field}'")
                return False
        
        # Validate choices
        if not isinstance(problem['choices'], list) or len(problem['choices']) != 4:
            self.errors.append(f"Problem {problem['number']}: Invalid choices format")
            return False
        
        # Validate correct answer
        if problem['correct_answer'] not in ['A', 'B', 'C', 'D']:
            self.errors.append(f"Problem {problem['number']}: Invalid correct answer '{problem['correct_answer']}'")
            return False
        
        return True
    
    def transform_problem(self, problem: Dict[str, Any]) -> Dict[str, Any]:
        """Transform problem for Firestore storage."""
        try:
            # Convert number to integer
            number = int(problem['number'])
            
            # Create transformed problem
            transformed = {
                'number': number,
                'category': problem['category'],
                'question': problem['question'],
                'media': problem.get('media', ''),
                'choices': problem['choices'],
                'correct_answer': problem['correct_answer'],
                'media_size': problem.get('media_size', 100),
                'imported_at': datetime.utcnow().isoformat() + 'Z'
            }
            
            return transformed
            
        except ValueError as e:
            self.errors.append(f"Problem {problem['number']}: Invalid number format: {e}")
            return None
    
    def check_document_exists(self, doc_id: str) -> bool:
        """Check if a document already exists in Firestore."""
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc = doc_ref.get()
            return doc.exists
        except Exception as e:
            print(f"Warning: Could not check if document {doc_id} exists: {e}")
            return False
    
    def import_problem(self, problem: Dict[str, Any]) -> bool:
        """Import a single problem to Firestore."""
        doc_id = str(problem['number'])
        
        # Check if document already exists
        if self.check_document_exists(doc_id):
            self.skipped.append(doc_id)
            return True  # Not an error, just skipped
        
        # Validate problem
        if not self.validate_problem(problem):
            return False
        
        # Transform problem
        transformed_problem = self.transform_problem(problem)
        if transformed_problem is None:
            return False
        
        # Upload to Firestore
        try:
            doc_ref = self.db.collection('problems').document(doc_id)
            doc_ref.set(transformed_problem)
            self.imported.append(doc_id)
            return True
        except Exception as e:
            self.errors.append(f"Problem {doc_id}: Failed to upload to Firestore: {e}")
            return False
    
    def import_all_problems(self, problems: List[Dict[str, Any]]):
        """Import all problems to Firestore."""
        print(f"\nStarting import of {len(problems)} problems...")
        print("=" * 50)
        
        for i, problem in enumerate(problems, 1):
            doc_id = str(problem['number'])
            status = "Imported" if self.import_problem(problem) else "Failed"
            print(f"Processing problem {i}/{len(problems)} (ID: {doc_id}) → {status}")
        
        # Print summary
        print("\n" + "=" * 50)
        print("IMPORT SUMMARY")
        print("=" * 50)
        print(f"Total problems processed: {len(problems)}")
        print(f"Successfully imported: {len(self.imported)}")
        print(f"Skipped (already exist): {len(self.skipped)}")
        print(f"Errors: {len(self.errors)}")
        
        if self.imported:
            print(f"\nImported problem IDs: {', '.join(self.imported)}")
        
        if self.skipped:
            print(f"\nSkipped problem IDs: {', '.join(self.skipped)}")
        
        if self.errors:
            print(f"\nErrors:")
            for error in self.errors:
                print(f"  - {error}")
    
    def run_import(self, json_file_path: str):
        """Run the complete import process."""
        print("FE Simulator - Firestore Import Tool (Pro Database)")
        print("=" * 50)
        
        # Initialize Firebase
        self.initialize_firebase()
        
        # Load problems
        problems = self.load_problems_from_json(json_file_path)
        
        # Import all problems
        self.import_all_problems(problems)

def main():
    """Main function."""
    # Get the directory where this script is located
    script_dir = os.path.dirname(__file__)
    json_file_path = os.path.join(script_dir, 'problems_database.json')
    
    # Create importer and run import
    importer = FirestoreImporterPro()
    importer.run_import(json_file_path)

if __name__ == "__main__":
    main()
